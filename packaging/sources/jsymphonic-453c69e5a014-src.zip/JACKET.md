# Album jackets

The headless engine reads and replaces album jacket pictures in the native
OMGAUDIO tree. It does not embed the image in the audio file. Jacket edits are
published through the same write-ahead journal as playlists (`playlist-recover`).

## Commands and protocol

```
jackets --device <mount>
jacket-set --device <mount> (--id <track-id> | --album-base64 <UTF-8-base64>) --image <jpeg>
jacket-clear --device <mount> (--id <track-id> | --album-base64 <UTF-8-base64>)
```

`--album <text>` is accepted in place of `--album-base64`. The two album options
are mutually exclusive, and exactly one of `--id` or an album option is required
for set and clear. `--album-base64` is standard base64 of UTF-8 bytes, for the
same Windows launcher reason as playlist names.

`jackets` emits one row per album group, then a terminator:

```json
{"event":"jacket","slot":"1","album":"Night","artist":"Ada","trackIds":["14","1"],"path":"20P00/1G000001P0.JPG","bytes":842}
{"event":"jacket","slot":"2","album":"Day","artist":"Bea","trackIds":["3"],"path":null,"bytes":0}
{"event":"jacketsEnd","count":2}
```

`jacket-set` and `jacket-clear` emit the affected row only after the journal has
published, then `{"event":"done"}`. `path` is null when that group has no
managed JPEG. Failures emit `fatal` and return nonzero.

A pending `.jsymphonic-playlist-transaction` reuses the playlist code. No
`JACKET_*` code is emitted:

```json
{"event":"fatal","message":"IOException: An incomplete playlist transaction requires backup recovery before another operation","code":"PLAYLIST_JOURNAL_PENDING"}
```

`PLAYLIST_LIBRARY_NOT_LOADED` is the playlist-repair code for an empty or
unloaded track library. Jacket commands do not emit it. A bad image, a foreign
picture pointer, and a `java.lang.Error` such as `OutOfMemoryError` are fatal
events with no `code`. The error path does not publish a jacket.

`jackets` reports a leftover rename-probe sibling and does not rename it, the
same way `list`, `info`, and `playlists` do:

```json
{"event":"warning","code":"DEVICE_PROBE_PENDING","path":"OMGAUDIO/10F00/10000001.OMA","probe_path":"OMGAUDIO/10F00/10000001.OMA.jsymphonic-probe"}
```

`jacket-set` and `jacket-clear` restore those siblings before any jacket work,
the same as other writes. A sibling that cannot be renamed back is
`DEVICE_PROBE_RESTORE_FAILED`. A sibling whose bytes differ from the original
is `DEVICE_PROBE_CONFLICT`. Both include `path` and `probe_path`. That shared
scan looks at `10F*` folders.

Before the commit marker, `jacket-set` and `jacket-clear` also run the rename
probe on the old `20P00` JPEG. A locked file is refused up front:

```json
{"event":"fatal","message":"Device file is locked","code":"DEVICE_FILE_LOCKED","path":"OMGAUDIO/20P00/1G000001P0.JPG"}
```

A read-only old JPEG is `DEVICE_FILE_READ_ONLY` with that same path. Neither
creates a journal or changes the live tree. A failure to read the old JPEG
while staging it, before the commit marker, is still a fatal with no `code`:
the journal directory is discarded and the live tree is unchanged.

After the commit marker, a rollback that cannot put every file back keeps the
journal and emits:

```json
{"event":"fatal","message":"Database update failed; incomplete recovery requires a verified backup","code":"DEVICE_ROLLBACK_FAILED"}
```

`playlist-recover` (with or without `--inspect`) is the recovery command for a
jacket journal. It is the same journal as a playlist or base-table write.

An album name matches the group's `TIT2` text. If none match, it also matches
the jsymphonic `artist + "/" + album` shape stored in `TIT2` with the artist in
`TPE1`. Zero matches, or more than one, fail before any write. `--id` selects
the group whose `01TREE01.DAT` membership contains that track id.

## Confirmed layout

These points are corroborated by this tree's writer, by mattn/sonydb
`write_03GINFXX` for type 1, and by Sony's own player documentation. The
inspected sonydb file is the same one named in `NATIVE-PLAYLISTS.md`
(`0a5eb09b1098d12773ae21ebee62d7846e7340f68404f2583d6e0d300299c904`). No source
from that project is copied here.

- `03GINF01.DAT` is a `GPIF` table. Its `GPFB` records are `0x310` bytes: a
  16-byte header (`tag count = 6`, `tag size = 0x80`) and six `0x80`-byte tags
  `TIT2`, `TPE1`, `TCON`, `TSOP`, `PICP`, `PIC0`.
- Encoding word `0x0002` is UTF-16BE, the same convention as playlist names.
  Both this codebase and sonydb write `PICP` and `PIC0` as empty text.
- One `GPFB` record is one artist/album group, not one track. `01TREE01.DAT`
  uses the same 8-byte `GPLB` and 2-byte `TPLB` layout as playlists: the group
  id is the 1-based `GPFB` slot, and the start index bounds the track-id run.
- `03GINF03.DAT` (album-name tree) is a short `0x90` record with only `TIT2`.
  It has no picture tags. `04CNTINF.DAT` has no picture tags either.
- The NW-S700 manual: jackets are album art registered in SonicStage; jackets
  registered on playlists do not appear on the player. Jacket Mode can hide
  them. Sony support article S1110278023278: SonicStage accepts JPEG, GIF, and
  BMP, and a trailing space on the album or artist name can stop a jacket from
  being transferred.
- SonicStage OMGAUDIO artwork files are documented as
  `OMGAUDIO/20Pxx/1G<6 hex digits><suffix>.JPG`, suffixes `P0`, `01`, and `02`
  (podkit's NW-HD notes). `P0` is described there as the preview. This engine
  did not find a separate jacket DAT (`08PICINF` or similar) in this repo,
  in sonydb, or in `FILE_FORMAT_v2.txt`, which stops at `05CIDLST.DAT`.

## Assumed, and left byte-identical

- **PICP text.** No public capture shows the bytes SonicStage stores in `PICP`.
  This writer stores the relative path `20P00/1G<6 uppercase hex>P0.JPG` as
  UTF-16BE in the `PICP` text area, and reads a group as having a jacket only
  when `PICP` or else `PIC0` matches
  `20Pxx/1G<6 hex>(P0|01|02).JPG`. Firmware may expect a different pointer
  (a content id, a bare filename, or a `04CNTINF` link). That link is **not**
  implemented. Picture ids are allocated from existing `1G` names, not from
  track content ids.
- **Foreign pointers.** `jacket-set` and `jacket-clear` refuse the group when
  `PICP` or `PIC0` holds a non-empty string that is not one of those managed
  paths. The refusal is a fatal event with no `code`. The table, the sidecars,
  and the journal are left untouched. A foreign value is never cleared.
  Uniform single-byte padding, such as the `0x3C` fill in the tests, is not a
  pointer string and stays byte-identical.
- **PIC0.** Its meaning is unconfirmed. It is not rewritten unless its text is
  a managed path equal to the `PICP` path being removed. Otherwise those bytes
  stay as they were, including the `0x3C` padding used in the tests.
- **Variants.** Only `20P00` and the `P0` suffix are written. `01` and `02`
  files, and any other `20Pxx` folder, are not rewritten. Their pixel sizes
  are not documented.
- **Case.** Sidecar lookups are uppercase-only. On a case-sensitive mount a
  lowercase `20p00/...` file is not found and can be left orphaned. FAT, which
  the player uses, is case-insensitive, so this is deferred.
- **Image limits.** The S705 manual states no pixel or byte cap. This engine
  reads width and height from the JPEG header with `ImageReader` before it
  decodes pixels, for every start-of-frame the reader understands, including
  progressive. An image over 4096 pixels on a side, or over 4 megapixels, is
  rejected before decode. A baseline (`SOF0`) JPEG up to 240 pixels on the
  longer edge and 128 KiB stored is kept byte-identical. A progressive JPEG,
  or a baseline JPEG over that edge or byte cap, is scaled and re-encoded as
  baseline JPEG. The input file may be at most 8 MiB. GIF and BMP are rejected
  even though SonicStage accepts them: the on-disk sidecar form in the notes
  above is JPEG, and this tree has no GIF/BMP codec.
- **Full library rebuild.** `add` / `del` still regenerate `03GINF01.DAT` from
  track metadata and write empty `PICP`/`PIC0` slots. That pre-existing rebuild
  does not copy jacket slots forward.

Bytes outside the edited record's `PICP` text (and a `PIC0` text cleared only
in the case above) are copied through. Header padding, the record key, tag
names, the encoding word, other groups, `01TREE01.DAT`, and unreferenced files
stay byte-identical. A group whose `PICP` magic or encoding is not the layout
above is refused before a write.

## Journal

`jacket-set` and `jacket-clear` call `OmgaudioJournal.commit` with the patched
`03GINF01.DAT` and, when a managed JPEG is added or removed, an audio-shaped
journal entry for that relative path (temp file, then rename). Nothing in the
live tree is replaced until the `commit` marker is durable. `playlist-recover`
rolls the journal forward when the marker is present and discards it when it is
not. A crash before the marker leaves the previous table and the previous JPEG;
a crash after it, once recovered, leaves the new pair. An `Error`, including
`OutOfMemoryError`, thrown after the journal directory exists and before the
commit marker discards that directory. The live files stay as they were, and
the next jacket write is not refused.

Cleanup deletes the `commit` marker first (`cleanup`), then renames the journal
directory to `.jsymphonic-playlist-transaction.retired` and removes that copy
(`cleanup-retired`). A crash at `cleanup` still looks committed, so recover
rolls forward. A crash at `cleanup-retired` no longer looks committed: the live
tree is already the new snapshot, and recover discards the directory instead of
rolling the JPEG back. Commit and recover also delete leftover
`*.jsymphonic-tmp` files. An empty `20P00` directory can remain after a
rolled-back add, which is the same parent-directory behavior the journal
already has for audio folders. A bad jacket image is rejected before any
journal write and is a `fatal` event with no `code`.

## Verification

`mvn test` includes the jacket round trip, untouched-byte preservation, invalid
JPEG rejection, and an interruption at every journal step followed by
`OmgaudioJournal.recover`. Synthetic JPEGs are generated in temporary
directories. Do not point the tests at a live player or a real cover dump.
Reading the bytes back does not prove the NW-S705 firmware will display the
picture; that still needs a hardware check against a SonicStage capture of the
`PICP` bytes.
