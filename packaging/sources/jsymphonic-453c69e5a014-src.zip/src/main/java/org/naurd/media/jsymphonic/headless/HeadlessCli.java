/*
 * HeadlessCli.java
 *
 * Headless command-line entry point for JSymphonic, added for Walkman Bridge
 * (https://github.com/JbawbyJ/walkman-bridge). Drives the existing non-GUI device layer
 * (NWOmgaudio / NWGeneric) and reports progress as JSON-lines on stdout so a
 * wrapping process can show a friendly UI. Human-readable logging stays on
 * stderr. Exit codes: 0 = success, 1 = failure (a {"event":"fatal"} line is
 * emitted first when possible), 2 = usage error.
 *
 * Invocation (the GUI remains the jar's default main class):
 *   java -cp jsymphonic-<v>-jar-with-dependencies.jar \
 *        org.naurd.media.jsymphonic.headless.HeadlessCli <command> [options]
 *
 * Commands:
 *   info --device <mount>                      device state summary
 *   list --device <mount>                      one "track" event per title
 *   add  --device <mount> <file> [<file>...]   import files, commit database
 *   del  --device <mount> --id <id>            delete one title, commit database
 *
 * Options:
 *   --generation <3..8>   JSymphonic device generation (default 7 = NW-S60x/S70x
 *                         family, no DvID.DAT key needed)
 *   --idle-timeout <sec>  abort if a transfer emits no events for this long
 *                         (default 300)
 *
 * Stdout is reserved for JSON-lines. Any leftover System.out traffic from the
 * device layer is redirected to stderr for the duration of a run. A transfer
 * step that finishes with a non-empty error (including a Windows delete that
 * could not remove the file) is treated as failure: fatal + exit 1, no "done".
 *
 * This file is part of JSymphonic and distributed under the terms of the GPL,
 * like the rest of the project.
 */

package org.naurd.media.jsymphonic.headless;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.Base64;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

import org.naurd.media.jsymphonic.device.sony.nw.JacketDatabase;
import org.naurd.media.jsymphonic.device.sony.nw.NWGeneric;
import org.naurd.media.jsymphonic.device.sony.nw.NWGenericListener;
import org.naurd.media.jsymphonic.device.sony.nw.NWOmgaudio;
import org.naurd.media.jsymphonic.device.sony.nw.NativePlaylistDatabase;
import org.naurd.media.jsymphonic.device.sony.nw.OmgaudioJournal;
import org.naurd.media.jsymphonic.title.Title;
import org.naurd.media.jsymphonic.toolBox.JSymphonicMap;

public class HeadlessCli {

    private static PrintStream out; // UTF-8 stdout, JSON-lines only
    private static PrintStream err; // usage / human-readable errors

    public static void main(String[] args) {
        // Never let a stray dialog block a headless run; the GUI entry point is
        // unaffected because it runs from its own main().
        System.setProperty("java.awt.headless", "true");

        System.exit(run(args, utf8Stream(FileDescriptor.out, System.out),
                utf8Stream(FileDescriptor.err, System.err)));
    }

    /**
     * Testable entry: same argument handling and JSON-lines protocol as main(),
     * but returns the process exit code instead of calling System.exit.
     * Redirects System.out to {@code logErr} so leftover debug prints cannot
     * corrupt the JSON stream on {@code jsonOut}.
     */
    public static int run(String[] args, PrintStream jsonOut, PrintStream logErr) {
        System.setProperty("java.awt.headless", "true");
        out = jsonOut;
        err = logErr;
        PrintStream previousOut = System.out;
        System.setOut(logErr);
        try {
            return runImpl(args);
        } catch (Exit e) {
            return e.code;
        } finally {
            System.setOut(previousOut);
        }
    }

    private static PrintStream utf8Stream(FileDescriptor fd, PrintStream fallback) {
        try {
            return new PrintStream(new FileOutputStream(fd), true, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            return fallback; // pre-UTF-8 fallback; ASCII JSON still valid
        }
    }

    private static int runImpl(String[] args) {
        if (args.length < 1) {
            usage();
            throw new Exit(2);
        }

        String command = args[0];
        String device = null;
        String id = null;
        String playlistName = null;
        String encodedPlaylistName = null;
        String playlistTracks = null;
        String album = null;
        String encodedAlbum = null;
        String image = null;
        boolean inspectJournal = false;
        int generation = NWGeneric.GENERATION_7;
        long idleTimeoutSec = 300;
        List<String> positional = new ArrayList<String>();

        for (int i = 1; i < args.length; i++) {
            String a = args[i];
            if ("--device".equals(a) && i + 1 < args.length) {
                device = args[++i];
            } else if ("--id".equals(a) && i + 1 < args.length) {
                id = args[++i];
            } else if ("--name".equals(a) && i + 1 < args.length) {
                playlistName = args[++i];
            } else if ("--name-base64".equals(a) && i + 1 < args.length) {
                encodedPlaylistName = args[++i];
            } else if ("--tracks".equals(a) && i + 1 < args.length) {
                playlistTracks = args[++i];
            } else if ("--album".equals(a) && i + 1 < args.length) {
                album = args[++i];
            } else if ("--album-base64".equals(a) && i + 1 < args.length) {
                encodedAlbum = args[++i];
            } else if ("--image".equals(a) && i + 1 < args.length) {
                image = args[++i];
            } else if ("--inspect".equals(a)) {
                inspectJournal = true;
            } else if ("--generation".equals(a) && i + 1 < args.length) {
                try {
                    generation = Integer.parseInt(args[++i]);
                } catch (NumberFormatException e) {
                    usage();
                    throw new Exit(2);
                }
            } else if ("--idle-timeout".equals(a) && i + 1 < args.length) {
                try {
                    idleTimeoutSec = Long.parseLong(args[++i]);
                } catch (NumberFormatException e) {
                    usage();
                    throw new Exit(2);
                }
            } else if (a.startsWith("--")) {
                usage();
                throw new Exit(2);
            } else {
                positional.add(a);
            }
        }

        if (device == null) {
            usage();
            throw new Exit(2);
        }
        if (generation < NWGeneric.GENERATION_3 || generation > NWGeneric.GENERATION_VAIO) {
            fatal("Unsupported generation " + generation + " (expected 3..8).");
        }

        // Validate the mount before constructing the device object: the
        // NWOmgaudio constructor's own invalid-path branch leaves the database
        // null, which only fails later and less clearly.
        File mount = new File(device);
        File omgaudio = new File(mount, "OMGAUDIO");
        if (!omgaudio.isDirectory()) {
            omgaudio = new File(mount, "omgaudio");
        }
        if (!omgaudio.isDirectory()) {
            fatal("No OMGAUDIO directory under " + mount.getAbsolutePath()
                    + " - is this really the Walkman mount?");
        }

        try {
            if (encodedPlaylistName != null) {
                if (playlistName != null) { usage(); throw new Exit(2); }
                playlistName = decodePlaylistName(encodedPlaylistName);
            }
            if (encodedAlbum != null) {
                if (album != null) { usage(); throw new Exit(2); }
                album = decodeUtf8Base64(encodedAlbum, "album name");
            }
            if ("jackets".equals(command) || "jacket-set".equals(command) || "jacket-clear".equals(command)) {
                if (inspectJournal || playlistName != null || playlistTracks != null || !positional.isEmpty()) {
                    usage(); throw new Exit(2);
                }
                runJackets(command, omgaudio, id, album, image);
            } else if (album != null || image != null) {
                usage();
                throw new Exit(2);
            } else if ("playlists".equals(command) || command.startsWith("playlist-")) {
                if (inspectJournal && !"playlist-recover".equals(command)) { usage(); throw new Exit(2); }
                runPlaylists(command, mount, omgaudio, generation, id, playlistName, playlistTracks, positional, inspectJournal);
            } else if (playlistName != null || playlistTracks != null || inspectJournal) {
                usage();
                throw new Exit(2);
            } else if ("info".equals(command)) {
                runInfo(mount, omgaudio, generation);
            } else if ("list".equals(command)) {
                runList(mount, omgaudio, generation);
            } else if ("add".equals(command)) {
                if (positional.isEmpty()) {
                    usage();
                    throw new Exit(2);
                }
                runAdd(mount, generation, positional, idleTimeoutSec);
            } else if ("del".equals(command)) {
                if (id == null) {
                    usage();
                    throw new Exit(2);
                }
                runDel(mount, generation, id, idleTimeoutSec);
            } else {
                usage();
                throw new Exit(2);
            }
        } catch (Exit e) {
            throw e;
        } catch (NativePlaylistDatabase.Fatal e) {
            OmgaudioJournal.RollbackFailed wrapped = rollbackFailed(e);
            if (wrapped != null) fatalRollback(wrapped);
            fatal("IOException: " + String.valueOf(e.getMessage()), e.code);
        } catch (OmgaudioJournal.FileLocked e) {
            String relative = e.relative;
            fatal("Device file is locked", NWOmgaudio.DEVICE_FILE_LOCKED,
                    relative == null ? null : omgaudio.getName() + "/" + relative);
        } catch (OmgaudioJournal.FileReadOnly e) {
            String relative = e.relative;
            fatal("Device file is read-only", NWOmgaudio.DEVICE_FILE_READ_ONLY,
                    relative == null ? null : omgaudio.getName() + "/" + relative);
        } catch (OmgaudioJournal.ProbeRestoreFailed e) {
            fatal("Device file probe could not be restored", NWOmgaudio.DEVICE_PROBE_RESTORE_FAILED,
                    mountRelative(omgaudio, e.relative), mountRelative(omgaudio, e.probeRelative));
        } catch (OmgaudioJournal.ProbeConflict e) {
            fatal("Device file probe conflicts with the track", NWOmgaudio.DEVICE_PROBE_CONFLICT,
                    mountRelative(omgaudio, e.relative), mountRelative(omgaudio, e.probeRelative));
        } catch (OmgaudioJournal.RollbackFailed e) {
            fatalRollback(e);
        } catch (Exception e) {
            OmgaudioJournal.RollbackFailed rollback = rollbackFailed(e);
            if (rollback != null) fatalRollback(rollback);
            fatal(e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()), fatalCode(e));
        } catch (Error e) {
            // OutOfMemoryError and other Errors are a JSON fatal with no code or path.
            // Before the commit marker, the journal has already discarded its directory.
            fatal(e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
        }
        return 0;
    }

    private static void usage() {
        PrintStream dest = err != null ? err : System.err;
        dest.println("Usage: HeadlessCli <info|list|add|del> --device <mount>"
                + " [--generation <3..8>] [--idle-timeout <sec>] [--id <id>] [files...]");
        dest.println("Native playlists: playlists --device <mount>; playlist-create --device <mount> --name-base64 <UTF-8 base64> [track IDs...]");
        dest.println("playlist-update --device <mount> --id <id> [--name-base64 <UTF-8 base64>] [--tracks <comma-separated IDs>]");
        dest.println("playlist-delete --device <mount> --id <id>. --name <text> is also accepted; use base64 for Unicode on Windows.");
        dest.println("playlist-repair --device <mount> prunes dangling track references.");
        dest.println("playlist-recover --device <mount> [--inspect] reports or applies a leftover playlist journal.");
        dest.println("Album jackets: jackets --device <mount>; jacket-set --device <mount> (--id <track-id> | --album-base64 <UTF-8 base64>) --image <jpeg>");
        dest.println("jacket-clear --device <mount> (--id <track-id> | --album-base64 <UTF-8 base64>). --album <text> is also accepted.");
    }

    private static String fatalCode(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof OmgaudioJournal.RollbackFailed) return NWOmgaudio.DEVICE_ROLLBACK_FAILED;
            if (current instanceof NativePlaylistDatabase.Fatal) return ((NativePlaylistDatabase.Fatal) current).code;
            current = current.getCause();
        }
        return null;
    }

    /** Same line add/delete emits. {@code path} stays absent: this failure has no file path. */
    private static void fatalRollback(OmgaudioJournal.RollbackFailed ignored) {
        fatal("Database update failed; incomplete recovery requires a verified backup",
                NWOmgaudio.DEVICE_ROLLBACK_FAILED, null);
    }

    /** Walk causes the same way {@link #fatalCode} does, so a wrapper still maps to the rollback fatal. */
    private static OmgaudioJournal.RollbackFailed rollbackFailed(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (current instanceof OmgaudioJournal.RollbackFailed) return (OmgaudioJournal.RollbackFailed) current;
            current = current.getCause();
        }
        return null;
    }

    /* ---------------------------------------------------------------- */
    /* Commands                                                          */
    /* ---------------------------------------------------------------- */

    private static NWOmgaudio mount(File mount, int generation, EventListener listener, boolean restoreProbes) {
        NWOmgaudio dev = new NWOmgaudio(mount.getAbsolutePath(), "walkman", "",
                null, generation, listener, mount.getAbsolutePath(), restoreProbes);
        dev.setAlwaysTranscode(false);
        dev.setTranscodeBitrate(192);
        File temp = new File(System.getProperty("java.io.tmpdir"), "walkman-bridge-jsym");
        temp.mkdirs();
        dev.setTempPath(temp.getAbsolutePath());
        return dev;
    }

    private static void runPlaylists(String command, File mountDir, File directory, int generation,
            String id, String name, String encodedTracks, List<String> positional, boolean inspectJournal) throws IOException {
        if (!("playlists".equals(command) || "playlist-create".equals(command)
                || "playlist-update".equals(command) || "playlist-delete".equals(command)
                || "playlist-repair".equals(command) || "playlist-recover".equals(command))) {
            usage(); throw new Exit(2);
        }
        if (("playlists".equals(command) && (id != null || name != null || encodedTracks != null || !positional.isEmpty()))
                || ("playlist-create".equals(command) && (name == null || id != null || encodedTracks != null))
                || ("playlist-update".equals(command) && (id == null || !positional.isEmpty() || (name == null && encodedTracks == null)))
                || ("playlist-delete".equals(command) && (id == null || name != null || encodedTracks != null || !positional.isEmpty()))
                || ("playlist-repair".equals(command) && (id != null || name != null || encodedTracks != null || !positional.isEmpty()))
                || ("playlist-recover".equals(command) && (id != null || name != null || encodedTracks != null || !positional.isEmpty()))) {
            usage(); throw new Exit(2);
        }
        if ("playlist-recover".equals(command)) {
            runRecover(directory, inspectJournal);
            return;
        }
        NativePlaylistDatabase db = NativePlaylistDatabase.read(directory);
        if ("playlist-repair".equals(command)) {
            NWOmgaudio device = mount(mountDir, generation, new EventListener(), true);
            if (!device.trackLibraryLoaded()) {
                fatal("Playlist repair refused: the device track list is empty or the library did not load",
                        NativePlaylistDatabase.Fatal.LIBRARY_NOT_LOADED);
            }
            Set<Integer> available = new HashSet<Integer>();
            for (Object value : device.getTitlesInMap().values()) available.add((Integer) value);
            int prunedCount = 0;
            Set<Integer> prunedTracks = new TreeSet<Integer>();
            Set<Integer> changedPlaylists = new TreeSet<Integer>();
            for (NativePlaylistDatabase.Playlist playlist : db.list()) {
                int removed = 0;
                for (Integer track : playlist.trackIds) {
                    if (available.contains(track)) continue;
                    prunedCount++;
                    removed++;
                    prunedTracks.add(track);
                }
                if (removed > 0) changedPlaylists.add(Integer.valueOf(playlist.id));
            }
            db.retainTracks(available);
            if (db.hasChanges()) db.save();
            emit("{\"event\":\"playlistRepair\",\"prunedCount\":" + prunedCount
                    + ",\"prunedTrackIds\":[" + decimalList(prunedTracks)
                    + "],\"playlistIds\":[" + decimalList(changedPlaylists) + "]}");
            for (NativePlaylistDatabase.Playlist playlist : db.list()) emitPlaylist(playlist);
            emit("{\"event\":\"done\"}");
            return;
        }
        if ("playlists".equals(command)) {
            warnPendingProbes(directory);
            for (NativePlaylistDatabase.Playlist playlist : db.list()) emitPlaylist(playlist);
            emit("{\"event\":\"playlistsEnd\",\"count\":" + db.list().size() + "}");
            return;
        }
        NWOmgaudio device = mount(mountDir, generation, new EventListener(), true);
        Set<Integer> available = new HashSet<Integer>();
        for (Object value : device.getTitlesInMap().values()) available.add((Integer) value);
        db.validateReferences(available);
        NativePlaylistDatabase.Playlist result = null;
        if ("playlist-create".equals(command)) {
            result = db.create(name, parseTrackIds(positional), available);
        } else if ("playlist-update".equals(command)) {
            List<Integer> tracks = encodedTracks == null ? null : parseTrackIds(encodedTracks.isEmpty()
                    ? new ArrayList<String>() : java.util.Arrays.asList(encodedTracks.split(",", -1)));
            result = db.update(parseNativeId(id), name, tracks, available);
        } else {
            db.delete(parseNativeId(id));
        }
        db.save();
        if (result != null) emitPlaylist(result);
        emit("{\"event\":\"done\"}");
    }

    private static void runRecover(File directory, boolean inspectOnly) throws IOException {
        if (inspectOnly) warnPendingProbes(directory);
        OmgaudioJournal.Report before = OmgaudioJournal.inspect(directory.toPath());
        String outcome = null;
        if (!inspectOnly) {
            OmgaudioJournal.recover(directory.toPath());
            outcome = !before.pending ? OmgaudioJournal.OUTCOME_NONE
                    : before.committed ? OmgaudioJournal.OUTCOME_ROLLED_FORWARD
                    : OmgaudioJournal.OUTCOME_DISCARDED;
        }
        OmgaudioJournal.Report after = inspectOnly ? before : OmgaudioJournal.inspect(directory.toPath());
        StringBuilder files = new StringBuilder();
        for (String file : before.files) {
            if (files.length() > 0) files.append(',');
            files.append(json(file));
        }
        StringBuilder line = new StringBuilder();
        line.append("{\"event\":\"playlistJournal\",\"state\":").append(json(before.state));
        if (outcome != null) line.append(",\"outcome\":").append(json(outcome));
        line.append(",\"pending\":").append(after.pending)
                .append(",\"committed\":").append(before.committed)
                .append(",\"action\":").append(json(before.action))
                .append(",\"files\":[").append(files).append("]")
                .append(",\"fingerprint\":").append(before.fingerprint == null ? "null" : json(before.fingerprint))
                .append(",\"library_fingerprint\":").append(json(before.libraryFingerprint)).append('}');
        emit(line.toString());
        emit("{\"event\":\"done\"}");
    }

    private static int parseNativeId(String value) throws IOException {
        if (value == null || !value.matches("[1-9][0-9]{0,4}")) throw new IOException("Invalid native database ID");
        int id = Integer.parseInt(value);
        if (id > 65535) throw new IOException("Native database ID exceeds 65535");
        return id;
    }

    private static String decodePlaylistName(String encoded) throws IOException {
        return decodeUtf8Base64(encoded, "playlist name");
    }

    private static String decodeUtf8Base64(String encoded, String label) throws IOException {
        if (encoded.length() > 1024) throw new IOException("Encoded " + label + " is too long");
        try {
            byte[] bytes = Base64.getDecoder().decode(encoded);
            if (bytes.length > 240) throw new IOException("Encoded " + label + " is too long");
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
        } catch (IllegalArgumentException e) {
            throw new IOException("Invalid base64 " + label, e);
        } catch (CharacterCodingException e) {
            throw new IOException("Invalid UTF-8 " + label, e);
        }
    }

    private static String decimalList(Set<Integer> values) {
        StringBuilder result = new StringBuilder();
        for (Integer value : values) {
            if (result.length() > 0) result.append(',');
            result.append(value.intValue());
        }
        return result.toString();
    }

    private static List<Integer> parseTrackIds(List<String> values) throws IOException {
        if (values.size() > 65534) throw new IOException("Too many playlist members");
        List<Integer> result = new ArrayList<Integer>();
        for (String value : values) result.add(parseNativeId(value));
        return result;
    }

    private static void runJackets(String command, File directory, String id, String album, String image) throws IOException {
        boolean set = "jacket-set".equals(command);
        boolean clear = "jacket-clear".equals(command);
        if (!set && !clear && !"jackets".equals(command)) { usage(); throw new Exit(2); }
        if (("jackets".equals(command) && (id != null || album != null || image != null))
                || (set && (image == null || (album == null) == (id == null)))
                || (clear && (image != null || (album == null) == (id == null)))) {
            usage(); throw new Exit(2);
        }
        if ("jackets".equals(command)) {
            warnPendingProbes(directory);
            JacketDatabase db = JacketDatabase.read(directory);
            List<JacketDatabase.Jacket> jackets = db.list();
            for (JacketDatabase.Jacket jacket : jackets) emitJacket(jacket);
            emit("{\"event\":\"jacketsEnd\",\"count\":" + jackets.size() + "}");
            return;
        }
        OmgaudioJournal.restoreProbeSiblings(directory.toPath());
        JacketDatabase db = JacketDatabase.read(directory);
        JacketDatabase.Jacket result = set
                ? (album != null ? db.setByAlbum(album, new File(image).toPath()) : db.setByTrack(parseNativeId(id), new File(image).toPath()))
                : (album != null ? db.clearByAlbum(album) : db.clearByTrack(parseNativeId(id)));
        db.save();
        emitJacket(result);
        emit("{\"event\":\"done\"}");
    }

    private static void emitJacket(JacketDatabase.Jacket jacket) {
        StringBuilder ids = new StringBuilder();
        for (Integer track : jacket.trackIds) {
            if (ids.length() > 0) ids.append(',');
            ids.append(json(track.toString()));
        }
        emit("{\"event\":\"jacket\",\"slot\":" + json(Integer.toString(jacket.slot))
                + ",\"album\":" + json(jacket.album)
                + ",\"artist\":" + json(jacket.artist)
                + ",\"trackIds\":[" + ids + "]"
                + ",\"path\":" + (jacket.path == null ? "null" : json(jacket.path))
                + ",\"bytes\":" + jacket.bytes + "}");
    }

    private static void emitPlaylist(NativePlaylistDatabase.Playlist playlist) {
        StringBuilder ids = new StringBuilder();
        for (Integer id : playlist.trackIds) { if (ids.length() > 0) ids.append(','); ids.append(json(id.toString())); }
        emit("{\"event\":\"playlist\",\"id\":" + json(Integer.toString(playlist.id))
                + ",\"name\":" + json(playlist.name) + ",\"trackIds\":[" + ids + "]}");
    }

    private static void runInfo(File mountDir, File omgaudio, int generation) throws IOException {
        warnPendingProbes(omgaudio);
        NWOmgaudio dev = mount(mountDir, generation, new EventListener(), false);
        int count = dev.getTitles().length;
        emit("{\"event\":\"device\",\"ok\":true,\"generation\":" + dev.getGeneration()
                + ",\"trackCount\":" + count
                + ",\"freeBytes\":" + mountDir.getUsableSpace()
                + ",\"totalBytes\":" + mountDir.getTotalSpace() + "}");
    }

    private static void runList(File mountDir, File omgaudio, int generation) throws IOException {
        warnPendingProbes(omgaudio);
        NWOmgaudio dev = mount(mountDir, generation, new EventListener(), false);
        JSymphonicMap titles = dev.getTitlesInMap();
        int count = 0;
        for (Iterator it = titles.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            Title title = (Title) entry.getKey();
            Object idx = entry.getValue();
            emit("{\"event\":\"track\""
                    + ",\"id\":" + json(String.valueOf(idx))
                    + ",\"title\":" + json(title.getTitle())
                    + ",\"artist\":" + json(title.getArtist())
                    + ",\"album\":" + json(title.getAlbum())
                    + ",\"durationSeconds\":" + (title.getLength() / 1000)
                    + ",\"format\":" + json(title.getFormatAsString())
                    + ",\"sizeBytes\":" + title.getFileSize() + "}");
            count++;
        }
        emit("{\"event\":\"listEnd\",\"count\":" + count + "}");
    }

    private static void runAdd(File mountDir, int generation, List<String> files,
            long idleTimeoutSec) throws InterruptedException {
        // Validate the whole batch before mounting for a write: mounting may
        // restore a pending probe. Invalid input must not mutate even that state.
        File[] toImport = new File[files.size()];
        for (int i = 0; i < files.size(); i++) {
            File f = new File(files.get(i));
            if (!f.isFile()) {
                fatal("File not found: " + f.getAbsolutePath());
            }
            try {
                Title.getTitleFromFile(f);
            } catch (org.naurd.media.jsymphonic.title.UnknowFileTypeException unsupported) {
                fatal("Unsupported input format: " + f.getAbsolutePath() + ". No files were imported.");
            }
            toImport[i] = f;
        }

        EventListener listener = new EventListener();
        NWOmgaudio dev = mount(mountDir, generation, listener, true);
        emit("{\"event\":\"start\",\"files\":" + toImport.length + "}");
        int scheduled = dev.scheduleImport(toImport, true);
        if (scheduled == -2) {
            fatal("The player is full.");
        }
        if (scheduled == -1) {
            fatal("Input scan failed: unsupported format. No files were imported.");
        }

        commitAndAwait(dev, listener, idleTimeoutSec);
        emit("{\"event\":\"done\"}");
    }

    private static void runDel(File mountDir, int generation, String id,
            long idleTimeoutSec) throws InterruptedException {
        EventListener listener = new EventListener();
        NWOmgaudio dev = mount(mountDir, generation, listener, true);

        Title title;
        try {
            title = (Title) dev.getTitlesInMap().getKey(Integer.valueOf(id));
        } catch (NumberFormatException e) {
            title = null;
        }
        if (title == null) {
            fatal("No track with id " + id + " on the device.");
        }

        emit("{\"event\":\"start\",\"files\":1}");
        dev.scheduleDeletion(title);
        commitAndAwait(dev, listener, idleTimeoutSec);
        emit("{\"event\":\"done\"}");
    }

    /**
     * applyChanges() spawns worker threads and returns immediately; completion
     * is only signalled through the listener's transferTermination(). If the
     * worker dies without signalling (its catch block merely logs), the idle
     * watchdog turns silence into a clean failure instead of a hang.
     *
     * A step that finishes with a non-empty error (for example a title file
     * that Windows could not delete) is a failed transfer: fatal + exit 1,
     * no "done" event.
     */
    private static void commitAndAwait(NWGeneric dev, EventListener listener,
            long idleTimeoutSec) throws InterruptedException {
        listener.touch();
        dev.applyChanges();
        while (true) {
            if (listener.finished.await(1, TimeUnit.SECONDS)) {
                String code = listener.fatalCode.get();
                if (NWOmgaudio.DEVICE_FILE_LOCKED.equals(code)) {
                    fatal("Device file is locked", code, listener.fatalPath.get());
                }
                if (NWOmgaudio.DEVICE_FILE_READ_ONLY.equals(code)) {
                    fatal("Device file is read-only", code, listener.fatalPath.get());
                }
                if (NWOmgaudio.DEVICE_ROLLBACK_FAILED.equals(code)) {
                    fatal("Database update failed; incomplete recovery requires a verified backup", code, null);
                }
                if (NWOmgaudio.DEVICE_PROBE_RESTORE_FAILED.equals(code)) {
                    fatal("Device file probe could not be restored", code,
                            listener.fatalPath.get(), listener.fatalProbePath.get());
                }
                if (NWOmgaudio.DEVICE_PROBE_CONFLICT.equals(code)) {
                    fatal("Device file probe conflicts with the track", code,
                            listener.fatalPath.get(), listener.fatalProbePath.get());
                }
                String stepError = listener.stepError.get();
                if (stepError != null) {
                    fatal(stepError, code);
                }
                return;
            }
            long idleMs = System.currentTimeMillis() - listener.lastEventMillis.get();
            if (idleMs > idleTimeoutSec * 1000L) {
                fatal("Transfer produced no progress for " + idleTimeoutSec
                        + "s - aborting. The device database may be incomplete;"
                        + " re-run 'list' to check.");
            }
        }
    }

    /* ---------------------------------------------------------------- */
    /* Listener: JSymphonic callbacks -> JSON-lines                      */
    /* ---------------------------------------------------------------- */

    static class EventListener implements NWGenericListener {
        final CountDownLatch finished = new CountDownLatch(1);
        final AtomicLong lastEventMillis = new AtomicLong(System.currentTimeMillis());
        final AtomicReference<String> stepError = new AtomicReference<String>();
        final AtomicReference<String> fatalCode = new AtomicReference<String>();
        final AtomicReference<String> fatalPath = new AtomicReference<String>();
        final AtomicReference<String> fatalProbePath = new AtomicReference<String>();

        public void transferFatalCode(String code) {
            if (code != null && !code.isEmpty()) fatalCode.compareAndSet(null, code);
        }

        public void transferFatalDetail(String code, String path) {
            if (code != null && !code.isEmpty()) fatalCode.compareAndSet(null, code);
            if (path != null) fatalPath.compareAndSet(null, path);
        }

        public void transferFatalProbe(String code, String path, String probePath) {
            transferFatalDetail(code, path);
            if (probePath != null) fatalProbePath.compareAndSet(null, probePath);
        }

        void touch() {
            lastEventMillis.set(System.currentTimeMillis());
        }

        private void recordStepError(String message) {
            if (message == null || message.isEmpty()) {
                return;
            }
            String cleaned = stripHtml(message);
            if (cleaned.isEmpty()) {
                cleaned = message;
            }
            stepError.compareAndSet(null, cleaned);
        }

        private static String stepName(int step) {
            switch (step) {
                case NWGenericListener.EXPORTING: return "export";
                case NWGenericListener.DELETING: return "delete";
                case NWGenericListener.IMPORTING: return "transfer";
                case NWGenericListener.DECODING: return "decode";
                case NWGenericListener.ENCODING: return "encode";
                case NWGenericListener.UPDATING: return "update";
                default: return "step" + step;
            }
        }

        public void transferInitialization(int numberOfExportFiles, int numberOfDeleteFiles,
                int numberOfDecodeFiles, int numberOfEncodeFiles, int numberOfTransferFiles,
                int numberOfDbFiles) {
            touch();
            emit("{\"event\":\"plan\",\"export\":" + numberOfExportFiles
                    + ",\"delete\":" + numberOfDeleteFiles
                    + ",\"decode\":" + numberOfDecodeFiles
                    + ",\"encode\":" + numberOfEncodeFiles
                    + ",\"transfer\":" + numberOfTransferFiles
                    + ",\"database\":" + numberOfDbFiles + "}");
        }

        public void transferTermination() {
            touch();
            finished.countDown();
        }

        public void transferStepStarted(int step) {
            touch();
            emit("{\"event\":\"step\",\"step\":\"" + stepName(step)
                    + "\",\"state\":\"started\",\"error\":null}");
        }

        public void transferStepFinished(int step, String errorMessage) {
            touch();
            recordStepError(errorMessage);
            String error = (errorMessage == null || errorMessage.isEmpty())
                    ? "null" : json(stripHtml(errorMessage));
            emit("{\"event\":\"step\",\"step\":\"" + stepName(step)
                    + "\",\"state\":\"finished\",\"error\":" + error + "}");
        }

        public void fileChanged(int step, String name) {
            touch();
            emit("{\"event\":\"file\",\"step\":\"" + stepName(step)
                    + "\",\"name\":" + json(name) + "}");
        }

        public void fileProgressChanged(int step, double value, double speed) {
            touch();
            emit("{\"event\":\"progress\",\"step\":\"" + stepName(step)
                    + "\",\"percent\":" + value + ",\"speedKBps\":" + speed + "}");
        }

        public void loadingInitialization(int numberOfFile) {
            touch();
            emit("{\"event\":\"scan\",\"files\":" + numberOfFile + "}");
        }

        public void loadingProgresChanged(double value) {
            touch();
        }

        public void showPlayerFullMsg() {
            touch();
            recordStepError("the player is full");
            emit("{\"event\":\"step\",\"step\":\"transfer\",\"state\":\"finished\","
                    + "\"error\":\"the player is full\"}");
        }
    }

    /* ---------------------------------------------------------------- */
    /* JSON-lines plumbing (no dependencies; Java 8)                     */
    /* ---------------------------------------------------------------- */

    private static synchronized void emit(String line) {
        out.println(line);
    }

    private static void fatal(String message) {
        fatal(message, null, null, null);
    }

    private static void fatal(String message, String code) {
        fatal(message, code, null, null);
    }

    /** {@code path} is omitted when null, so existing fatals keep their shape. */
    private static void fatal(String message, String code, String path) {
        fatal(message, code, path, null);
    }

    /** {@code probe_path} is omitted when null. */
    private static void fatal(String message, String code, String path, String probePath) {
        StringBuilder line = new StringBuilder();
        line.append("{\"event\":\"fatal\",\"message\":").append(json(message));
        if (code != null) line.append(",\"code\":").append(json(code));
        if (path != null) line.append(",\"path\":").append(json(path));
        if (probePath != null) line.append(",\"probe_path\":").append(json(probePath));
        line.append('}');
        emit(line.toString());
        throw new Exit(1);
    }

    private static String mountRelative(File omgaudio, String relative) {
        if (relative == null) return null;
        return omgaudio.getName() + "/" + relative;
    }

    /** Read commands report a leftover probe and do not rename it. */
    private static void warnPendingProbes(File omgaudio) throws IOException {
        String prefix = omgaudio.getName() + "/";
        for (OmgaudioJournal.PendingProbe probe : OmgaudioJournal.listPendingProbes(omgaudio.toPath())) {
            emit("{\"event\":\"warning\",\"code\":" + json(NWOmgaudio.DEVICE_PROBE_PENDING)
                    + ",\"path\":" + json(prefix + probe.relative)
                    + ",\"probe_path\":" + json(prefix + probe.probeRelative) + "}");
        }
    }

    /** Quote and escape a string for JSON. */
    static String json(String s) {
        if (s == null) {
            return "\"\"";
        }
        StringBuilder sb = new StringBuilder(s.length() + 8);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
        return sb.toString();
    }

    /** Flatten GUI HTML error strings into a single-line CLI message. */
    static String stripHtml(String s) {
        if (s == null || s.isEmpty()) {
            return "";
        }
        String plain = s.replaceAll("(?i)<br\\s*/?>", " ");
        plain = plain.replaceAll("<[^>]+>", "");
        plain = plain.replace("&nbsp;", " ");
        plain = plain.replace("&lt;", "<");
        plain = plain.replace("&gt;", ">");
        plain = plain.replace("&amp;", "&");
        return plain.replaceAll(" +", " ").trim();
    }

    private static final class Exit extends RuntimeException {
        final int code;

        Exit(int code) {
            this.code = code;
        }
    }
}
