package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AccessDeniedException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileSystemException;
import java.nio.file.FileSystemLoopException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.NotDirectoryException;
import java.nio.file.NotLinkException;
import java.nio.file.Path;
import java.nio.file.ReadOnlyFileSystemException;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;

/**
 * Write-ahead journal for OMGAUDIO playlist tables, base tables, 02TREINF and
 * the audio files an add or delete will publish with them.
 *
 * <p>Nothing in the live tree is replaced until a {@code commit} marker is
 * durable. A crash before that marker rolls back (the journal is discarded and
 * the live tree is left as it was). A crash after that marker rolls forward:
 * every staged database file is published with a temp file and rename, then
 * each audio add or delete is applied. {@link #recover} is idempotent.
 * {@link #inspect} only reads the journal.
 *
 * <p>Any {@link Throwable} other than {@link Interrupt} before the commit marker
 * is durable — including {@link RuntimeException} and {@link Error} such as
 * {@link OutOfMemoryError} — discards that uncommitted journal and is rethrown.
 * The next write is not blocked by {@code PLAYLIST_JOURNAL_PENDING}. After the
 * marker and before publication completes, an {@link IOException} or
 * {@link RuntimeException} other than {@link Interrupt} restores the staged
 * before-images. Cleanup failures after publication keep the new snapshot.
 * If that restore cannot
 * put every file back, the journal stays so inspect and recover can still run.
 * A hard stop (process death, or {@link Interrupt} from a test probe) leaves
 * the journal in place. Cleanup deletes the commit marker before it removes
 * anything else, then renames the journal directory aside, so a crash
 * mid-cleanup cannot look committed.
 *
 * <p>One audio file that cannot be published fails the whole batch. The staged
 * database already describes every add and delete in the batch; committing the
 * tables while leaving a locked file behind, or keeping the other audio files
 * without those tables, would split the library from the database. The device
 * stays on the previous consistent snapshot.
 */
public final class OmgaudioJournal {
    public static final String DIRECTORY = ".jsymphonic-playlist-transaction";
    /** Sibling left when a rename probe is interrupted after the file is moved aside. */
    static final String PROBE_SUFFIX = ".jsymphonic-probe";
    /** Sibling left behind when cleanup is interrupted after the journal is renamed aside. */
    static final String RETIRED = DIRECTORY + ".retired";
    public static final String STATE_NONE = "none";
    public static final String STATE_COMMITTED = "committed";
    public static final String STATE_UNCOMMITTED = "uncommitted";
    public static final String OUTCOME_NONE = "none";
    public static final String OUTCOME_ROLLED_FORWARD = "rolled_forward";
    public static final String OUTCOME_DISCARDED = "discarded";
    /** Test seam: the first publish after the commit marker throws. Cleared when it fires. */
    static volatile boolean failNextPublish;
    /** Test seam: restoring published files throws before any file is put back. Cleared when it fires. */
    static volatile boolean failRollbackRestore;
    /** Test seam: the next audio publish or delete is reported as locked. Cleared when it fires. */
    static volatile boolean lockAudioOnPublish;
    /** Test seam: the next path relativize fails as a different-root path. Cleared when it fires. */
    static volatile boolean failRelativize;
    /**
     * Test seam: the next copy of this payload throws before any byte is read.
     * Cleared when it fires. Null in production.
     */
    static volatile Path failPayloadRead;
    /**
     * Test seam: every probe rename-back throws until cleared. Unlike the one-shot
     * seams, this stays set so all of the bounded retries fail.
     */
    static volatile boolean failProbeRenameBack;
    /** Test seam: the next audio publish throws this exception once, then clears it. */
    static volatile IOException failAudioIo;
    /** Test seam: the next audio publish throws this unchecked exception once, then clears it. */
    static volatile RuntimeException failAudioUnchecked;
    /** Test seam: the audio destination is on write-protected media. */
    static volatile boolean readOnlyMedia;
    /** Rename-back tries this many times, sleeping {@link #PROBE_RENAME_BACKOFF_MS} between them. */
    static final int PROBE_RENAME_ATTEMPTS = 5;
    /** Gap between rename-back attempts. Four gaps over five attempts is about one second. */
    static final long PROBE_RENAME_BACKOFF_MS = 250L;
    /** Test seam: counts rename-back attempts. Reset at the start of each rename-back. */
    static volatile int probeRenameAttempts;
    /** Test seam: replaces {@link Thread#sleep} during rename-back. Null uses a real sleep. */
    static volatile ProbeBackoff probeBackoff;
    /** Windows ERROR_SHARING_VIOLATION. OpenJDK does not map this to its own type. */
    private static final int ERROR_SHARING_VIOLATION = 32;
    /** Windows ERROR_LOCK_VIOLATION. OpenJDK does not map this to its own type. */
    private static final int ERROR_LOCK_VIOLATION = 33;

    /** Injected pause between probe rename-back attempts. */
    interface ProbeBackoff {
        void sleep(long millis);
    }

    static final class FileSpec {
        final String name;
        final byte[] before;
        final byte[] next;
        FileSpec(String name, byte[] before, byte[] next) {
            this.name = name;
            this.before = before;
            this.next = next;
        }
    }

    static final class AudioSpec {
        final boolean delete;
        final String relative;
        final Path payload;
        AudioSpec(boolean delete, String relative, Path payload) {
            this.delete = delete;
            this.relative = relative;
            this.payload = payload;
        }
    }

    public static final class Report {
        public final boolean pending;
        public final boolean committed;
        /** {@code committed}, {@code uncommitted}, or {@code none}. */
        public final String state;
        public final String action;
        public final List<String> files;
        /** SHA-256 over journal entry names and bytes; null when no journal exists. */
        public final String fingerprint;
        /** SHA-256 over direct OMGAUDIO DAT names and bytes, including when no journal exists. */
        public final String libraryFingerprint;
        Report(boolean pending, boolean committed, String action, List<String> files,
                String fingerprint, String libraryFingerprint) {
            this.pending = pending;
            this.committed = committed;
            this.state = !pending ? STATE_NONE : committed ? STATE_COMMITTED : STATE_UNCOMMITTED;
            this.action = action;
            this.files = files;
            this.fingerprint = fingerprint;
            this.libraryFingerprint = libraryFingerprint;
        }
    }

    /**
     * The probe sibling is still on disk after the bounded rename-back. The
     * original location is {@link #relative}; the sibling is {@link #probeRelative}.
     * Both are OMGAUDIO-relative with forward slashes, or null when unknown.
     */
    public static final class ProbeRestoreFailed extends RuntimeException {
        public final String relative;
        public final String probeRelative;
        public ProbeRestoreFailed(String relative, String probeRelative) {
            this(relative, probeRelative, null);
        }
        public ProbeRestoreFailed(String relative, String probeRelative, Throwable cause) {
            super("Device file probe could not be restored", cause);
            this.relative = relative;
            this.probeRelative = probeRelative;
        }
    }

    /**
     * A {@code .jsymphonic-probe} sibling sits beside its original and the bytes
     * differ. Neither file is deleted. Paths match {@link ProbeRestoreFailed}.
     */
    public static final class ProbeConflict extends RuntimeException {
        public final String relative;
        public final String probeRelative;
        public ProbeConflict(String relative, String probeRelative) {
            super("Device file probe conflicts with the track");
            this.relative = relative;
            this.probeRelative = probeRelative;
        }
    }

    /** A probe sibling a read command should warn about, without renaming it. */
    public static final class PendingProbe {
        public final String relative;
        public final String probeRelative;
        PendingProbe(String relative, String probeRelative) {
            this.relative = relative;
            this.probeRelative = probeRelative;
        }
    }

    /** Test seam. Thrown by a probe to simulate process death at a journal step. */
    static final class Interrupt extends RuntimeException {
        final String step;
        Interrupt(String step) {
            super(step);
            this.step = step;
        }
    }

    interface Probe {
        void step(String name) throws IOException;
    }

    private OmgaudioJournal() {}

    static List<String> plan(List<FileSpec> files, List<AudioSpec> audio) {
        List<String> steps = new ArrayList<String>();
        steps.add("directory");
        steps.add("format");
        for (int i = 0; i < files.size(); i++) steps.add("before:" + files.get(i).name);
        for (int i = 0; i < files.size(); i++) steps.add("next:" + files.get(i).name);
        for (int i = 0; i < audio.size(); i++) steps.add("stage-audio:" + audio.get(i).relative);
        steps.add("manifest");
        steps.add("commit");
        for (int i = 0; i < files.size(); i++) steps.add("publish:" + files.get(i).name);
        for (int i = 0; i < audio.size(); i++)         steps.add("publish-audio:" + audio.get(i).relative);
        steps.add("cleanup");
        // Fired after the commit marker is gone and before the directory is removed.
        steps.add("cleanup-retired");
        return steps;
    }

    static String relativize(Path root, Path file) throws IOException {
        try {
            if (failRelativize) {
                failRelativize = false;
                throw new IllegalArgumentException("different file system roots");
            }
            Path rel = root.relativize(file.toAbsolutePath().normalize());
            String text = rel.toString().replace('\\', '/');
            if (text.isEmpty() || text.startsWith("/") || text.startsWith("../") || text.equals("..") || text.indexOf('\\') >= 0)
                throw new IOException("Audio path escapes OMGAUDIO");
            return text;
        } catch (IllegalArgumentException e) {
            throw new IOException("Device path is not on this mount");
        }
    }

    public static Report inspect(Path root) throws IOException {
        NativePlaylistDatabase.checkPath(root);
        Path journal = root.resolve(DIRECTORY);
        if (!Files.exists(journal)) return new Report(false, false, "none", new ArrayList<String>(),
                null, directoryFingerprint(root, true));
        NativePlaylistDatabase.checkPath(journal);
        if (!Files.isDirectory(journal)) throw new IOException("Journal is not a directory");
        NativePlaylistDatabase.checkPath(journal.resolve("format"));
        if (Files.exists(journal.resolve("format"))
                && (!Files.isRegularFile(journal.resolve("format"))
                || !"2".equals(new String(readBytes(journal.resolve("format")), StandardCharsets.UTF_8).trim())))
            throw new IOException("Unknown journal format; preserve the journal for reconciliation");
        boolean format2 = Files.isRegularFile(journal.resolve("format"));
        NativePlaylistDatabase.checkPath(journal.resolve("commit"));
        if (Files.exists(journal.resolve("commit")) && (!Files.isRegularFile(journal.resolve("commit"))
                || Files.size(journal.resolve("commit")) != 0))
            throw new IOException("Invalid journal commit marker");
        boolean marker = Files.isRegularFile(journal.resolve("commit"));
        boolean legacy = !format2 && Files.isRegularFile(journal.resolve("files.txt"))
                && Files.isRegularFile(journal.resolve("tree.next"))
                && Files.isRegularFile(journal.resolve("info.next"));
        boolean committed = marker || legacy;
        List<String> files = new ArrayList<String>();
        if (Files.isRegularFile(journal.resolve("files.txt"))) files.addAll(lines(journal.resolve("files.txt")));
        if (legacy && files.isEmpty()) {
            files.add("tree");
            files.add("info");
        }
        if (Files.isRegularFile(journal.resolve("audio.txt"))) {
            for (String line : lines(journal.resolve("audio.txt"))) {
                String[] parts = line.split("\t", -1);
                if (parts.length >= 2) files.add(parts[1]);
            }
        }
        return new Report(true, committed, committed ? "roll-forward" : "roll-back", files,
                directoryFingerprint(journal, false), directoryFingerprint(root, true));
    }

    private static String directoryFingerprint(Path directory, boolean tablesOnly) throws IOException {
        NativePlaylistDatabase.checkPath(directory);
        List<Path> files = new ArrayList<Path>();
        try (java.nio.file.DirectoryStream<Path> entries = Files.newDirectoryStream(directory)) {
            for (Path entry : entries) {
                if (tablesOnly && !entry.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".dat")) continue;
                requireFile(entry);
                files.add(entry);
            }
        }
        Collections.sort(files, new Comparator<Path>() {
            public int compare(Path left, Path right) {
                return left.getFileName().toString().compareTo(right.getFileName().toString());
            }
        });
        MessageDigest digest;
        try { digest = MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException unavailable) { throw new IOException("SHA-256 unavailable", unavailable); }
        digest.update((tablesOnly ? "jsymphonic-library-v1\n" : "jsymphonic-journal-v1\n").getBytes(StandardCharsets.UTF_8));
        for (Path file : files) {
            byte[] name = file.getFileName().toString().getBytes(StandardCharsets.UTF_8);
            long size = Files.size(file);
            digest.update(ByteBuffer.allocate(4).putInt(name.length).array());
            digest.update(name);
            digest.update(ByteBuffer.allocate(8).putLong(size).array());
            long read = 0;
            try (InputStream input = Files.newInputStream(file)) {
                byte[] buffer = new byte[8192];
                int length;
                while ((length = input.read(buffer)) != -1) {
                    digest.update(buffer, 0, length);
                    read += length;
                }
            }
            if (read != size || Files.size(file) != size)
                throw new IOException("Files changed during inspection; retry with exclusive access");
        }
        StringBuilder hex = new StringBuilder();
        for (byte value : digest.digest()) hex.append(String.format(Locale.ROOT, "%02x", value & 0xff));
        return hex.toString();
    }

    public static void recover(Path root) throws IOException {
        // Validate the entire replay before changing probes, temps, or live files.
        // A missing later payload must not partially publish an earlier table.
        Report report = inspect(root);
        Path journal = root.resolve(DIRECTORY);
        if (report.committed) validateRecovery(root, journal);
        // A crashed rename probe leaves the bytes beside the missing original.
        // Put them back before roll-forward, including when there is no journal.
        restoreProbeSiblings(root);
        sweepStrays(root);
        deleteOmaTemps(root);
        if (!report.pending) return;
        if (report.committed) {
            if (Files.isRegularFile(journal.resolve("format"))) publishFormat2(root, journal);
            else publishLegacy(root, journal);
        }
        retireJournal(journal, null);
        sweepStrays(root);
        deleteOmaTemps(root);
    }

    static void commit(Path root, List<FileSpec> files, List<AudioSpec> audio,
            NativePlaylistDatabase.Publisher publisher, Probe probe) throws IOException {
        for (FileSpec file : files) checkName(file.name);
        sweepStrays(root);
        Path journal = root.resolve(DIRECTORY);
        if (Files.exists(journal))
            throw new NativePlaylistDatabase.Fatal(NativePlaylistDatabase.Fatal.JOURNAL_PENDING,
                    "An incomplete playlist transaction requires backup recovery before another operation");
        Files.createDirectory(journal);
        fire(probe, "directory");
        boolean publishing = false;
        boolean published = false;
        int publishedFiles = 0;
        int publishedAudio = 0;
        try {
            atomicWrite(journal, "format", "2\n".getBytes(StandardCharsets.UTF_8));
            fire(probe, "format");
            for (FileSpec file : files) {
                atomicWrite(journal, file.name + ".before", file.before == null ? new byte[0] : file.before);
                fire(probe, "before:" + file.name);
            }
            for (FileSpec file : files) {
                atomicWrite(journal, file.name + ".next", file.next);
                fire(probe, "next:" + file.name);
            }
            StringBuilder audioManifest = new StringBuilder();
            for (int i = 0; i < audio.size(); i++) {
                AudioSpec spec = audio.get(i);
                String stored = (spec.delete ? "del-" : "add-") + i + ".dat";
                copyAtomically(spec.payload, journal.resolve(stored));
                audioManifest.append(spec.delete ? "delete" : "add").append('\t')
                        .append(spec.relative).append('\t').append(stored).append('\n');
                fire(probe, "stage-audio:" + spec.relative);
            }
            StringBuilder names = new StringBuilder();
            for (FileSpec file : files) names.append(file.name).append('\n');
            atomicWrite(journal, "files.txt", names.toString().getBytes(StandardCharsets.UTF_8));
            atomicWrite(journal, "audio.txt", audioManifest.toString().getBytes(StandardCharsets.UTF_8));
            fire(probe, "manifest");
            atomicWrite(journal, "commit", new byte[0]);
            fire(probe, "commit");
            publishing = true;
            if (failNextPublish) {
                failNextPublish = false;
                throw new IOException("injected publish failure");
            }
            for (FileSpec file : files) {
                Path source = journal.resolve(file.name + ".next");
                Path target = root.resolve(file.name);
                // A publisher may change the target and then throw. Include that
                // uncertain attempt in rollback, even when it never returns.
                publishedFiles++;
                if (publisher != null) publisher.publish(source, target);
                else copyAtomically(source, target);
                if (!Arrays.equals(file.next, readBytes(target)))
                    throw new IOException("Database write verification failed for " + file.name);
                fire(probe, "publish:" + file.name);
            }
            for (int i = 0; i < audio.size(); i++) {
                AudioSpec spec = audio.get(i);
                // A locked file fails the whole batch. The staged tables already
                // omit or include every track in this transaction, so publishing
                // the others without this file would leave the database wrong.
                String stored = (spec.delete ? "del-" : "add-") + i + ".dat";
                publishAudioOperation(root, journal, spec.delete, spec.relative, stored);
                publishedAudio++;
                fire(probe, "publish-audio:" + spec.relative);
            }
            published = true;
            fire(probe, "cleanup");
            retireJournal(journal, probe);
            sweepStrays(root);
        } catch (Interrupt e) {
            throw e;
        } catch (Throwable failure) {
            // Before the commit marker, drop the journal for every failure kind,
            // including Error, then rethrow the original. After it, roll the
            // batch back. An Error once the marker is durable is left in place:
            // recovery itself may be what ran out of memory.
            if (!publishing) discardUncommitted(journal, failure);
            else if (!published && failure instanceof Exception)
                undoPublished(root, journal, files, audio, publishedFiles, publishedAudio, (Exception) failure);
            // Once every publish is verified, cleanup cannot turn success into
            // rollback: cleanup may already have removed restoration payloads.
            // Preserve any remaining journal so explicit recovery can finish.
            rethrow(failure);
        }
    }

    /** The journal has no commit marker yet. Remove it so a later write is not refused. */
    private static void discardUncommitted(Path journal, Throwable failure) {
        try { deleteTree(journal); }
        catch (Throwable cleanup) { if (cleanup != failure) failure.addSuppressed(cleanup); }
    }

    private static void rethrow(Throwable failure) throws IOException {
        if (failure instanceof Error) throw (Error) failure;
        if (failure instanceof RuntimeException) throw (RuntimeException) failure;
        if (failure instanceof IOException) throw (IOException) failure;
        throw new IOException(failure);
    }

    /** Restore live files, then drop the commit marker before the rest of the journal. */
    private static void undoPublished(Path root, Path journal, List<FileSpec> files, List<AudioSpec> audio,
            int publishedFiles, int publishedAudio, Exception failure) throws IOException {
        try {
            rollback(root, journal, files, audio, publishedFiles, publishedAudio);
            // The lock and read-only codes are only allowed once this check passes
            // and the journal is gone. A mismatch keeps the journal instead.
            verifyRestored(root, journal, files, audio, publishedFiles, publishedAudio);
        } catch (IOException recovery) {
            failure.addSuppressed(recovery);
            // The commit marker is still on disk. Inspect and recover can finish the job.
            throw new RollbackFailed("Database update failed; incomplete recovery requires a verified backup", failure);
        }
        try {
            retireJournal(journal, null);
            sweepStrays(root);
        } catch (IOException recovery) {
            failure.addSuppressed(recovery);
            // Live files may be back, but the journal is not gone, so this is not a lock code.
            throw new RollbackFailed("Database update failed; incomplete recovery requires a verified backup", failure);
        }
    }

    /** Post-commit restore did not put every file back. The journal is still present. */
    public static final class RollbackFailed extends IOException {
        RollbackFailed(String message, Throwable cause) { super(message, cause); }
    }

    /**
     * An audio file was locked or still in use while publishing or rolling forward.
     * {@code relative} is the OMGAUDIO-relative path with forward slashes.
     */
    public static final class FileLocked extends IOException {
        public final String relative;
        public FileLocked(String relative) {
            super("Device file is locked");
            this.relative = relative == null ? null : relative.replace('\\', '/');
        }
    }

    /**
     * An audio file was read-only while publishing or rolling forward.
     * {@code relative} is the OMGAUDIO-relative path with forward slashes.
     */
    public static final class FileReadOnly extends IOException {
        public final String relative;
        public FileReadOnly(String relative) {
            super("Device file is read-only");
            this.relative = relative == null ? null : relative.replace('\\', '/');
        }
    }

    static void atomicWrite(Path directory, String name, byte[] data) throws IOException {
        checkName(name);
        Path tmp = directory.resolve(name + ".jsymphonic-tmp");
        NativePlaylistDatabase.checkPath(directory);
        NativePlaylistDatabase.checkPath(tmp);
        boolean created = false;
        try {
            try (FileChannel out = FileChannel.open(tmp, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
                created = true;
                ByteBuffer bytes = ByteBuffer.wrap(data);
                while (bytes.hasRemaining()) out.write(bytes);
                out.force(true);
            }
            replace(tmp, directory.resolve(name));
        } finally {
            // Only unlink a temp this invocation created; never remove an
            // existing path that caused CREATE_NEW to fail.
            if (created) Files.deleteIfExists(tmp);
        }
    }

    private static void publishFormat2(Path root, Path journal) throws IOException {
        List<String> names = lines(journal.resolve("files.txt"));
        for (String name : names) {
            checkName(name);
            Path source = journal.resolve(name + ".next");
            if (!Files.isRegularFile(source)) throw new IOException("Journal is missing the staged bytes for " + name);
            copyAtomically(source, root.resolve(name));
        }
        if (!Files.isRegularFile(journal.resolve("audio.txt"))) return;
        for (String line : lines(journal.resolve("audio.txt"))) applyAudio(root, journal, line);
    }

    private static void validateRecovery(Path root, Path journal) throws IOException {
        requireFile(journal.resolve("files.txt"));
        List<String> names = lines(journal.resolve("files.txt"));
        boolean format2 = Files.isRegularFile(journal.resolve("format"));
        Set<String> destinations = new HashSet<String>();
        Set<String> inventory = new HashSet<String>();
        inventory.add("files.txt");
        if (Files.exists(journal.resolve("commit"))) inventory.add("commit");
        if (format2) {
            inventory.add("format");
            inventory.add("audio.txt");
        }
        if (!format2 && names.size() != 2) throw new IOException("Legacy playlist journal is incomplete");
        for (int i = 0; i < names.size(); i++) {
            String name = names.get(i);
            checkName(name);
            if (!destinations.add(name.toLowerCase(Locale.ROOT)))
                throw new IOException("Duplicate journal destination: " + name);
            Path next = journal.resolve(format2 ? name + ".next" : i == 0 ? "tree.next" : "info.next");
            inventory.add(next.getFileName().toString());
            requireFile(next);
            Path target = root.resolve(name);
            NativePlaylistDatabase.checkPath(target);
            if (format2) {
                Path before = journal.resolve(name + ".before");
                inventory.add(before.getFileName().toString());
                requireFile(before);
                if (Files.exists(target) && (!Files.isRegularFile(target)
                        || (!sameBytes(target, before) && !sameBytes(target, next))))
                    throw new IOException("Live file conflicts with journal: " + name);
            }
        }
        if (!format2) {
            // Legacy transactions may also carry the two before-images.
            for (String name : Arrays.asList("tree.before", "info.before"))
                if (Files.exists(journal.resolve(name))) inventory.add(name);
            validateInventory(journal, inventory);
            return;
        }
        requireFile(journal.resolve("audio.txt"));
        int audioIndex = 0;
        for (String line : lines(journal.resolve("audio.txt"))) {
            String[] parts = line.split("\t", -1);
            if (parts.length != 3 || !("add".equals(parts[0]) || "delete".equals(parts[0])))
                throw new IOException("Invalid audio journal entry");
            checkName(parts[2]);
            if (!parts[2].equals(("delete".equals(parts[0]) ? "del-" : "add-") + audioIndex++ + ".dat"))
                throw new IOException("Invalid journal audio payload name");
            checkAudioName(parts[1]);
            if (!destinations.add(parts[1].toLowerCase(Locale.ROOT)))
                throw new IOException("Duplicate journal destination: " + parts[1]);
            if (!inventory.add(parts[2])) throw new IOException("Duplicate journal payload: " + parts[2]);
            Path payload = journal.resolve(parts[2]);
            requireFile(payload);
            Path target = resolveInside(root, parts[1]);
            NativePlaylistDatabase.checkPath(target);
            // A crashed probe may hold the live bytes beside the original.
            Path current = Files.exists(target) ? target
                    : target.resolveSibling(target.getFileName().toString() + PROBE_SUFFIX);
            NativePlaylistDatabase.checkPath(current);
            if (Files.exists(current) && (!Files.isRegularFile(current) || !sameBytes(current, payload)))
                throw new IOException("Live audio conflicts with journal: " + parts[1]);
        }
        validateInventory(journal, inventory);
    }

    private static void validateInventory(Path journal, Set<String> expected) throws IOException {
        Set<String> actual = new HashSet<String>();
        try (java.nio.file.DirectoryStream<Path> entries = Files.newDirectoryStream(journal)) {
            for (Path entry : entries) {
                requireFile(entry);
                actual.add(entry.getFileName().toString());
            }
        }
        if (!actual.equals(expected))
            throw new IOException("Journal inventory does not match its manifests; preserve it for reconciliation");
    }

    private static void checkAudioName(String relative) throws IOException {
        if (relative == null || !relative.matches("(?i)(10f[0-9a-f]{2}/[0-9a-f]{8}\\.oma|20p[0-9a-f]{2}/1g[0-9a-f]{6}(p0|01|02)\\.jpg)"))
            throw new IOException("Invalid journal audio destination");
    }

    private static void requireFile(Path path) throws IOException {
        NativePlaylistDatabase.checkPath(path);
        if (!Files.isRegularFile(path) || !Files.isReadable(path))
            throw new IOException("Journal is missing readable staged data: " + path.getFileName());
    }

    private static void publishLegacy(Path root, Path journal) throws IOException {
        List<String> names = lines(journal.resolve("files.txt"));
        if (names.size() != 2) throw new IOException("Legacy playlist journal is incomplete");
        checkName(names.get(0));
        checkName(names.get(1));
        copyAtomically(journal.resolve("tree.next"), root.resolve(names.get(0)));
        copyAtomically(journal.resolve("info.next"), root.resolve(names.get(1)));
    }

    private static void applyAudio(Path root, Path journal, String line) throws IOException {
        String[] parts = line.split("\t", -1);
        if (parts.length != 3) throw new IOException("Invalid audio journal entry");
        checkName(parts[2]);
        if ("delete".equals(parts[0])) publishAudioOperation(root, journal, true, parts[1], parts[2]);
        else if ("add".equals(parts[0])) publishAudioOperation(root, journal, false, parts[1], parts[2]);
        else throw new IOException("Invalid audio journal entry");
    }

    /**
     * Publish one audio add or delete. A lock is an {@link AccessDeniedException}
     * or a Windows sharing/lock violation. Write-protected media is
     * {@link FileReadOnly}. Any other {@link FileSystemException} stays an
     * ordinary IOException. Message text is not consulted.
     */
    private static void publishAudioOperation(Path root, Path journal, boolean delete, String relative, String stored) throws IOException {
        if (lockAudioOnPublish) {
            lockAudioOnPublish = false;
            throw new FileLocked(relative);
        }
        Path dest = resolveInside(root, relative);
        if (Files.isRegularFile(dest) && NWOmgaudio.isReadOnly(dest.toFile()))
            throw new FileReadOnly(relative);
        if (isReadOnlyMedia(dest))
            throw new FileReadOnly(relative);
        try {
            RuntimeException unchecked = failAudioUnchecked;
            if (unchecked != null) {
                failAudioUnchecked = null;
                throw unchecked;
            }
            IOException injected = failAudioIo;
            if (injected != null) {
                failAudioIo = null;
                throw injected;
            }
            if (delete) {
                Files.deleteIfExists(dest);
                if (Files.exists(dest)) throw new FileLocked(relative);
            } else {
                if (dest.getParent() != null) Files.createDirectories(dest.getParent());
                copyAtomically(journal.resolve(stored), dest);
            }
        } catch (ReadOnlyFileSystemException e) {
            throw new FileReadOnly(relative);
        } catch (FileLocked e) {
            throw e;
        } catch (FileReadOnly e) {
            throw e;
        } catch (IOException e) {
            if (isLockException(e)) throw new FileLocked(relative);
            throw e;
        }
    }

    /**
     * {@link AccessDeniedException}, or a sharing/lock violation.
     * OpenJDK maps Win32 {@code ERROR_ACCESS_DENIED} (5) to {@link AccessDeniedException}
     * and leaves {@code ERROR_SHARING_VIOLATION} (32) and {@code ERROR_LOCK_VIOLATION} (33)
     * as a {@link FileSystemException} whose reason is the localized system text.
     * The numeric code is present only when {@code FormatMessage} fails
     * ({@code Unknown error: 0x20} or {@code Unknown error: 0x21}) or when a
     * {@code WindowsException} cause exposes {@code lastError()}. A sentence in
     * the reason is not a lock.
     */
    private static boolean isLockException(IOException error) {
        if (error instanceof AccessDeniedException) return true;
        return isSharingViolation(error);
    }

    private static boolean isSharingViolation(Throwable error) {
        Throwable current = error;
        while (current != null) {
            if (windowsSharingOrLock(current)) return true;
            if (current instanceof FileSystemException && isSharingReason(((FileSystemException) current).getReason()))
                return true;
            current = current.getCause();
        }
        return false;
    }

    /** Reason is the JDK fallback or the bare Win32 code, never a sentence. */
    private static boolean isSharingReason(String reason) {
        if (reason == null) return false;
        String trimmed = reason.trim();
        return "Unknown error: 0x20".equals(trimmed) || "Unknown error: 0x21".equals(trimmed)
                || "32".equals(trimmed) || "33".equals(trimmed);
    }

    private static boolean windowsSharingOrLock(Throwable error) {
        if (!"WindowsException".equals(error.getClass().getSimpleName())) return false;
        try {
            java.lang.reflect.Method method = error.getClass().getMethod("lastError");
            Object value = method.invoke(error);
            if (!(value instanceof Integer)) return false;
            int code = ((Integer) value).intValue();
            return code == ERROR_SHARING_VIOLATION || code == ERROR_LOCK_VIOLATION;
        } catch (ReflectiveOperationException ex) {
            return false;
        }
    }

    /** {@link java.nio.file.FileStore#isReadOnly()} or the write-protected test seam. */
    private static boolean isReadOnlyMedia(Path dest) {
        if (readOnlyMedia) return true;
        try {
            Path storePath = Files.exists(dest) ? dest : dest.getParent();
            if (storePath == null) return false;
            return Files.getFileStore(storePath).isReadOnly();
        } catch (IOException e) {
            return false;
        }
    }

    private static void rollback(Path root, Path journal, List<FileSpec> files, List<AudioSpec> audio,
            int publishedFiles, int publishedAudio) throws IOException {
        if (failRollbackRestore) {
            failRollbackRestore = false;
            throw new IOException("rollback restore refused");
        }
        for (int i = 0; i < publishedFiles; i++) {
            FileSpec file = files.get(i);
            Path target = root.resolve(file.name);
            if (file.before == null) Files.deleteIfExists(target);
            else atomicWrite(root, file.name, file.before);
        }
        for (int i = publishedAudio - 1; i >= 0; i--) {
            AudioSpec spec = audio.get(i);
            Path dest = resolveInside(root, spec.relative);
            if (spec.delete) copyAtomically(journal.resolve("del-" + i + ".dat"), dest);
            else Files.deleteIfExists(dest);
        }
    }

    /** After rollback, every published file and every audio target must match the pre-commit bytes. */
    private static void verifyRestored(Path root, Path journal, List<FileSpec> files, List<AudioSpec> audio,
            int publishedFiles, int publishedAudio) throws IOException {
        for (int i = 0; i < publishedFiles; i++) {
            FileSpec file = files.get(i);
            Path target = root.resolve(file.name);
            if (file.before == null) {
                if (Files.exists(target)) throw new IOException("rollback left " + file.name);
            } else if (!Files.isRegularFile(target) || !Arrays.equals(file.before, readBytes(target))) {
                throw new IOException("rollback mismatch for " + file.name);
            }
        }
        for (int i = 0; i < audio.size(); i++) {
            AudioSpec spec = audio.get(i);
            Path dest = resolveInside(root, spec.relative);
            if (spec.delete) {
                Path staged = journal.resolve("del-" + i + ".dat");
                if (!Files.isRegularFile(dest) || !Arrays.equals(readBytes(staged), readBytes(dest)))
                    throw new IOException("rollback mismatch for " + spec.relative);
            } else if (i < publishedAudio && Files.exists(dest)) {
                throw new IOException("rollback left added audio " + spec.relative);
            }
        }
    }

    private static Path resolveInside(Path root, String relative) throws IOException {
        if (relative == null || relative.isEmpty() || relative.startsWith("/") || relative.indexOf('\\') >= 0
                || relative.startsWith("../") || relative.equals("..") || relative.contains("/../"))
            throw new IOException("Invalid journal audio path");
        Path dest = root.resolve(relative).normalize();
        if (!dest.startsWith(root)) throw new IOException("Invalid journal audio path");
        return dest;
    }

    private static void checkName(String name) throws IOException {
        if (name == null || ".".equals(name) || "..".equals(name) || !name.matches("[A-Za-z0-9._-]+"))
            throw new IOException("Invalid journal file name");
    }

    private static List<String> lines(Path file) throws IOException {
        List<String> result = new ArrayList<String>();
        String text = new String(readBytes(file), StandardCharsets.UTF_8);
        for (String line : text.split("\n", -1)) {
            if (line.endsWith("\r")) line = line.substring(0, line.length() - 1);
            if (!line.isEmpty()) result.add(line);
        }
        return result;
    }

    private static void fire(Probe probe, String step) throws IOException {
        if (probe != null) probe.step(step);
    }

    private static byte[] readBytes(Path path) throws IOException {
        NativePlaylistDatabase.checkPath(path);
        return Files.readAllBytes(path);
    }

    private static void copyAtomically(Path source, Path target) throws IOException {
        if (failPayloadRead != null && source.toAbsolutePath().normalize().equals(failPayloadRead.toAbsolutePath().normalize())) {
            failPayloadRead = null;
            throw new IOException("Could not read " + source.getFileName());
        }
        NativePlaylistDatabase.checkPath(source);
        if (target.getParent() != null) NativePlaylistDatabase.checkPath(target.getParent());
        Path tmp = target.resolveSibling(target.getFileName().toString() + ".jsymphonic-tmp");
        // CREATE_NEW opens and claims the path in one filesystem operation.
        // NOFOLLOW alone would still truncate an existing hard-linked inode.
        boolean created = false;
        try {
            try (InputStream in = Files.newInputStream(source);
                    FileChannel out = FileChannel.open(tmp, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE)) {
                created = true;
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) >= 0) {
                    ByteBuffer bytes = ByteBuffer.wrap(buffer, 0, n);
                    while (bytes.hasRemaining()) out.write(bytes);
                }
                out.force(true);
            }
            replace(tmp, target);
        } finally {
            if (created) Files.deleteIfExists(tmp);
        }
    }

    private static void replace(Path source, Path target) throws IOException {
        try {
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    /**
     * Drop the commit marker before any other journal entry, then rename the
     * directory aside and delete that copy. A crash after the marker is gone
     * can no longer be mistaken for a committed transaction.
     */
    private static void retireJournal(Path journal, Probe probe) throws IOException {
        if (!Files.exists(journal)) return;
        Files.deleteIfExists(journal.resolve("commit"));
        fire(probe, "cleanup-retired");
        Path retired = journal.resolveSibling(RETIRED);
        if (Files.exists(retired)) deleteTree(retired);
        try {
            Files.move(journal, retired, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(journal, retired);
        }
        deleteTree(retired);
    }

    /**
     * Put a crashed rename probe back before a write or recover. A missing
     * original is renamed back, with a short retry. A sibling whose bytes match
     * the original is deleted. A sibling whose bytes differ is a
     * {@link ProbeConflict}: neither file is removed.
     */
    public static void restoreProbeSiblings(Path omgaudio) throws IOException {
        for (ProbeSite site : probeSites(omgaudio)) settleExistingProbe(site.original, site.sibling);
    }

    /** Probe siblings a read command should report. Does not rename or delete. */
    public static List<PendingProbe> listPendingProbes(Path omgaudio) throws IOException {
        List<PendingProbe> pending = new ArrayList<PendingProbe>();
        for (ProbeSite site : probeSites(omgaudio))
            pending.add(new PendingProbe(site.relative, site.probeRelative));
        return pending;
    }

    /**
     * Resolve one sibling that is already beside the probe. Identical bytes:
     * delete only the sibling. Different bytes: {@link ProbeConflict}. Missing
     * original: retry the rename-back.
     */
    static void settleExistingProbe(Path original, Path sibling) {
        String relative = folderAndName(original);
        String probeRelative = folderAndName(sibling);
        if (!Files.exists(sibling)) return;
        if (!Files.exists(original)) {
            renameProbeBack(sibling, original);
            return;
        }
        try {
            if (sameBytes(original, sibling)) {
                Files.delete(sibling);
                return;
            }
        } catch (IOException e) {
            throw new ProbeRestoreFailed(relative, probeRelative, e);
        }
        throw new ProbeConflict(relative, probeRelative);
    }

    /**
     * Rename a probe sibling back onto the missing original. Five attempts,
     * with 250ms between them (about one second). If the sibling is still there
     * and the original is not, {@link ProbeRestoreFailed}. The sibling is not deleted.
     */
    static void renameProbeBack(Path sibling, Path original) {
        String relative = folderAndName(original);
        String probeRelative = folderAndName(sibling);
        IOException last = null;
        probeRenameAttempts = 0;
        for (int attempt = 0; attempt < PROBE_RENAME_ATTEMPTS; attempt++) {
            probeRenameAttempts++;
            if (attempt > 0) pauseProbe(PROBE_RENAME_BACKOFF_MS);
            try {
                if (failProbeRenameBack) throw new IOException("probe rename-back refused");
                moveNew(sibling, original);
                return;
            } catch (IOException e) {
                last = e;
            }
        }
        if (Files.exists(sibling) && !Files.exists(original))
            throw new ProbeRestoreFailed(relative, probeRelative, last);
        if (!Files.exists(sibling)) return;
        try {
            if (Files.exists(original) && sameBytes(original, sibling)) {
                Files.delete(sibling);
                return;
            }
        } catch (IOException e) {
            throw new ProbeRestoreFailed(relative, probeRelative, e);
        }
        if (Files.exists(original)) throw new ProbeConflict(relative, probeRelative);
        throw new ProbeRestoreFailed(relative, probeRelative, last);
    }

    private static void pauseProbe(long millis) {
        ProbeBackoff backoff = probeBackoff;
        if (backoff != null) {
            backoff.sleep(millis);
            return;
        }
        try {
            Thread.sleep(millis);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
        }
    }

    private static String folderAndName(Path file) {
        Path parent = file.getParent();
        String folder = parent == null || parent.getFileName() == null ? "" : parent.getFileName().toString();
        return folder + "/" + file.getFileName().toString();
    }

    private static boolean sameBytes(Path left, Path right) throws IOException {
        if (Files.size(left) != Files.size(right)) return false;
        try (InputStream a = Files.newInputStream(left); InputStream b = Files.newInputStream(right)) {
            byte[] leftBuf = new byte[8192];
            byte[] rightBuf = new byte[8192];
            while (true) {
                int leftN = readChunk(a, leftBuf);
                int rightN = readChunk(b, rightBuf);
                if (leftN != rightN) return false;
                if (leftN == 0) return true;
                for (int i = 0; i < leftN; i++) if (leftBuf[i] != rightBuf[i]) return false;
            }
        }
    }

    private static int readChunk(InputStream in, byte[] buf) throws IOException {
        int offset = 0;
        while (offset < buf.length) {
            int n = in.read(buf, offset, buf.length - offset);
            if (n < 0) return offset;
            offset += n;
        }
        return offset;
    }

    private static final class ProbeSite {
        final Path original;
        final Path sibling;
        final String relative;
        final String probeRelative;
        ProbeSite(Path original, Path sibling, String relative, String probeRelative) {
            this.original = original;
            this.sibling = sibling;
            this.relative = relative;
            this.probeRelative = probeRelative;
        }
    }

    private static List<ProbeSite> probeSites(Path omgaudio) throws IOException {
        List<ProbeSite> sites = new ArrayList<ProbeSite>();
        if (omgaudio == null || !Files.isDirectory(omgaudio)) return sites;
        NativePlaylistDatabase.checkPath(omgaudio);
        File[] dirs = omgaudio.toFile().listFiles();
        if (dirs == null) return sites;
        for (File dir : dirs) {
            if (!isProbeFolder(dir.getName())) continue;
            NativePlaylistDatabase.checkPath(dir.toPath());
            if (!dir.isDirectory()) continue;
            File[] files = dir.listFiles();
            if (files == null) continue;
            for (File sibling : files) {
                if (!sibling.isFile()) continue;
                String name = sibling.getName();
                if (!name.toLowerCase(java.util.Locale.ROOT).endsWith(PROBE_SUFFIX)) continue;
                String originalName = name.substring(0, name.length() - PROBE_SUFFIX.length());
                if (originalName.isEmpty()) continue;
                Path original = new File(dir, originalName).toPath();
                NativePlaylistDatabase.checkPath(original);
                NativePlaylistDatabase.checkPath(sibling.toPath());
                sites.add(new ProbeSite(original, sibling.toPath(),
                        dir.getName() + "/" + originalName, dir.getName() + "/" + name));
            }
        }
        Collections.sort(sites, new Comparator<ProbeSite>() {
            public int compare(ProbeSite left, ProbeSite right) {
                return left.relative.compareTo(right.relative);
            }
        });
        return sites;
    }

    /** Audio folders {@code 10F*} and jacket folders {@code 20Pxx} (two hex digits). */
    private static boolean isProbeFolder(String name) {
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        return lower.startsWith("10f") || lower.matches("20p[0-9a-f]{2}");
    }

    /** Rename without replacing an existing file, so a probe sibling is never overwritten or deleted. */
    private static void moveNew(Path source, Path target) throws IOException {
        try {
            Files.move(source, target, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(source, target);
        }
    }

    /**
     * Remove crashed temp files from the journal directory and from the OMGAUDIO
     * directory that holds the known tables. Audio folders such as {@code 10F00}
     * are not walked. A journal directory renamed aside is removed with them.
     */
    static void sweepStrays(Path root) throws IOException {
        if (root == null || !Files.isDirectory(root)) return;
        NativePlaylistDatabase.checkPath(root);
        Path retired = root.resolve(RETIRED);
        if (Files.exists(retired)) deleteTree(retired);
        deleteTempFiles(root, false);
        Path journal = root.resolve(DIRECTORY);
        if (Files.isDirectory(journal)) deleteTempFiles(journal, true);
    }

    /**
     * Recover-only. Delete direct children of {@code 10Fxx} directories whose
     * names end with {@code .oma.jsymphonic-tmp}, ignoring case. Other temps in
     * those folders, including {@code .jsymphonic-probe} siblings, stay.
     */
    private static void deleteOmaTemps(Path root) throws IOException {
        if (root == null || !Files.isDirectory(root)) return;
        File[] dirs = root.toFile().listFiles();
        if (dirs == null) return;
        for (File dir : dirs) {
            if (!dir.getName().toLowerCase(java.util.Locale.ROOT).startsWith("10f")) continue;
            NativePlaylistDatabase.checkPath(dir.toPath());
            if (!dir.isDirectory()) continue;
            File[] files = dir.listFiles();
            if (files == null) continue;
            for (File child : files) {
                if (child.isFile() && child.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".oma.jsymphonic-tmp"))
                    Files.deleteIfExists(child.toPath());
            }
        }
    }

    /** {@code recursive} is only for the journal directory. The table directory is one level. */
    private static void deleteTempFiles(Path dir, boolean recursive) throws IOException {
        if (!recursive) {
            File[] children = dir.toFile().listFiles();
            if (children == null) return;
            for (File child : children) {
                if (child.isFile() && child.getName().endsWith(".jsymphonic-tmp"))
                    Files.deleteIfExists(child.toPath());
            }
            return;
        }
        List<Path> temps = new ArrayList<Path>();
        Files.walkFileTree(dir, new java.nio.file.SimpleFileVisitor<Path>() {
            @Override public java.nio.file.FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (file.getFileName().toString().endsWith(".jsymphonic-tmp")) temps.add(file);
                return java.nio.file.FileVisitResult.CONTINUE;
            }
        });
        for (Path temp : temps) Files.deleteIfExists(temp);
    }

    private static void deleteTree(Path root) throws IOException {
        if (!Files.exists(root)) return;
        NativePlaylistDatabase.checkPath(root);
        List<Path> children = new ArrayList<Path>();
        Files.walkFileTree(root, new java.nio.file.SimpleFileVisitor<Path>() {
            @Override public java.nio.file.FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) throws IOException {
                children.add(file);
                return java.nio.file.FileVisitResult.CONTINUE;
            }
            @Override public java.nio.file.FileVisitResult postVisitDirectory(Path dir, IOException exc) {
                children.add(dir);
                return java.nio.file.FileVisitResult.CONTINUE;
            }
        });
        for (Path child : children) Files.deleteIfExists(child);
    }
}
