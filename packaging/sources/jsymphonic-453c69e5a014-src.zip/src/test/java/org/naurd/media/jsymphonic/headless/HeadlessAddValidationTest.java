package org.naurd.media.jsymphonic.headless;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class HeadlessAddValidationTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();

    @Test public void unsupportedBatchFailsWithoutDatabaseRebuild() throws Exception {
        assertRejectedBatch(false, false);
    }

    @Test public void mixedBatchFailsBeforePublishingTheSupportedFile() throws Exception {
        assertRejectedBatch(true, false);
    }

    @Test public void rejectedBatchDoesNotRestorePendingProbes() throws Exception {
        assertRejectedBatch(false, true);
    }

    private void assertRejectedBatch(boolean mixed, boolean probe) throws Exception {
        Path mount = temporary.newFolder().toPath();
        Path root = Files.createDirectory(mount.resolve("OMGAUDIO"));
        if (probe) {
            Files.write(Files.createDirectory(root.resolve("10F00"))
                    .resolve("10000001.OMA.jsymphonic-probe"), new byte[] {1,2,3,4,5,6,7,8});
        }
        Path unknown = temporary.newFile("unsupported.txt").toPath();
        Files.write(unknown, new byte[] {7});
        List<String> args = new ArrayList<String>(Arrays.asList("add", "--device", mount.toString()));
        if (mixed) {
            Path known = temporary.newFile("supported.oma").toPath();
            Files.write(known, new byte[] {1,2,3,4,5,6,7,8});
            args.add(known.toString());
        }
        args.add(unknown.toString());
        Map<String, List<Byte>> before = snapshot(root);
        ByteArrayOutputStream json = new ByteArrayOutputStream();
        int exit = HeadlessCli.run(args.toArray(new String[0]), new PrintStream(json, true, "UTF-8"),
                new PrintStream(new ByteArrayOutputStream(), true, "UTF-8"));
        String output = json.toString("UTF-8");
        assertFalse(output, output.contains("\"event\":\"plan\""));
        assertEquals(output, 1, exit);
        assertTrue(output, output.contains("\"event\":\"fatal\""));
        assertFalse(output, output.contains("\"event\":\"done\""));
        assertEquals("Rejected input must preserve all device paths and bytes", before, snapshot(root));
    }

    private static Map<String, List<Byte>> snapshot(Path root) throws Exception {
        Map<String, List<Byte>> result = new TreeMap<String, List<Byte>>();
        try (java.util.stream.Stream<Path> paths = Files.walk(root)) {
            for (Path path : (Iterable<Path>) paths::iterator) {
                List<Byte> bytes = new ArrayList<Byte>();
                if (Files.isRegularFile(path)) for (byte b : Files.readAllBytes(path)) bytes.add(b);
                result.put(root.relativize(path).toString(), bytes);
            }
        }
        return result;
    }
}
