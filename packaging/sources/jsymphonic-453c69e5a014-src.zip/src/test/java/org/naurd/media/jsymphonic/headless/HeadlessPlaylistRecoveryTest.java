package org.naurd.media.jsymphonic.headless;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import org.junit.Test;
import org.naurd.media.jsymphonic.device.sony.nw.NativePlaylistDatabase;
import org.naurd.media.jsymphonic.device.sony.nw.OmgaudioJournal;
import static org.junit.Assert.*;

public class HeadlessPlaylistRecoveryTest {
    @Test public void danglingRefsAndJournalAndSlotLimitEmitFatalCodes() throws Exception {
        Path device = device();
        NativePlaylistDatabase db = NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile());
        db.create("Dangling", Collections.singletonList(99), Collections.singleton(99));
        db.save();
        Result update = invoke("playlist-update", "--device", device.toString(), "--id", "1", "--name", "Nope");
        assertEquals(update.out, 1, update.code);
        assertTrue(update.out, update.out.contains("\"event\":\"fatal\""));
        assertTrue(update.out, update.out.contains("\"code\":\"PLAYLIST_REF_MISSING\""));
        assertTrue(update.out, update.out.contains("references missing track"));
        assertFalse(update.out, update.out.contains("\"event\":\"done\""));

        // Use a recognized input so this reaches the device's reference checks.
        Path source = Files.createTempFile("playlist-input-", ".oma");
        Files.write(source, new byte[] {1, 2, 3, 4, 5, 6, 7, 8});
        Result add = invoke("add", "--device", device.toString(), source.toString(), "--idle-timeout", "5");
        assertEquals(add.out, 1, add.code);
        assertTrue(add.out, add.out.contains("\"code\":\"PLAYLIST_REF_MISSING\""));
        assertTrue(add.out, add.out.contains("IllegalStateException"));
        assertFalse(add.out, add.out.contains("\"event\":\"done\""));

        Path blocked = device();
        Files.createDirectory(blocked.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY));
        Result listed = invoke("playlists", "--device", blocked.toString());
        assertEquals(1, listed.code);
        assertTrue(listed.out, listed.out.contains("\"code\":\"PLAYLIST_JOURNAL_PENDING\""));
        assertTrue(listed.out, listed.out.contains("incomplete"));
        Result blockedAdd = invoke("add", "--device", blocked.toString(), source.toString(), "--idle-timeout", "5");
        assertTrue(blockedAdd.out, blockedAdd.out.contains("\"code\":\"PLAYLIST_JOURNAL_PENDING\""));

        Path full = device();
        NativePlaylistDatabase slots = NativePlaylistDatabase.read(full.resolve("OMGAUDIO").toFile());
        for (int i = 0; i < 2048; i++) slots.create("p" + i, Collections.<Integer>emptyList(), Collections.<Integer>emptySet());
        slots.save();
        Result overflow = invoke("playlist-create", "--device", full.toString(), "--name", "One more");
        assertEquals(overflow.out, 1, overflow.code);
        assertTrue(overflow.out, overflow.out.contains("\"code\":\"PLAYLIST_SLOTS_EXHAUSTED\""));
        assertTrue(overflow.out, overflow.out.contains("2048"));

        Result ordinary = invoke("playlist-create", "--device", device().toString(), "--name", "Ok", "999");
        assertEquals(1, ordinary.code);
        assertTrue(ordinary.out, ordinary.out.contains("\"event\":\"fatal\""));
        assertFalse(ordinary.out, ordinary.out.contains("\"code\""));
    }

    @Test public void repairPrunesDanglingMembersWithoutAFatalCode() throws Exception {
        Path device = device();
        Files.createDirectories(device.resolve("OMGAUDIO/10F00"));
        Files.write(device.resolve("OMGAUDIO/10F00/10000001.OMA"), new byte[] {1, 2, 3, 4, 5, 6, 7, 8});
        NativePlaylistDatabase db = NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile());
        db.create("Keep", java.util.Arrays.asList(1, 3), new java.util.HashSet<Integer>(java.util.Arrays.asList(1, 3)));
        db.save();
        Result repaired = invoke("playlist-repair", "--device", device.toString());
        assertEquals(repaired.out + repaired.err, 0, repaired.code);
        assertLineOrder(repaired.out,
                "{\"event\":\"playlistRepair\",\"prunedCount\":1,\"prunedTrackIds\":[3],\"playlistIds\":[1]}",
                "{\"event\":\"playlist\",\"id\":\"1\",\"name\":\"Keep\",\"trackIds\":[\"1\"]}",
                "{\"event\":\"done\"}");
        assertFalse(repaired.out, repaired.out.contains("\"code\""));
        assertEquals(java.util.Arrays.asList(1), NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile()).list().get(0).trackIds);
    }

    @Test public void repairWithNothingToPruneWritesNothing() throws Exception {
        Path device = device();
        Files.createDirectories(device.resolve("OMGAUDIO/10F00"));
        Files.write(device.resolve("OMGAUDIO/10F00/10000001.OMA"), new byte[] {1, 2, 3, 4, 5, 6, 7, 8});
        NativePlaylistDatabase db = NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile());
        db.create("Keep", java.util.Collections.singletonList(1), java.util.Collections.singleton(1));
        db.save();
        byte[] tree = Files.readAllBytes(device.resolve("OMGAUDIO/01tree22.dat"));
        byte[] info = Files.readAllBytes(device.resolve("OMGAUDIO/03ginf22.dat"));
        Result repaired = invoke("playlist-repair", "--device", device.toString());
        assertEquals(repaired.out + repaired.err, 0, repaired.code);
        assertLineOrder(repaired.out,
                "{\"event\":\"playlistRepair\",\"prunedCount\":0,\"prunedTrackIds\":[],\"playlistIds\":[]}",
                "{\"event\":\"playlist\",\"id\":\"1\",\"name\":\"Keep\",\"trackIds\":[\"1\"]}",
                "{\"event\":\"done\"}");
        assertArrayEquals(tree, Files.readAllBytes(device.resolve("OMGAUDIO/01tree22.dat")));
        assertArrayEquals(info, Files.readAllBytes(device.resolve("OMGAUDIO/03ginf22.dat")));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void repairRefusesAnEmptyOrFailedTrackLoad() throws Exception {
        Path empty = device();
        NativePlaylistDatabase db = NativePlaylistDatabase.read(empty.resolve("OMGAUDIO").toFile());
        db.create("Keep", java.util.Collections.singletonList(1), java.util.Collections.singleton(1));
        db.save();
        byte[] tree = Files.readAllBytes(empty.resolve("OMGAUDIO/01tree22.dat"));
        byte[] info = Files.readAllBytes(empty.resolve("OMGAUDIO/03ginf22.dat"));
        Result refused = invoke("playlist-repair", "--device", empty.toString());
        assertEquals(refused.out + refused.err, 1, refused.code);
        assertTrue(hasLine(refused.out, "{\"event\":\"fatal\",\"message\":\"Playlist repair refused: the device track list is empty or the library did not load\",\"code\":\"PLAYLIST_LIBRARY_NOT_LOADED\"}"));
        assertFalse(refused.out, refused.out.contains("\"event\":\"done\""));
        assertFalse(refused.out, refused.out.contains("\"event\":\"playlistRepair\""));
        assertArrayEquals(tree, Files.readAllBytes(empty.resolve("OMGAUDIO/01tree22.dat")));
        assertArrayEquals(info, Files.readAllBytes(empty.resolve("OMGAUDIO/03ginf22.dat")));

        Path failed = device();
        Files.createDirectories(failed.resolve("OMGAUDIO/10F00"));
        Files.write(failed.resolve("OMGAUDIO/10F00/10000001.OMA"), new byte[] {1, 2});
        db = NativePlaylistDatabase.read(failed.resolve("OMGAUDIO").toFile());
        db.create("Keep", java.util.Collections.singletonList(1), java.util.Collections.singleton(1));
        db.save();
        tree = Files.readAllBytes(failed.resolve("OMGAUDIO/01tree22.dat"));
        Result unread = invoke("playlist-repair", "--device", failed.toString());
        assertEquals(1, unread.code);
        assertTrue(hasLine(unread.out, "{\"event\":\"fatal\",\"message\":\"Playlist repair refused: the device track list is empty or the library did not load\",\"code\":\"PLAYLIST_LIBRARY_NOT_LOADED\"}"));
        assertArrayEquals(tree, Files.readAllBytes(failed.resolve("OMGAUDIO/01tree22.dat")));
    }

    @Test public void repairRefusesWhenAnOmaFailsToParse() throws Exception {
        Path device = device();
        Files.createDirectories(device.resolve("OMGAUDIO/10F00"));
        Files.write(device.resolve("OMGAUDIO/10F00/10000001.OMA"), new byte[] {1, 2, 3, 4, 5, 6, 7, 8});
        byte[] unparseable = new byte[18];
        unparseable[10] = 'T';
        unparseable[11] = 'I';
        unparseable[12] = 'T';
        unparseable[13] = '2';
        unparseable[16] = 0x0C;
        unparseable[17] = (byte) 0xC1;
        Files.write(device.resolve("OMGAUDIO/10F00/10000003.OMA"), unparseable);
        NativePlaylistDatabase db = NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile());
        db.create("Keep", java.util.Arrays.asList(1, 3), new java.util.HashSet<Integer>(java.util.Arrays.asList(1, 3)));
        db.save();
        byte[] tree = Files.readAllBytes(device.resolve("OMGAUDIO/01tree22.dat"));
        byte[] info = Files.readAllBytes(device.resolve("OMGAUDIO/03ginf22.dat"));
        Result refused = invoke("playlist-repair", "--device", device.toString());
        assertEquals(refused.out + refused.err, 1, refused.code);
        assertTrue(hasLine(refused.out, "{\"event\":\"fatal\",\"message\":\"Playlist repair refused: the device track list is empty or the library did not load\",\"code\":\"PLAYLIST_LIBRARY_NOT_LOADED\"}"));
        assertFalse(refused.out, refused.out.contains("\"event\":\"playlistRepair\""));
        assertFalse(refused.out, refused.out.contains("\"event\":\"done\""));
        assertArrayEquals(tree, Files.readAllBytes(device.resolve("OMGAUDIO/01tree22.dat")));
        assertArrayEquals(info, Files.readAllBytes(device.resolve("OMGAUDIO/03ginf22.dat")));
    }

    @Test public void playlistsLeavesAStrayTempFile() throws Exception {
        Path device = device();
        Path stray = device.resolve("OMGAUDIO/STRAY.jsymphonic-tmp");
        Files.write(stray, new byte[] {1, 2, 3});
        Files.createDirectories(device.resolve("OMGAUDIO/10F00"));
        Path audioStray = device.resolve("OMGAUDIO/10F00/a.oma.jsymphonic-tmp");
        Files.write(audioStray, new byte[] {4});
        Result listed = invoke("playlists", "--device", device.toString());
        assertEquals(listed.out + listed.err, 0, listed.code);
        assertTrue(Files.exists(stray));
        assertArrayEquals(new byte[] {1, 2, 3}, Files.readAllBytes(stray));
        assertTrue(Files.exists(audioStray));
    }

    private static boolean hasLine(String out, String line) {
        for (String candidate : out.split("\\r?\\n", -1)) if (candidate.equals(line)) return true;
        return false;
    }

    private static void assertLineOrder(String out, String... lines) {
        int at = -1;
        for (String line : lines) {
            assertTrue(out, hasLine(out, line));
            int found = out.indexOf(line);
            assertTrue(out, found > at);
            at = found;
        }
    }

    @Test public void recoverInspectReportsTheJournalAndRecoverAppliesIt() throws Exception {
        Path device = device();
        Path root = device.resolve("OMGAUDIO");
        Files.write(root.resolve("MARKER.DAT"), "live".getBytes(StandardCharsets.UTF_8));
        Files.createDirectories(root.resolve("10F00"));
        Files.write(root.resolve("10F00/10000001.OMA"), new byte[] {4, 5, 6, 7, 8});
        Path journal = root.resolve(OmgaudioJournal.DIRECTORY);
        Files.createDirectory(journal);
        Files.write(journal.resolve("format"), "2\n".getBytes(StandardCharsets.UTF_8));
        Files.write(journal.resolve("files.txt"), "MARKER.DAT\n".getBytes(StandardCharsets.UTF_8));
        Files.write(journal.resolve("MARKER.DAT.before"), "live".getBytes(StandardCharsets.UTF_8));
        Files.write(journal.resolve("MARKER.DAT.next"), "next".getBytes(StandardCharsets.UTF_8));
        Files.write(journal.resolve("audio.txt"), "delete\t10F00/10000001.OMA\tdel-0.dat\n".getBytes(StandardCharsets.UTF_8));
        Files.write(journal.resolve("del-0.dat"), new byte[] {4, 5, 6, 7, 8});
        Files.write(journal.resolve("commit"), new byte[0]);

        Result inspect = invoke("playlist-recover", "--device", device.toString(), "--inspect");
        assertEquals(inspect.out + inspect.err, 0, inspect.code);
        assertTrue(inspect.out, inspect.out.contains(
                "{\"event\":\"playlistJournal\",\"state\":\"committed\",\"pending\":true,\"committed\":true,\"action\":\"roll-forward\",\"files\":[\"MARKER.DAT\",\"10F00/10000001.OMA\"],\"fingerprint\":"));
        assertTrue(inspect.out, inspect.out.contains("\"event\":\"done\""));
        assertFalse(inspect.out, inspect.out.contains("\"outcome\""));
        assertFalse(inspect.out, inspect.out.contains("\"code\""));
        assertEquals("live", new String(Files.readAllBytes(root.resolve("MARKER.DAT")), StandardCharsets.UTF_8));
        assertTrue(Files.exists(root.resolve("10F00/10000001.OMA")));
        assertTrue(Files.isDirectory(journal));

        Result recover = invoke("playlist-recover", "--device", device.toString());
        assertEquals(recover.out + recover.err, 0, recover.code);
        assertTrue(recover.out, recover.out.contains(
                "{\"event\":\"playlistJournal\",\"state\":\"committed\",\"outcome\":\"rolled_forward\",\"pending\":false,\"committed\":true,\"action\":\"roll-forward\",\"files\":[\"MARKER.DAT\",\"10F00/10000001.OMA\"],\"fingerprint\":"));
        assertEquals("next", new String(Files.readAllBytes(root.resolve("MARKER.DAT")), StandardCharsets.UTF_8));
        assertFalse(Files.exists(root.resolve("10F00/10000001.OMA")));
        assertFalse(Files.exists(journal));

        Path absent = device();
        Result none = invoke("playlist-recover", "--device", absent.toString(), "--inspect");
        assertEquals(0, none.code);
        assertTrue(none.out, none.out.contains(
                "{\"event\":\"playlistJournal\",\"state\":\"none\",\"pending\":false,\"committed\":false,\"action\":\"none\",\"files\":[],\"fingerprint\":null"));
        assertFalse(none.out, none.out.contains("\"outcome\""));
        Result recoverNone = invoke("playlist-recover", "--device", absent.toString());
        assertTrue(recoverNone.out, recoverNone.out.contains("\"outcome\":\"none\""));

        Path open = device();
        Path openJournal = open.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY);
        Files.createDirectory(openJournal);
        Files.write(openJournal.resolve("format"), "2\n".getBytes(StandardCharsets.UTF_8));
        Result uncommitted = invoke("playlist-recover", "--device", open.toString());
        assertEquals(uncommitted.out + uncommitted.err, 0, uncommitted.code);
        assertTrue(uncommitted.out, uncommitted.out.contains(
                "{\"event\":\"playlistJournal\",\"state\":\"uncommitted\",\"outcome\":\"discarded\",\"pending\":false,\"committed\":false,\"action\":\"roll-back\",\"files\":[],\"fingerprint\":"));
        assertFalse(Files.exists(openJournal));
    }

    private static Path device() throws Exception {
        Path device = Files.createTempDirectory("playlist-recovery-");
        Files.createDirectories(device.resolve("OMGAUDIO"));
        return device;
    }

    private static Result invoke(String... args) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        int code = HeadlessCli.run(args, new PrintStream(out, true, "UTF-8"), new PrintStream(err, true, "UTF-8"));
        return new Result(code, out.toString("UTF-8"), err.toString("UTF-8"));
    }

    private static final class Result {
        final int code;
        final String out;
        final String err;
        Result(int code, String out, String err) { this.code = code; this.out = out; this.err = err; }
    }
}
