package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystemException;
import java.nio.file.NoSuchFileException;
import java.nio.file.ReadOnlyFileSystemException;
import java.util.ArrayList;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.PosixFilePermission;
import java.util.EnumSet;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.Test;
import org.naurd.media.jsymphonic.headless.HeadlessCli;
import org.naurd.media.jsymphonic.title.Title;
import static org.junit.Assert.*;

public class DeviceFileFailureTest {
    private static final byte[] BODY = new byte[] {1, 2, 3, 4, 5, 6, 7, 8};
    private static final String LOCKED =
            "{\"event\":\"fatal\",\"message\":\"Device file is locked\",\"code\":\"DEVICE_FILE_LOCKED\",\"path\":\"OMGAUDIO/10F00/10000001.OMA\"}";
    private static final String READ_ONLY =
            "{\"event\":\"fatal\",\"message\":\"Device file is read-only\",\"code\":\"DEVICE_FILE_READ_ONLY\",\"path\":\"OMGAUDIO/10F00/10000001.OMA\"}";
    private static final String ROLLBACK =
            "{\"event\":\"fatal\",\"message\":\"Database update failed; incomplete recovery requires a verified backup\",\"code\":\"DEVICE_ROLLBACK_FAILED\"}";
    private static final String RESTORE_FAILED =
            "{\"event\":\"fatal\",\"message\":\"Device file probe could not be restored\",\"code\":\"DEVICE_PROBE_RESTORE_FAILED\",\"path\":\"OMGAUDIO/10F00/10000001.OMA\",\"probe_path\":\"OMGAUDIO/10F00/10000001.OMA.jsymphonic-probe\"}";
    private static final String CONFLICT =
            "{\"event\":\"fatal\",\"message\":\"Device file probe conflicts with the track\",\"code\":\"DEVICE_PROBE_CONFLICT\",\"path\":\"OMGAUDIO/10F00/10000001.OMA\",\"probe_path\":\"OMGAUDIO/10F00/10000001.OMA.jsymphonic-probe\"}";

    @Test public void renameProbeRoundTripsWithoutLeavingASibling() throws Exception {
        Path dir = Files.createTempDirectory("probe-roundtrip-");
        Path file = dir.resolve("10000001.OMA");
        Files.write(file, BODY);
        assertFalse(NWOmgaudio.trackFileLocked(file.toFile()));
        assertArrayEquals(BODY, Files.readAllBytes(file));
        assertFalse(Files.exists(dir.resolve("10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX)));
    }

    @Test public void restoreRefusesADifferentProbeBesideTheOriginal() throws Exception {
        Path root = Files.createTempDirectory("probe-keep-");
        Files.createDirectories(root.resolve("10F00"));
        Files.write(root.resolve("10F00/10000001.OMA"), new byte[] {1});
        Files.write(root.resolve("10F00/10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX), new byte[] {2});
        try {
            OmgaudioJournal.restoreProbeSiblings(root);
            fail("differing probe sibling must conflict");
        } catch (OmgaudioJournal.ProbeConflict conflict) {
            assertEquals("10F00/10000001.OMA", conflict.relative);
            assertEquals("10F00/10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX, conflict.probeRelative);
        }
        assertArrayEquals(new byte[] {1}, Files.readAllBytes(root.resolve("10F00/10000001.OMA")));
        assertArrayEquals(new byte[] {2}, Files.readAllBytes(root.resolve("10F00/10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX)));
    }

    @Test public void restoreDeletesAProbeThatMatchesTheOriginal() throws Exception {
        Path root = Files.createTempDirectory("probe-same-");
        Files.createDirectories(root.resolve("10F00"));
        Files.write(root.resolve("10F00/10000001.OMA"), new byte[] {1, 2});
        Files.write(root.resolve("10F00/10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX), new byte[] {1, 2});
        OmgaudioJournal.restoreProbeSiblings(root);
        assertArrayEquals(new byte[] {1, 2}, Files.readAllBytes(root.resolve("10F00/10000001.OMA")));
        assertFalse(Files.exists(root.resolve("10F00/10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX)));
    }

    @Test public void lockedFileFailsBeforeAnythingIsWritten() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        NWOmgaudio.fileLockProbe = new NWOmgaudio.FileLockProbe() {
            public boolean locked(File file) {
                return file.getName().toLowerCase().endsWith(".oma");
            }
        };
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, LOCKED));
            assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        } finally {
            NWOmgaudio.fileLockProbe = null;
        }
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertFalse(Files.exists(sibling(audio)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO/db_backup")));
    }

    @Test public void readOnlyFileFailsBeforeItIsRenamed() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        markReadOnly(audio);
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, READ_ONLY));
            assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        } finally {
            clearReadOnly(audio);
        }
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertFalse(Files.exists(sibling(audio)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO/db_backup")));
    }

    @Test public void rollbackFailureKeepsTheJournal() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        OmgaudioJournal.failNextPublish = true;
        OmgaudioJournal.failRollbackRestore = true;
        Result deleted;
        try {
            deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
        } finally {
            OmgaudioJournal.failNextPublish = false;
            OmgaudioJournal.failRollbackRestore = false;
        }
        assertEquals(deleted.out + deleted.err, 1, deleted.code);
        assertTrue(hasLine(deleted.out, "{\"event\":\"fatal\",\"message\":\"Database update failed; incomplete recovery requires a verified backup\",\"code\":\"DEVICE_ROLLBACK_FAILED\"}"));
        assertFalse(deleted.out, deleted.out.contains("\"path\""));
        assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        assertTrue(Files.isDirectory(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertTrue(Files.exists(audio));

        Result inspect = invoke("playlist-recover", "--device", device.toString(), "--inspect");
        assertEquals(inspect.out + inspect.err, 0, inspect.code);
        assertTrue(inspect.out, inspect.out.contains("\"state\":\"committed\""));
        assertTrue(inspect.out, inspect.out.contains("\"event\":\"done\""));
        Result recover = invoke("playlist-recover", "--device", device.toString());
        assertEquals(recover.out + recover.err, 0, recover.code);
        assertTrue(recover.out, recover.out.contains("\"outcome\":\"rolled_forward\""));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void playlistCreateRollbackFailureKeepsTheCodeAndJournal() throws Exception {
        Path device = device();
        OmgaudioJournal.failNextPublish = true;
        OmgaudioJournal.failRollbackRestore = true;
        Result created;
        try {
            created = invoke("playlist-create", "--device", device.toString(), "--name", "Kept");
        } finally {
            OmgaudioJournal.failNextPublish = false;
            OmgaudioJournal.failRollbackRestore = false;
        }
        assertEquals(created.out + created.err, 1, created.code);
        assertTrue(hasLine(created.out, ROLLBACK));
        assertFalse(created.out, created.out.contains("\"path\""));
        assertFalse(created.out, created.out.contains("\"event\":\"done\""));
        assertTrue(Files.isRegularFile(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY).resolve("commit")));
    }

    @Test public void playlistUpdateDeleteAndRepairReportRollbackFailure() throws Exception {
        Path updated = device();
        Result created = invoke("playlist-create", "--device", updated.toString(), "--name", "Kept");
        assertEquals(created.out + created.err, 0, created.code);
        assertPlaylistRollback(updated, "playlist-update", "--device", updated.toString(), "--id", "1", "--name", "Changed");

        Path deleted = device();
        Result made = invoke("playlist-create", "--device", deleted.toString(), "--name", "Kept");
        assertEquals(made.out + made.err, 0, made.code);
        assertPlaylistRollback(deleted, "playlist-delete", "--device", deleted.toString(), "--id", "1");

        Path repaired = device();
        track(repaired, "10000001.OMA", BODY);
        track(repaired, "10000002.OMA", new byte[] {8, 7, 6, 5, 4, 3, 2, 1});
        Result playlist = invoke("playlist-create", "--device", repaired.toString(), "--name", "Mix", "1", "2");
        assertEquals(playlist.out + playlist.err, 0, playlist.code);
        Files.delete(repaired.resolve("OMGAUDIO/10F00/10000001.OMA"));
        assertPlaylistRollback(repaired, "playlist-repair", "--device", repaired.toString());
    }

    @Test public void renameBackRetriesFiveTimesWithoutSleeping() throws Exception {
        Path root = Files.createTempDirectory("probe-retry-");
        Files.createDirectories(root.resolve("10F00"));
        Path sibling = root.resolve("10F00/10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX);
        Files.write(sibling, BODY);
        final java.util.List<Long> pauses = new ArrayList<Long>();
        OmgaudioJournal.failProbeRenameBack = true;
        OmgaudioJournal.probeBackoff = new OmgaudioJournal.ProbeBackoff() {
            public void sleep(long millis) { pauses.add(Long.valueOf(millis)); }
        };
        try {
            OmgaudioJournal.renameProbeBack(sibling, root.resolve("10F00/10000001.OMA"));
            fail("rename-back should fail");
        } catch (OmgaudioJournal.ProbeRestoreFailed failed) {
            assertEquals("10F00/10000001.OMA", failed.relative);
        } finally {
            OmgaudioJournal.failProbeRenameBack = false;
            OmgaudioJournal.probeBackoff = null;
        }
        assertEquals(5, OmgaudioJournal.probeRenameAttempts);
        assertEquals(java.util.Arrays.asList(250L, 250L, 250L, 250L), pauses);
        assertArrayEquals(BODY, Files.readAllBytes(sibling));
        assertFalse(Files.exists(root.resolve("10F00/10000001.OMA")));
    }

    @Test public void wrappedPlaylistFatalStillReportsRollbackFailure() throws Exception {
        Path device = device();
        NativePlaylistDatabase.Fatal wrapped = new NativePlaylistDatabase.Fatal(
                NativePlaylistDatabase.Fatal.REF_MISSING, "wrapped playlist failure");
        wrapped.initCause(new OmgaudioJournal.RollbackFailed(
                "Database update failed; incomplete recovery requires a verified backup", new IOException("rollback")));
        NativePlaylistDatabase.failSave = wrapped;
        try {
            Result created = invoke("playlist-create", "--device", device.toString(), "--name", "Kept");
            assertEquals(created.out + created.err, 1, created.code);
            assertTrue(created.out, hasLine(created.out, ROLLBACK));
            assertFalse(created.out, created.out.contains("PLAYLIST_REF_MISSING"));
            assertFalse(created.out, created.out.contains("\"path\""));
        } finally {
            NativePlaylistDatabase.failSave = null;
        }
    }

    @Test public void lockDuringCommitRollsBackAndKeepsTheFatal() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        OmgaudioJournal.lockAudioOnPublish = true;
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, LOCKED));
            assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        } finally {
            OmgaudioJournal.lockAudioOnPublish = false;
        }
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void lockDuringRecoverKeepsTheCommittedJournal() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        Path journal = device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY);
        Files.createDirectory(journal);
        Files.write(journal.resolve("format"), "2\n".getBytes(StandardCharsets.UTF_8));
        Files.write(journal.resolve("files.txt"), new byte[0]);
        Files.write(journal.resolve("audio.txt"), "delete\t10F00/10000001.OMA\tdel-0.dat\n".getBytes(StandardCharsets.UTF_8));
        Files.write(journal.resolve("del-0.dat"), BODY);
        Files.write(journal.resolve("commit"), new byte[0]);
        OmgaudioJournal.lockAudioOnPublish = true;
        try {
            Result recover = invoke("playlist-recover", "--device", device.toString());
            assertEquals(recover.out + recover.err, 1, recover.code);
            assertTrue(recover.out, hasLine(recover.out, LOCKED));
            assertFalse(recover.out, recover.out.contains("\"event\":\"done\""));
            assertFalse(recover.out, recover.out.contains("\"event\":\"playlistJournal\""));
        } finally {
            OmgaudioJournal.lockAudioOnPublish = false;
        }
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertTrue(Files.isRegularFile(journal.resolve("commit")));
    }

    @Test public void recoverRestoresAProbeSiblingAndInspectDoesNot() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        crashProbe(device, "1");
        assertFalse(Files.exists(audio));
        assertArrayEquals(BODY, Files.readAllBytes(sibling(audio)));

        Result listed = invoke("playlists", "--device", device.toString());
        assertEquals(listed.out + listed.err, 0, listed.code);
        assertFalse(Files.exists(audio));
        assertTrue(Files.exists(sibling(audio)));

        Result inspect = invoke("playlist-recover", "--device", device.toString(), "--inspect");
        assertEquals(inspect.out + inspect.err, 0, inspect.code);
        assertTrue(inspect.out, inspect.out.contains("\"event\":\"done\""));
        assertFalse(Files.exists(audio));
        assertArrayEquals(BODY, Files.readAllBytes(sibling(audio)));

        Result recover = invoke("playlist-recover", "--device", device.toString());
        assertEquals(recover.out + recover.err, 0, recover.code);
        assertTrue(recover.out, recover.out.contains("\"outcome\":\"none\""));
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertFalse(Files.exists(sibling(audio)));
    }

    @Test public void followingWriteRestoresAProbeSibling() throws Exception {
        Path device = device();
        Path first = track(device, "10000001.OMA", BODY);
        byte[] other = new byte[] {8, 7, 6, 5, 4, 3, 2, 1};
        Path second = track(device, "10000002.OMA", other);
        crashProbe(device, "1");
        assertFalse(Files.exists(first));
        assertArrayEquals(BODY, Files.readAllBytes(sibling(first)));

        Result inspect = invoke("playlist-recover", "--device", device.toString(), "--inspect");
        assertEquals(inspect.out + inspect.err, 0, inspect.code);
        assertFalse(Files.exists(first));
        assertTrue(Files.exists(sibling(first)));

        Result deleted = invoke("del", "--device", device.toString(), "--id", "2", "--idle-timeout", "15");
        assertEquals(deleted.out + deleted.err, 0, deleted.code);
        assertArrayEquals(BODY, Files.readAllBytes(first));
        assertFalse(Files.exists(sibling(first)));
        assertFalse(Files.exists(second));
        assertFalse(Files.exists(sibling(second)));
    }

    @Test public void lockedDeleteInAMixedBatchWritesNothing() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        Path incoming = Files.createTempFile("add-", ".oma");
        Files.write(incoming, BODY);
        System.setProperty("java.awt.headless", "true");
        CountDownLatch done = new CountDownLatch(1);
        NWOmgaudio dev = new NWOmgaudio(device.toString(), "walkman", "", null, NWGeneric.GENERATION_7,
                new QuietListener(done), device.toString());
        File temp = new File(System.getProperty("java.io.tmpdir"), "walkman-bridge-jsym");
        temp.mkdirs();
        dev.setTempPath(temp.getAbsolutePath());
        dev.setAlwaysTranscode(false);
        Title[] titles = dev.getTitles();
        assertEquals(1, titles.length);
        dev.scheduleDeletion(titles[0]);
        assertEquals(0, dev.scheduleImport(new File[] { incoming.toFile() }, false));
        NWOmgaudio.fileLockProbe = new NWOmgaudio.FileLockProbe() {
            public boolean locked(File file) {
                return file.getName().toLowerCase().endsWith(".oma");
            }
        };
        try {
            dev.applyChanges();
            assertTrue(done.await(15, TimeUnit.SECONDS));
        } finally {
            NWOmgaudio.fileLockProbe = null;
        }
        assertFalse(Files.exists(device.resolve("OMGAUDIO/10F00/10000002.OMA")));
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertFalse(Files.exists(sibling(audio)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO/db_backup")));
        File[] children = device.resolve("OMGAUDIO").toFile().listFiles();
        assertNotNull(children);
        for (File child : children) {
            if (child.isDirectory()) assertEquals("10F00", child.getName());
        }
    }

    @Test public void pathOffTheMountIsFatalImmediatelyWithNoCode() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        OmgaudioJournal.failRelativize = true;
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "2");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, "{\"event\":\"fatal\",\"message\":\"Device path is not on this mount\"}"));
            assertFalse(deleted.out, deleted.out.contains("\"code\""));
            assertFalse(deleted.out, deleted.out.contains("Transfer produced no progress"));
            assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        } finally {
            OmgaudioJournal.failRelativize = false;
        }
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void probeTimeLockOrReadOnlyWritesNothing() throws Exception {
        Path lockedDevice = seeded();
        Map<String, byte[]> beforeLock = liveLibrary(lockedDevice.resolve("OMGAUDIO"));
        NWOmgaudio.fileLockProbe = new NWOmgaudio.FileLockProbe() {
            public boolean locked(File file) {
                return file.getName().toLowerCase().endsWith(".oma");
            }
        };
        try {
            Result deleted = invoke("del", "--device", lockedDevice.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, LOCKED));
            assertFalse(deleted.out, deleted.out.contains(NWOmgaudio.DEVICE_FILE_READ_ONLY));
            assertFalse(deleted.out, deleted.out.contains(NWOmgaudio.DEVICE_ROLLBACK_FAILED));
        } finally {
            NWOmgaudio.fileLockProbe = null;
        }
        assertLibraryUnchanged(lockedDevice, beforeLock);

        Path readOnlyDevice = seeded();
        Path audio = readOnlyDevice.resolve("OMGAUDIO/10F00/10000001.OMA");
        markReadOnly(audio);
        Map<String, byte[]> beforeReadOnly = liveLibrary(readOnlyDevice.resolve("OMGAUDIO"));
        try {
            Result deleted = invoke("del", "--device", readOnlyDevice.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, READ_ONLY));
            assertFalse(deleted.out, deleted.out.contains(NWOmgaudio.DEVICE_FILE_LOCKED));
            assertFalse(deleted.out, deleted.out.contains(NWOmgaudio.DEVICE_ROLLBACK_FAILED));
        } finally {
            clearReadOnly(audio);
        }
        assertLibraryUnchanged(readOnlyDevice, beforeReadOnly);
    }

    @Test public void postCommitLockWithSuccessfulRollbackWritesNothing() throws Exception {
        Path device = seeded();
        Map<String, byte[]> before = liveLibrary(device.resolve("OMGAUDIO"));
        OmgaudioJournal.lockAudioOnPublish = true;
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, LOCKED));
            assertFalse(deleted.out, deleted.out.contains(NWOmgaudio.DEVICE_ROLLBACK_FAILED));
            assertFalse(deleted.out, deleted.out.contains(NWOmgaudio.DEVICE_FILE_READ_ONLY));
        } finally {
            OmgaudioJournal.lockAudioOnPublish = false;
        }
        assertLibraryUnchanged(device, before);
    }

    @Test public void postCommitLockWithFailedRollbackKeepsTheJournal() throws Exception {
        Path device = seeded();
        Path audio = device.resolve("OMGAUDIO/10F00/10000001.OMA");
        byte[] audioBefore = Files.readAllBytes(audio);
        OmgaudioJournal.lockAudioOnPublish = true;
        OmgaudioJournal.failRollbackRestore = true;
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, ROLLBACK));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_READ_ONLY\""));
            assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        } finally {
            OmgaudioJournal.lockAudioOnPublish = false;
            OmgaudioJournal.failRollbackRestore = false;
        }
        assertTrue(Files.isRegularFile(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY).resolve("commit")));
        assertFalse(hasProbeSibling(device.resolve("OMGAUDIO")));
        assertArrayEquals(audioBefore, Files.readAllBytes(audio));
    }

    @Test public void errorDuringApplyChangesIsFatalImmediately() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        NWOmgaudio.probeFailure = new OutOfMemoryError("boom");
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "2");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(hasLine(deleted.out, "{\"event\":\"fatal\",\"message\":\"OutOfMemoryError: boom\"}"));
            assertFalse(deleted.out, deleted.out.contains("\"code\""));
            assertFalse(deleted.out, deleted.out.contains("Transfer produced no progress"));
            assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        } finally {
            NWOmgaudio.probeFailure = null;
        }
        assertArrayEquals(BODY, Files.readAllBytes(audio));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void renameBackFailureKeepsTheProbeAndIsNotLocked() throws Exception {
        Path device = device();
        Path audio = track(device, "10000001.OMA", BODY);
        OmgaudioJournal.failProbeRenameBack = true;
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, RESTORE_FAILED));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
            assertFalse(deleted.out, deleted.out.contains("\"event\":\"done\""));
        } finally {
            OmgaudioJournal.failProbeRenameBack = false;
        }
        assertFalse(Files.exists(audio));
        assertArrayEquals(BODY, Files.readAllBytes(sibling(audio)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void restoreAtMountAndRecoverUsesTheSameCode() throws Exception {
        Path write = device();
        Path writeAudio = track(write, "10000001.OMA", BODY);
        Files.move(writeAudio, sibling(writeAudio));
        OmgaudioJournal.failProbeRenameBack = true;
        try {
            Result deleted = invoke("del", "--device", write.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, RESTORE_FAILED));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
        } finally {
            OmgaudioJournal.failProbeRenameBack = false;
        }
        assertFalse(Files.exists(writeAudio));
        assertArrayEquals(BODY, Files.readAllBytes(sibling(writeAudio)));

        Path recoverDevice = device();
        Path recoverAudio = track(recoverDevice, "10000001.OMA", BODY);
        Files.move(recoverAudio, sibling(recoverAudio));
        OmgaudioJournal.failProbeRenameBack = true;
        try {
            Result recovered = invoke("playlist-recover", "--device", recoverDevice.toString());
            assertEquals(recovered.out + recovered.err, 1, recovered.code);
            assertTrue(recovered.out, hasLine(recovered.out, RESTORE_FAILED));
            assertFalse(recovered.out, recovered.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
            assertFalse(recovered.out, recovered.out.contains("\"event\":\"playlistJournal\""));
        } finally {
            OmgaudioJournal.failProbeRenameBack = false;
        }
        assertFalse(Files.exists(recoverAudio));
        assertArrayEquals(BODY, Files.readAllBytes(sibling(recoverAudio)));
    }

    @Test public void identicalProbeIsDeletedAndADifferentProbeConflicts() throws Exception {
        Path write = device();
        Path kept = track(write, "10000001.OMA", BODY);
        Path other = track(write, "10000002.OMA", new byte[] {8, 7, 6, 5, 4, 3, 2, 1});
        Files.write(sibling(kept), BODY);
        Result deleted = invoke("del", "--device", write.toString(), "--id", "2", "--idle-timeout", "15");
        assertEquals(deleted.out + deleted.err, 0, deleted.code);
        assertArrayEquals(BODY, Files.readAllBytes(kept));
        assertFalse(Files.exists(sibling(kept)));
        assertFalse(Files.exists(other));

        Path recoverDevice = device();
        Path recoverAudio = track(recoverDevice, "10000001.OMA", BODY);
        Files.write(sibling(recoverAudio), BODY);
        Result recovered = invoke("playlist-recover", "--device", recoverDevice.toString());
        assertEquals(recovered.out + recovered.err, 0, recovered.code);
        assertTrue(recovered.out, recovered.out.contains("\"outcome\":\"none\""));
        assertArrayEquals(BODY, Files.readAllBytes(recoverAudio));
        assertFalse(Files.exists(sibling(recoverAudio)));

        Path conflictWrite = device();
        Path conflictAudio = track(conflictWrite, "10000001.OMA", BODY);
        byte[] otherBytes = new byte[] {9, 9, 9, 9, 9, 9, 9, 9};
        Files.write(sibling(conflictAudio), otherBytes);
        Files.write(conflictWrite.resolve("OMGAUDIO/NOTES.TXT"), "leave-this".getBytes(StandardCharsets.UTF_8));
        Result refused = invoke("del", "--device", conflictWrite.toString(), "--id", "1", "--idle-timeout", "15");
        assertEquals(refused.out + refused.err, 1, refused.code);
        assertTrue(refused.out, hasLine(refused.out, CONFLICT));
        assertFalse(refused.out, refused.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
        assertFalse(refused.out, refused.out.contains("\"event\":\"done\""));
        assertArrayEquals(BODY, Files.readAllBytes(conflictAudio));
        assertArrayEquals(otherBytes, Files.readAllBytes(sibling(conflictAudio)));
        assertArrayEquals("leave-this".getBytes(StandardCharsets.UTF_8),
                Files.readAllBytes(conflictWrite.resolve("OMGAUDIO/NOTES.TXT")));
        assertFalse(Files.exists(conflictWrite.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));

        Path conflictRecover = device();
        Path recoverConflictAudio = track(conflictRecover, "10000001.OMA", BODY);
        Files.write(sibling(recoverConflictAudio), otherBytes);
        Result recoverRefused = invoke("playlist-recover", "--device", conflictRecover.toString());
        assertEquals(recoverRefused.out + recoverRefused.err, 1, recoverRefused.code);
        assertTrue(recoverRefused.out, hasLine(recoverRefused.out, CONFLICT));
        assertFalse(recoverRefused.out, recoverRefused.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
        assertFalse(recoverRefused.out, recoverRefused.out.contains("\"event\":\"playlistJournal\""));
        assertArrayEquals(BODY, Files.readAllBytes(recoverConflictAudio));
        assertArrayEquals(otherBytes, Files.readAllBytes(sibling(recoverConflictAudio)));
    }

    @Test public void jacketProbeIn20P00IsRestoredWarnedAndConflicted() throws Exception {
        byte[] jpeg = new byte[] {(byte) 0xFF, (byte) 0xD8, 1, 2, 3, 4, 5, 6};

        Path missingDevice = device();
        Path missing = jacket(missingDevice, "10000001.JPG", jpeg);
        Files.move(missing, sibling(missing));
        Result restored = invoke("playlist-recover", "--device", missingDevice.toString());
        assertEquals(restored.out + restored.err, 0, restored.code);
        assertArrayEquals(jpeg, Files.readAllBytes(missing));
        assertFalse(Files.exists(sibling(missing)));

        Path sameDevice = device();
        Path same = jacket(sameDevice, "10000001.JPG", jpeg);
        Files.write(sibling(same), jpeg);
        Result deleted = invoke("playlist-recover", "--device", sameDevice.toString());
        assertEquals(deleted.out + deleted.err, 0, deleted.code);
        assertArrayEquals(jpeg, Files.readAllBytes(same));
        assertFalse(Files.exists(sibling(same)));

        Path conflictDevice = device();
        Path conflict = jacket(conflictDevice, "10000001.JPG", jpeg);
        byte[] other = new byte[] {9, 9, 9, 9, 9, 9, 9, 9};
        Files.write(sibling(conflict), other);
        String conflictLine =
                "{\"event\":\"fatal\",\"message\":\"Device file probe conflicts with the track\",\"code\":\"DEVICE_PROBE_CONFLICT\",\"path\":\"OMGAUDIO/20P00/10000001.JPG\",\"probe_path\":\"OMGAUDIO/20P00/10000001.JPG.jsymphonic-probe\"}";
        Result refused = invoke("playlist-recover", "--device", conflictDevice.toString());
        assertEquals(refused.out + refused.err, 1, refused.code);
        assertTrue(refused.out, hasLine(refused.out, conflictLine));
        assertFalse(refused.out, refused.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
        assertFalse(refused.out, refused.out.contains("\"event\":\"playlistJournal\""));
        assertArrayEquals(jpeg, Files.readAllBytes(conflict));
        assertArrayEquals(other, Files.readAllBytes(sibling(conflict)));

        Path readDevice = device();
        Path pending = jacket(readDevice, "10000001.JPG", jpeg);
        Files.move(pending, sibling(pending));
        Map<String, byte[]> before = allFiles(readDevice);
        Result listed = invoke("list", "--device", readDevice.toString());
        assertEquals(listed.out + listed.err, 0, listed.code);
        assertTrue(listed.out, hasLine(listed.out, warning("OMGAUDIO/20P00/10000001.JPG")));
        assertFalse(listed.out, listed.out.contains("\"event\":\"fatal\""));
        assertTreeEquals("list", before, allFiles(readDevice));
        assertFalse(Files.exists(pending));
        assertTrue(Files.exists(sibling(pending)));
    }

    @Test public void readCommandsLeaveAPendingProbeUntouched() throws Exception {
        Path device = device();
        Path missing = track(device, "10000001.OMA", BODY);
        Files.move(missing, sibling(missing));
        Path same = track(device, "10000002.OMA", BODY);
        Files.write(sibling(same), BODY);
        Path different = track(device, "10000003.OMA", new byte[] {3, 3, 3, 3, 3, 3, 3, 3});
        Files.write(sibling(different), new byte[] {4, 4, 4, 4, 4, 4, 4, 4});
        Map<String, byte[]> before = allFiles(device);
        String warnMissing = warning("OMGAUDIO/10F00/10000001.OMA");
        String warnSame = warning("OMGAUDIO/10F00/10000002.OMA");
        String warnDifferent = warning("OMGAUDIO/10F00/10000003.OMA");
        String[] commands = new String[] {
            "list", "info", "playlists", "playlist-recover"
        };
        for (String command : commands) {
            Result result = "playlist-recover".equals(command)
                    ? invoke(command, "--device", device.toString(), "--inspect")
                    : invoke(command, "--device", device.toString());
            assertEquals(command + "\n" + result.out + result.err, 0, result.code);
            assertTrue(command + "\n" + result.out, result.out.startsWith(warnMissing + System.lineSeparator())
                    || result.out.startsWith(warnMissing + "\n"));
            int first = result.out.indexOf(warnMissing);
            int second = result.out.indexOf(warnSame);
            int third = result.out.indexOf(warnDifferent);
            assertTrue(command + "\n" + result.out, first >= 0 && first < second && second < third);
            assertFalse(command, result.out.contains("\"event\":\"fatal\""));
            assertTreeEquals(command, before, allFiles(device));
        }
        assertFalse(Files.exists(missing));
        assertTrue(Files.exists(sibling(missing)));
        assertTrue(Files.exists(sibling(same)));
        assertTrue(Files.exists(sibling(different)));
    }

    @Test public void lockIsClassifiedByExceptionTypeNotMessageText() throws Exception {
        Path denied = seeded();
        Map<String, byte[]> beforeDenied = liveLibrary(denied.resolve("OMGAUDIO"));
        OmgaudioJournal.failAudioIo = new java.nio.file.AccessDeniedException("10F00/10000001.OMA", null,
                "fichier utilisé par un autre processus");
        try {
            Result deleted = invoke("del", "--device", denied.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, LOCKED));
        } finally {
            OmgaudioJournal.failAudioIo = null;
        }
        assertLibraryUnchanged(denied, beforeDenied);

        Path sharing = seeded();
        Map<String, byte[]> beforeSharing = liveLibrary(sharing.resolve("OMGAUDIO"));
        FileSystemException shared = new FileSystemException("10F00/10000001.OMA", null,
                "Datei wird von einem anderen Prozess verwendet");
        shared.initCause(new WindowsException(32));
        OmgaudioJournal.failAudioIo = shared;
        try {
            Result deleted = invoke("del", "--device", sharing.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, LOCKED));
        } finally {
            OmgaudioJournal.failAudioIo = null;
        }
        assertLibraryUnchanged(sharing, beforeSharing);

        Path codeOnly = seeded();
        Map<String, byte[]> beforeCode = liveLibrary(codeOnly.resolve("OMGAUDIO"));
        OmgaudioJournal.failAudioIo = new FileSystemException("10F00/10000001.OMA", null, "Unknown error: 0x21");
        try {
            Result deleted = invoke("del", "--device", codeOnly.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, LOCKED));
        } finally {
            OmgaudioJournal.failAudioIo = null;
        }
        assertLibraryUnchanged(codeOnly, beforeCode);

        Path wording = seeded();
        assertPlainAudioFailure(wording, new IOException("locked: fichier verrouillé"), "fichier verrouillé");

        Path sentence = seeded();
        assertPlainAudioFailure(sentence, new FileSystemException("10F00/10000001.OMA", null,
                "Datei wird von einem anderen Prozess verwendet"), "Datei wird von einem anderen Prozess verwendet");

        Path fullRoot = seeded();
        assertPlainAudioFailure(fullRoot, new FileSystemException("10F00/10000001.OMA", null,
                "Das Stammverzeichnis ist voll"), "Das Stammverzeichnis ist voll");

        Path badName = seeded();
        assertPlainAudioFailure(badName, new FileSystemException("bad name"), null);

        Path missing = seeded();
        assertPlainAudioFailure(missing, new NoSuchFileException("10F00/10000001.OMA", null, "locked"), null);
    }

    @Test public void writeProtectedMediaIsReadOnly() throws Exception {
        Path store = seeded();
        Map<String, byte[]> beforeStore = liveLibrary(store.resolve("OMGAUDIO"));
        OmgaudioJournal.readOnlyMedia = true;
        try {
            Result deleted = invoke("del", "--device", store.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, READ_ONLY));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
            assertFalse(deleted.out, deleted.out.contains(NWOmgaudio.DEVICE_ROLLBACK_FAILED));
        } finally {
            OmgaudioJournal.readOnlyMedia = false;
        }
        assertLibraryUnchanged(store, beforeStore);

        Path filesystem = seeded();
        Map<String, byte[]> beforeFs = liveLibrary(filesystem.resolve("OMGAUDIO"));
        OmgaudioJournal.failAudioUnchecked = new ReadOnlyFileSystemException();
        try {
            Result deleted = invoke("del", "--device", filesystem.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertTrue(deleted.out, hasLine(deleted.out, READ_ONLY));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
        } finally {
            OmgaudioJournal.failAudioUnchecked = null;
        }
        assertLibraryUnchanged(filesystem, beforeFs);
    }

    private static void assertPlainAudioFailure(Path device, IOException injected, String expectedText) throws Exception {
        Path audio = device.resolve("OMGAUDIO/10F00/10000001.OMA");
        byte[] audioBefore = Files.readAllBytes(audio);
        OmgaudioJournal.failAudioIo = injected;
        try {
            Result deleted = invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15");
            assertEquals(deleted.out + deleted.err, 1, deleted.code);
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_LOCKED\""));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_FILE_READ_ONLY\""));
            assertFalse(deleted.out, deleted.out.contains("\"code\":\"DEVICE_ROLLBACK_FAILED\""));
            if (expectedText != null) assertTrue(deleted.out, deleted.out.contains(expectedText));
        } finally {
            OmgaudioJournal.failAudioIo = null;
        }
        assertArrayEquals(audioBefore, Files.readAllBytes(audio));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    private static void assertPlaylistRollback(Path device, String... args) throws Exception {
        OmgaudioJournal.failNextPublish = true;
        OmgaudioJournal.failRollbackRestore = true;
        try {
            Result result = invoke(args);
            assertEquals(result.out + result.err, 1, result.code);
            assertTrue(result.out, hasLine(result.out, ROLLBACK));
            assertFalse(result.out, result.out.contains("\"path\""));
            assertFalse(result.out, result.out.contains("\"event\":\"done\""));
        } finally {
            OmgaudioJournal.failNextPublish = false;
            OmgaudioJournal.failRollbackRestore = false;
        }
        assertTrue(Files.isRegularFile(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY).resolve("commit")));
    }

    /** Stand-in for {@code sun.nio.fs.WindowsException}. {@code lastError()} is the Win32 code. */
    private static final class WindowsException extends Exception {
        private final int code;
        WindowsException(int code) { this.code = code; }
        public int lastError() { return code; }
    }

    private static String warning(String path) {
        return "{\"event\":\"warning\",\"code\":\"DEVICE_PROBE_PENDING\",\"path\":\"" + path
                + "\",\"probe_path\":\"" + path + ".jsymphonic-probe\"}";
    }

    private static void assertTreeEquals(String command, Map<String, byte[]> before, Map<String, byte[]> after) {
        assertEquals(command, before.keySet(), after.keySet());
        for (String path : before.keySet()) assertArrayEquals(command + " " + path, before.get(path), after.get(path));
    }

    private static Map<String, byte[]> allFiles(Path root) throws Exception {
        final Map<String, byte[]> tree = new TreeMap<String, byte[]>();
        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                String rel = root.relativize(dir).toString().replace('\\', '/');
                if (!rel.isEmpty()) tree.put(rel + "/", new byte[0]);
                return FileVisitResult.CONTINUE;
            }
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                String rel = root.relativize(file).toString().replace('\\', '/');
                tree.put(rel, Files.readAllBytes(file));
                return FileVisitResult.CONTINUE;
            }
        });
        return tree;
    }

    private static void crashProbe(Path device, String id) throws Exception {
        NWOmgaudio.interruptProbeAfterRenameAway = true;
        try {
            Result crashed = invoke("del", "--device", device.toString(), "--id", id, "--idle-timeout", "15");
            assertEquals(crashed.out + crashed.err, 1, crashed.code);
            assertFalse(crashed.out, crashed.out.contains("\"event\":\"done\""));
        } finally {
            NWOmgaudio.interruptProbeAfterRenameAway = false;
        }
    }

    private static Path jacket(Path device, String name, byte[] body) throws Exception {
        Files.createDirectories(device.resolve("OMGAUDIO/20P00"));
        Path file = device.resolve("OMGAUDIO/20P00").resolve(name);
        Files.write(file, body);
        return file;
    }

    private static Path track(Path device, String name, byte[] body) throws Exception {
        Files.createDirectories(device.resolve("OMGAUDIO/10F00"));
        Path audio = device.resolve("OMGAUDIO/10F00").resolve(name);
        Files.write(audio, body);
        return audio;
    }

    private static Path sibling(Path audio) {
        return audio.resolveSibling(audio.getFileName().toString() + OmgaudioJournal.PROBE_SUFFIX);
    }

    private static void clearReadOnly(Path file) {
        try {
            Files.setPosixFilePermissions(file, EnumSet.of(
                    PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
        } catch (Exception ignored) {
        }
        try {
            DosFileAttributeView view = Files.getFileAttributeView(file, DosFileAttributeView.class);
            if (view != null) view.setReadOnly(false);
        } catch (Exception ignored) {
        }
    }

    private static void markReadOnly(Path file) throws Exception {
        try {
            Files.setPosixFilePermissions(file, EnumSet.of(
                    PosixFilePermission.OWNER_READ,
                    PosixFilePermission.GROUP_READ,
                    PosixFilePermission.OTHERS_READ));
        } catch (UnsupportedOperationException ex) {
            DosFileAttributeView view = Files.getFileAttributeView(file, DosFileAttributeView.class);
            if (view == null) throw ex;
            view.setReadOnly(true);
        }
    }

    private static boolean hasLine(String out, String line) {
        for (String candidate : out.split("\\r?\\n", -1)) if (candidate.equals(line)) return true;
        return false;
    }

    private static Path seeded() throws Exception {
        Path device = device();
        Files.write(device.resolve("OMGAUDIO/NOTES.TXT"), "leave-this".getBytes(StandardCharsets.UTF_8));
        track(device, "10000001.OMA", BODY);
        return device;
    }

    /** Tables and audio, excluding the backup copy and the journal directory. */
    private static Map<String, byte[]> liveLibrary(Path omgaudio) throws Exception {
        final Map<String, byte[]> tree = new TreeMap<String, byte[]>();
        Files.walkFileTree(omgaudio, new SimpleFileVisitor<Path>() {
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws java.io.IOException {
                String rel = omgaudio.relativize(file).toString().replace('\\', '/');
                String lower = rel.toLowerCase(java.util.Locale.ROOT);
                if (lower.equals("db_backup") || lower.startsWith("db_backup/")
                        || lower.equals(OmgaudioJournal.DIRECTORY.toLowerCase(java.util.Locale.ROOT))
                        || lower.startsWith(OmgaudioJournal.DIRECTORY.toLowerCase(java.util.Locale.ROOT) + "/"))
                    return FileVisitResult.CONTINUE;
                tree.put(rel, Files.readAllBytes(file));
                return FileVisitResult.CONTINUE;
            }
        });
        return tree;
    }

    private static void assertLibraryUnchanged(Path device, Map<String, byte[]> before) throws Exception {
        Path root = device.resolve("OMGAUDIO");
        Map<String, byte[]> after = liveLibrary(root);
        assertEquals(before.keySet(), after.keySet());
        for (String path : before.keySet()) assertArrayEquals(path, before.get(path), after.get(path));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(hasProbeSibling(root));
    }

    private static boolean hasProbeSibling(Path omgaudio) throws Exception {
        final boolean[] found = new boolean[] { false };
        Files.walkFileTree(omgaudio, new SimpleFileVisitor<Path>() {
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (file.getFileName().toString().toLowerCase(java.util.Locale.ROOT).endsWith(OmgaudioJournal.PROBE_SUFFIX))
                    found[0] = true;
                return FileVisitResult.CONTINUE;
            }
        });
        return found[0];
    }

    private static Path device() throws Exception {
        Path device = Files.createTempDirectory("device-file-failure-");
        Files.createDirectories(device.resolve("OMGAUDIO"));
        return device;
    }

    private static Result invoke(String... args) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        int code = HeadlessCli.run(args, new PrintStream(out, true, "UTF-8"), new PrintStream(err, true, "UTF-8"));
        return new Result(code, out.toString("UTF-8"), err.toString("UTF-8"));
    }

    private static final class Result {
        final int code;
        final String out;
        final String err;
        Result(int code, String out, String err) { this.code = code; this.out = out; this.err = err; }
    }

    private static final class QuietListener implements NWGenericListener {
        private final CountDownLatch done;
        QuietListener(CountDownLatch done) { this.done = done; }
        public void transferInitialization(int a, int b, int c, int d, int e, int f) {}
        public void transferTermination() { done.countDown(); }
        public void transferStepStarted(int step) {}
        public void transferStepFinished(int step, String errorMessage) {}
        public void fileChanged(int step, String name) {}
        public void fileProgressChanged(int step, double value, double speed) {}
        public void loadingInitialization(int numberOfFile) {}
        public void loadingProgresChanged(double value) {}
        public void showPlayerFullMsg() {}
    }
}
