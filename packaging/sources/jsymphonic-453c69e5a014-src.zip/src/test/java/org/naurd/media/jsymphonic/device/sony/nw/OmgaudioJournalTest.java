package org.naurd.media.jsymphonic.device.sony.nw;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.naurd.media.jsymphonic.title.Title;
import static org.junit.Assert.*;

public class OmgaudioJournalTest {
    @Test public void interruptionAtEachStepReconcilesToOneSnapshot() throws Exception {
        byte[] oldBase = "old-base".getBytes("UTF-8");
        byte[] newBase = "new-base-bytes".getBytes("UTF-8");
        byte[] oldInfo = "old-info".getBytes("UTF-8");
        byte[] newInfo = "new-info-bytes".getBytes("UTF-8");
        byte[] kept = new byte[] {1, 2, 3, 4, 5};
        byte[] added = new byte[] {9, 8, 7, 6, 5};
        List<OmgaudioJournal.FileSpec> files = Arrays.asList(
                new OmgaudioJournal.FileSpec("02TREINF.DAT", oldBase, newBase),
                new OmgaudioJournal.FileSpec("03ginf22.dat", oldInfo, newInfo));
        Path payload = Files.createTempFile("journal-add-", ".oma");
        Files.write(payload, added);
        List<String> steps;
        Path sample = Files.createTempDirectory("journal-plan-");
        try {
            Files.write(sample.resolve("10000001.OMA"), kept);
            List<OmgaudioJournal.AudioSpec> audio = Arrays.asList(
                    new OmgaudioJournal.AudioSpec(true, "10F00/10000001.OMA", sample.resolve("10000001.OMA")),
                    new OmgaudioJournal.AudioSpec(false, "10F00/10000002.OMA", payload));
            steps = OmgaudioJournal.plan(files, audio);
            int commit = steps.indexOf("commit");
            assertTrue(commit > 0);
            for (String step : steps) {
                Path root = Files.createTempDirectory("journal-step-");
                Files.write(root.resolve("02TREINF.DAT"), oldBase);
                Files.write(root.resolve("03ginf22.dat"), oldInfo);
                Files.createDirectories(root.resolve("10F00"));
                Files.write(root.resolve("10F00/10000001.OMA"), kept);
                List<OmgaudioJournal.AudioSpec> attempt = Arrays.asList(
                        new OmgaudioJournal.AudioSpec(true, "10F00/10000001.OMA", root.resolve("10F00/10000001.OMA")),
                        new OmgaudioJournal.AudioSpec(false, "10F00/10000002.OMA", payload));
                try {
                    OmgaudioJournal.commit(root, files, attempt, null, new OmgaudioJournal.Probe() {
                        public void step(String name) {
                            if (name.equals(step)) throw new OmgaudioJournal.Interrupt(name);
                        }
                    });
                    fail(step);
                } catch (OmgaudioJournal.Interrupt expected) {
                    assertEquals(step, expected.step);
                }
                OmgaudioJournal.Report pending = OmgaudioJournal.inspect(root);
                assertTrue(step, pending.pending);
                // cleanup-retired runs only after the commit marker has been deleted.
                // The live tree is already the new snapshot; recover must discard the
                // journal instead of treating the half-removed directory as committed.
                boolean published = steps.indexOf(step) >= commit;
                boolean forward = published && !"cleanup-retired".equals(step);
                assertEquals(step, forward ? "roll-forward" : "roll-back", pending.action);
                if ("cleanup-retired".equals(step)) {
                    assertEquals(step, "uncommitted", pending.state);
                    assertFalse(step, pending.committed);
                }
                byte[][] beforeRecover = new byte[][] {
                    Files.readAllBytes(root.resolve("02TREINF.DAT")),
                    Files.readAllBytes(root.resolve("03ginf22.dat"))
                };
                OmgaudioJournal.inspect(root);
                assertArrayEquals(beforeRecover[0], Files.readAllBytes(root.resolve("02TREINF.DAT")));
                assertArrayEquals(beforeRecover[1], Files.readAllBytes(root.resolve("03ginf22.dat")));
                OmgaudioJournal.recover(root);
                assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
                if (published) {
                    assertArrayEquals(step, newBase, Files.readAllBytes(root.resolve("02TREINF.DAT")));
                    assertArrayEquals(step, newInfo, Files.readAllBytes(root.resolve("03ginf22.dat")));
                    assertFalse(step, Files.exists(root.resolve("10F00/10000001.OMA")));
                    assertArrayEquals(step, added, Files.readAllBytes(root.resolve("10F00/10000002.OMA")));
                } else {
                    assertArrayEquals(step, oldBase, Files.readAllBytes(root.resolve("02TREINF.DAT")));
                    assertArrayEquals(step, oldInfo, Files.readAllBytes(root.resolve("03ginf22.dat")));
                    assertArrayEquals(step, kept, Files.readAllBytes(root.resolve("10F00/10000001.OMA")));
                    assertFalse(step, Files.exists(root.resolve("10F00/10000002.OMA")));
                }
            }
        } finally {
            payload.toFile().delete();
        }
    }

    @Test public void inspectDoesNotMutateAndLegacyJournalsRollForward() throws Exception {
        Path root = Files.createTempDirectory("journal-inspect-");
        Files.write(root.resolve("MARKER.DAT"), "live".getBytes("UTF-8"));
        Path journal = root.resolve(OmgaudioJournal.DIRECTORY);
        Files.createDirectory(journal);
        Files.write(journal.resolve("format"), "2\n".getBytes("UTF-8"));
        Files.write(journal.resolve("MARKER.DAT.next"), "next".getBytes("UTF-8"));
        byte[] before = Files.readAllBytes(root.resolve("MARKER.DAT"));
        OmgaudioJournal.Report report = OmgaudioJournal.inspect(root);
        assertTrue(report.pending);
        assertFalse(report.committed);
        assertEquals("roll-back", report.action);
        assertArrayEquals(before, Files.readAllBytes(root.resolve("MARKER.DAT")));
        assertTrue(Files.exists(journal));
        OmgaudioJournal.recover(root);
        assertArrayEquals("live".getBytes("UTF-8"), Files.readAllBytes(root.resolve("MARKER.DAT")));
        assertFalse(Files.exists(journal));

        Path legacy = Files.createTempDirectory("journal-legacy-");
        Path old = legacy.resolve(OmgaudioJournal.DIRECTORY);
        Files.createDirectory(old);
        Files.write(old.resolve("tree.next"), "TREE".getBytes("UTF-8"));
        Files.write(old.resolve("info.next"), "INFO".getBytes("UTF-8"));
        Files.write(old.resolve("files.txt"), "01TREE22.DAT\n03GINF22.DAT\n".getBytes("UTF-8"));
        OmgaudioJournal.Report seen = OmgaudioJournal.inspect(legacy);
        assertEquals("roll-forward", seen.action);
        assertEquals(Arrays.asList("01TREE22.DAT", "03GINF22.DAT"), seen.files);
        assertFalse(Files.exists(legacy.resolve("01TREE22.DAT")));
        OmgaudioJournal.recover(legacy);
        assertEquals("TREE", new String(Files.readAllBytes(legacy.resolve("01TREE22.DAT")), "UTF-8"));
        assertEquals("INFO", new String(Files.readAllBytes(legacy.resolve("03GINF22.DAT")), "UTF-8"));
        assertFalse(Files.exists(old));
    }

    @Test public void injectedPublishFailureRestoresBaseAndPlaylistTogether() throws Exception {
        Path root = Files.createTempDirectory("journal-rollback-");
        byte[] base = "base-v1".getBytes("UTF-8");
        byte[] info = "info-v1".getBytes("UTF-8");
        Files.write(root.resolve("01TREE01.DAT"), base);
        Files.write(root.resolve("03ginf22.dat"), info);
        List<OmgaudioJournal.FileSpec> files = Arrays.asList(
                new OmgaudioJournal.FileSpec("01TREE01.DAT", base, "base-v2".getBytes("UTF-8")),
                new OmgaudioJournal.FileSpec("03ginf22.dat", info, "info-v2".getBytes("UTF-8")));
        try {
            OmgaudioJournal.commit(root, files, new ArrayList<OmgaudioJournal.AudioSpec>(), new NativePlaylistDatabase.Publisher() {
                int calls;
                public void publish(Path source, Path target) throws java.io.IOException {
                    if (++calls == 2) throw new java.io.IOException("injected second-file I/O failure");
                    Files.move(source, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
            }, null);
            fail("I/O failure must surface");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage(), expected.getMessage().contains("injected"));
        }
        assertArrayEquals(base, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertArrayEquals(info, Files.readAllBytes(root.resolve("03ginf22.dat")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void databaseWriteKeepsFilesAndTablesTogether() throws Exception {
        Path root = Files.createTempDirectory("journal-write-");
        org.naurd.media.jsymphonic.toolBox.DataBaseOmgaudioToolBox.write02TREINF(
                root.toFile(), new java.util.HashMap<Object, Object>());
        byte[] treinf = Files.readAllBytes(root.resolve("02treinf.dat"));
        byte[] sentinel = "sentinel-base-table".getBytes("UTF-8");
        Files.write(root.resolve("01TREE01.DAT"), sentinel);
        NativePlaylistDatabase playlists = NativePlaylistDatabase.read(root.toFile());
        playlists.create("Night", Collections.singletonList(1), Collections.singleton(1));
        playlists.save();
        byte[] tree = Files.readAllBytes(root.resolve("01tree22.dat"));
        Files.createDirectories(root.resolve("10F00"));
        Path audio = root.resolve("10F00/10000001.OMA");
        Files.write(audio, new byte[] {1, 2, 3, 4, 5, 6});

        DataBaseOmgaudio database = new DataBaseOmgaudio(root.toFile(), true, false, false, false, false);
        Title title = new Title();
        database.addTitle(title, 1);
        database.prepareWrite();
        database.delete(title);
        database.deferDeletion(audio.toFile());
        database.setJournalProbe(new OmgaudioJournal.Probe() {
            public void step(String name) {
                if ("directory".equals(name)) throw new OmgaudioJournal.Interrupt(name);
            }
        });
        try {
            database.write(stub());
            fail("interrupt");
        } catch (OmgaudioJournal.Interrupt expected) { }
        assertArrayEquals(sentinel, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertArrayEquals(treinf, Files.readAllBytes(root.resolve("02treinf.dat")));
        assertArrayEquals(tree, Files.readAllBytes(root.resolve("01tree22.dat")));
        assertTrue(Files.exists(audio));
        OmgaudioJournal.recover(root);
        assertArrayEquals(sentinel, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertArrayEquals(tree, Files.readAllBytes(root.resolve("01tree22.dat")));
        assertTrue(Files.exists(audio));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));

        database = new DataBaseOmgaudio(root.toFile(), true, false, false, false, false);
        Title published = new Title();
        database.addTitle(published, 1);
        database.prepareWrite();
        database.delete(published);
        database.deferDeletion(audio.toFile());
        database.setJournalProbe(new OmgaudioJournal.Probe() {
            public void step(String name) throws java.io.IOException {
                if (name.startsWith("publish:") && name.toLowerCase().contains("tree22"))
                    throw new java.io.IOException("injected playlist publish failure");
            }
        });
        database.write(stub());
        assertArrayEquals(sentinel, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertArrayEquals(tree, Files.readAllBytes(root.resolve("01tree22.dat")));
        assertTrue(Files.exists(audio));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));

        database = new DataBaseOmgaudio(root.toFile(), true, false, false, false, false);
        Title committed = new Title();
        database.addTitle(committed, 1);
        database.prepareWrite();
        database.delete(committed);
        database.deferDeletion(audio.toFile());
        database.setJournalProbe(new OmgaudioJournal.Probe() {
            public void step(String name) {
                if ("commit".equals(name)) throw new OmgaudioJournal.Interrupt(name);
            }
        });
        try {
            database.write(stub());
            fail("interrupt after commit");
        } catch (OmgaudioJournal.Interrupt expected) { }
        assertTrue(Files.exists(audio));
        OmgaudioJournal.recover(root);
        assertFalse(Files.exists(audio));
        assertFalse("sentinel must be replaced with the rendered table",
                Arrays.equals(sentinel, Files.readAllBytes(root.resolve("01TREE01.DAT"))));
        assertFalse(Arrays.equals(tree, Files.readAllBytes(root.resolve("01tree22.dat"))));
        assertEquals(Collections.emptyList(), NativePlaylistDatabase.read(root.toFile()).list().get(0).trackIds);
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
        try (java.util.stream.Stream<Path> listing = Files.list(root)) {
            for (Path file : (Iterable<Path>) listing::iterator)
                assertFalse(file.getFileName().toString(), file.getFileName().toString().contains("jsymphonic-tmp"));
        }
    }

    @Test public void readBackFailureRestoresTheFileThatFailedVerification() throws Exception {
        Path root = Files.createTempDirectory("journal-readback-");
        byte[] first = "first-v1".getBytes("UTF-8");
        byte[] second = "second-v1".getBytes("UTF-8");
        Files.write(root.resolve("01TREE01.DAT"), first);
        Files.write(root.resolve("03ginf22.dat"), second);
        List<OmgaudioJournal.FileSpec> files = Arrays.asList(
                new OmgaudioJournal.FileSpec("01TREE01.DAT", first, "first-v2".getBytes("UTF-8")),
                new OmgaudioJournal.FileSpec("03ginf22.dat", second, "second-v2".getBytes("UTF-8")));
        try {
            OmgaudioJournal.commit(root, files, new ArrayList<OmgaudioJournal.AudioSpec>(), new NativePlaylistDatabase.Publisher() {
                int calls;
                public void publish(Path source, Path target) throws java.io.IOException {
                    if (++calls == 1) Files.move(source, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    else Files.write(target, "corrupt-readback".getBytes("UTF-8"));
                }
            }, null);
            fail("read-back must fail");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage(), expected.getMessage().contains("verification failed"));
            assertTrue(expected.getMessage(), expected.getMessage().contains("03ginf22.dat"));
        }
        assertArrayEquals(first, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertArrayEquals(second, Files.readAllBytes(root.resolve("03ginf22.dat")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void backupCopyFailureStillReportsASuccessfulCommit() throws Exception {
        Path root = Files.createTempDirectory("journal-backup-");
        org.naurd.media.jsymphonic.toolBox.DataBaseOmgaudioToolBox.write02TREINF(
                root.toFile(), new java.util.HashMap<Object, Object>());
        byte[] sentinel = "sentinel-base-table".getBytes("UTF-8");
        Files.write(root.resolve("01TREE01.DAT"), sentinel);
        Files.createDirectories(root.resolve("10F00"));
        Path audio = root.resolve("10F00/10000001.OMA");
        Files.write(audio, new byte[] {1, 2, 3, 4, 5, 6});
        DataBaseOmgaudio database = new DataBaseOmgaudio(root.toFile(), true, false, false, false, false);
        Title title = new Title();
        database.addTitle(title, 1);
        database.prepareWrite();
        database.delete(title);
        database.deferDeletion(audio.toFile());
        database.failBackupCopies();
        final List<String> errors = new ArrayList<String>();
        final List<String> codes = new ArrayList<String>();
        final List<String> successes = new ArrayList<String>();
        database.write(new NWGeneric("walkman", "", null, null, "export") {
            protected void applyDeletion() {}
            protected void applyExport() {}
            protected void applyImport() {}
            protected void loadTitlesFromDevice() {}
            public void sendFatalCode(String code) { codes.add(String.valueOf(code)); }
            protected void sendTransferStepFinished(int step, String error) {
                if (error == null || error.isEmpty()) successes.add(step + ":ok");
                else errors.add(error);
            }
        });
        assertTrue(codes.toString(), codes.isEmpty());
        assertTrue(errors.toString(), errors.isEmpty());
        assertFalse(successes.toString(), successes.isEmpty());
        assertFalse(Files.exists(audio));
        assertFalse("tables must be published",
                Arrays.equals(sentinel, Files.readAllBytes(root.resolve("01TREE01.DAT"))));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void runtimeExceptionBeforeCommitDiscardsItsJournal() throws Exception {
        Path root = Files.createTempDirectory("journal-runtime-before-");
        byte[] original = "live".getBytes("UTF-8");
        Files.write(root.resolve("01TREE01.DAT"), original);
        List<OmgaudioJournal.FileSpec> files = Collections.singletonList(
                new OmgaudioJournal.FileSpec("01TREE01.DAT", original, "next".getBytes("UTF-8")));
        try {
            OmgaudioJournal.commit(root, files, new ArrayList<OmgaudioJournal.AudioSpec>(), null, new OmgaudioJournal.Probe() {
                public void step(String name) {
                    if ("manifest".equals(name)) throw new IllegalStateException("before commit");
                }
            });
            fail("runtime failure must surface");
        } catch (IllegalStateException expected) {
            assertEquals("before commit", expected.getMessage());
        }
        assertArrayEquals(original, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
        OmgaudioJournal.commit(root, files, new ArrayList<OmgaudioJournal.AudioSpec>(), null, null);
        assertEquals("next", new String(Files.readAllBytes(root.resolve("01TREE01.DAT")), "UTF-8"));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void errorBeforeCommitDiscardsItsJournal() throws Exception {
        Path root = Files.createTempDirectory("journal-error-before-");
        byte[] original = "live".getBytes("UTF-8");
        Files.write(root.resolve("01TREE01.DAT"), original);
        List<OmgaudioJournal.FileSpec> files = Collections.singletonList(
                new OmgaudioJournal.FileSpec("01TREE01.DAT", original, "next".getBytes("UTF-8")));
        try {
            OmgaudioJournal.commit(root, files, new ArrayList<OmgaudioJournal.AudioSpec>(), null, new OmgaudioJournal.Probe() {
                public void step(String name) {
                    if ("format".equals(name)) throw new OutOfMemoryError("before commit");
                }
            });
            fail("Error must surface");
        } catch (OutOfMemoryError expected) {
            assertEquals("before commit", expected.getMessage());
        }
        assertArrayEquals(original, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
        OmgaudioJournal.commit(root, files, new ArrayList<OmgaudioJournal.AudioSpec>(), null, null);
        assertEquals("next", new String(Files.readAllBytes(root.resolve("01TREE01.DAT")), "UTF-8"));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void runtimeExceptionAfterCommitRollsTheBatchBack() throws Exception {
        Path root = Files.createTempDirectory("journal-runtime-");
        byte[] original = "live".getBytes("UTF-8");
        Files.write(root.resolve("01TREE01.DAT"), original);
        List<OmgaudioJournal.FileSpec> files = Collections.singletonList(
                new OmgaudioJournal.FileSpec("01TREE01.DAT", original, "next".getBytes("UTF-8")));
        try {
            OmgaudioJournal.commit(root, files, new ArrayList<OmgaudioJournal.AudioSpec>(), null, new OmgaudioJournal.Probe() {
                public void step(String name) {
                    if ("publish:01TREE01.DAT".equals(name)) throw new IllegalStateException("boom");
                }
            });
            fail("runtime failure must surface");
        } catch (IllegalStateException expected) {
            assertEquals("boom", expected.getMessage());
        }
        assertArrayEquals(original, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void strayTempFilesStayOnReadAndAreSweptOnRecover() throws Exception {
        Path root = Files.createTempDirectory("journal-stray-");
        Files.write(root.resolve("STRAY.jsymphonic-tmp"), new byte[] {1, 2, 3});
        Files.createDirectories(root.resolve("10F00"));
        Files.write(root.resolve("10F00/a.oma.jsymphonic-tmp"), new byte[] {4});
        Files.createDirectories(root.resolve(OmgaudioJournal.RETIRED));
        Files.write(root.resolve(OmgaudioJournal.RETIRED).resolve("leftover"), new byte[] {5});
        NativePlaylistDatabase.read(root.toFile());
        assertTrue(Files.exists(root.resolve("STRAY.jsymphonic-tmp")));
        assertTrue(Files.exists(root.resolve("10F00/a.oma.jsymphonic-tmp")));
        assertTrue(Files.exists(root.resolve(OmgaudioJournal.RETIRED)));

        Path again = Files.createTempDirectory("journal-stray-recover-");
        Files.write(again.resolve("MARKER.DAT"), "live".getBytes("UTF-8"));
        Files.write(again.resolve("MARKER.DAT.jsymphonic-tmp"), new byte[] {9});
        Files.createDirectories(again.resolve("10F00"));
        Files.write(again.resolve("10F00/a.oma.jsymphonic-tmp"), new byte[] {4});
        Files.write(again.resolve("10F00/b.OMA.jsymphonic-tmp"), new byte[] {6});
        Files.write(again.resolve("10F00/note.txt.jsymphonic-tmp"), new byte[] {8});
        Path journal = again.resolve(OmgaudioJournal.DIRECTORY);
        Files.createDirectory(journal);
        Files.write(journal.resolve("format"), "2\n".getBytes("UTF-8"));
        Files.write(journal.resolve("files.txt"), "MARKER.DAT\n".getBytes("UTF-8"));
        Files.write(journal.resolve("MARKER.DAT.before"), "live".getBytes("UTF-8"));
        Files.write(journal.resolve("MARKER.DAT.next"), "next".getBytes("UTF-8"));
        Files.write(journal.resolve("staged.jsymphonic-tmp"), new byte[] {7});
        OmgaudioJournal.recover(again);
        assertEquals("live", new String(Files.readAllBytes(again.resolve("MARKER.DAT")), "UTF-8"));
        assertFalse(Files.exists(again.resolve("MARKER.DAT.jsymphonic-tmp")));
        assertFalse(Files.exists(journal));
        assertFalse(Files.exists(again.resolve("10F00/a.oma.jsymphonic-tmp")));
        assertFalse(Files.exists(again.resolve("10F00/b.OMA.jsymphonic-tmp")));
        assertTrue(Files.exists(again.resolve("10F00/note.txt.jsymphonic-tmp")));
    }

    @Test public void audioPublishFailureIsNotDescribedAsAPlaylistError() throws Exception {
        Path root = Files.createTempDirectory("journal-audio-error-");
        org.naurd.media.jsymphonic.toolBox.DataBaseOmgaudioToolBox.write02TREINF(
                root.toFile(), new java.util.HashMap<Object, Object>());
        Files.createDirectories(root.resolve("10F00"));
        Path audio = root.resolve("10F00/10000001.OMA");
        Files.write(audio, new byte[] {1, 2, 3, 4, 5, 6});
        NativePlaylistDatabase playlists = NativePlaylistDatabase.read(root.toFile());
        playlists.create("Night", Collections.singletonList(1), Collections.singleton(1));
        playlists.save();
        final List<String> errors = new ArrayList<String>();
        final List<String> codes = new ArrayList<String>();
        DataBaseOmgaudio database = new DataBaseOmgaudio(root.toFile(), true, false, false, false, false);
        Title title = new Title();
        database.addTitle(title, 1);
        database.prepareWrite();
        database.delete(title);
        database.deferDeletion(audio.toFile());
        database.setJournalProbe(new OmgaudioJournal.Probe() {
            public void step(String name) throws java.io.IOException {
                if (name.startsWith("publish-audio:"))
                    throw new java.io.IOException("Audio file could not be deleted: " + name);
            }
        });
        database.write(new NWGeneric("walkman", "", null, null, "export") {
            protected void applyDeletion() {}
            protected void applyExport() {}
            protected void applyImport() {}
            protected void loadTitlesFromDevice() {}
            public void sendFatalCode(String code) { codes.add(String.valueOf(code)); }
            protected void sendTransferStepFinished(int step, String error) {
                if (error != null && !error.isEmpty()) errors.add(error);
            }
        });
        assertTrue(errors.toString(), errors.size() > 0);
        String joined = errors.toString();
        assertTrue(joined, joined.contains("Audio file could not be deleted"));
        assertTrue(joined, joined.contains("Database update failed"));
        assertFalse(joined, joined.contains("PLAYLIST_"));
        assertFalse(joined, joined.contains("Native playlists"));
        assertTrue(codes.toString(), codes.isEmpty());
        assertTrue(Files.exists(audio));
    }

    private static NWGeneric stub() {
        return new NWGeneric("walkman", "", null, null, "export") {
            protected void applyDeletion() {}
            protected void applyExport() {}
            protected void applyImport() {}
            protected void loadTitlesFromDevice() {}
        };
    }
}
