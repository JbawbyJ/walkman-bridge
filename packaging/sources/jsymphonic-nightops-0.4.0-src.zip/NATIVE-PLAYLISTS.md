# Native Sony playlists

The headless engine reads and edits the native `OMGAUDIO/01TREE22.DAT` and
`03GINF22.DAT` playlist tables. It does not write an M3U file or alter audio to
represent a playlist. Playlist operations leave every other device file intact.

## Commands and protocol

```
playlists --device <mount>
playlist-create --device <mount> --name-base64 <UTF-8-base64> [track-id ...]
playlist-update --device <mount> --id <playlist-id> [--name-base64 <UTF-8-base64>] [--tracks <id,id,...>]
playlist-delete --device <mount> --id <playlist-id>
```

All commands use the existing `HeadlessCli` entry point. `playlists` emits a row
for each active group, followed by `{"event":"playlistsEnd","count":N}`:

```json
{"event":"playlist","id":"3","name":"Night walk","trackIds":["14","1","3"]}
```

Create/update emit the changed row only after both tables have been written and
read back successfully, then `{"event":"done"}`. Delete emits `done`. Failures
emit `fatal` and return nonzero. An update without a name or track-list argument
is a usage error. `--tracks ""` explicitly clears membership; omitting the option
retains membership. Delete removes only the playlist group, never audio tracks.

`--name-base64` carries the name as standard base64 of its UTF-8 bytes. Malformed
base64 or UTF-8 is rejected before mutation. Use this option for all names from
wrappers: the Windows Java launcher can corrupt non-ANSI command-line text
before `main()` receives it, even with UTF-8 JVM settings. `--name <text>` remains
available for direct CLI use; the two name options are mutually exclusive.

Names are limited to 60 UTF-16 code units, with no control/format characters or
unpaired surrogates. They are not truncated. Track IDs are decimal values
1–65535 and must exist in the loaded device library. Duplicate member IDs are
preserved because a playlist may intentionally repeat a track. There are at
most 2048 metadata slots and 65534 total membership entries.

## Format evidence

The Java implementation was written independently from the format facts in
[mattn/sonydb](https://github.com/mattn/sonydb/blob/master/sonydb.cpp), the
BSD-licensed Linux port of Winamp ML_SONY. The source's `readAllPlaylist`,
`write_01TREEXX(...,22)` and `write_03GINFXX(...,22)` establish:

- `TREE` consists of 8-byte `GPLB` groups and 2-byte `TPLB` track IDs, big endian.
- `GPLB` refers to a one-based metadata slot and a one-based start in `TPLB`;
  the next group's start ends the previous group's ordered membership.
- Active groups use `0x0100`. The writer reserves `0x4010` bytes for the group
  section, putting `TPLB` at `0x4040`.
- `GPIF/GPFB` records for playlists are `0x310` bytes, including six `0x80`-byte
  tags. `TIT2`, with encoding `0x0002`, contains the UTF-16BE playlist name.

The inspected source file's SHA-256 is
`0a5eb09b1098d12773ae21ebee62d7846e7340f68404f2583d6e0d300299c904`.
No source code from that project is copied or translated into this engine.

The existing `reference/omgaudio_files_version2.xls` (outside this repository)
documents the generic class headers and group/track offsets but explicitly
leaves populated playlist semantics unimplemented. It is not treated as proof
of populated playlist handling. The independent source provides that evidence.

The locally supplied Sony NW-S705F backup has zero active `GPLB` memberships but
two opaque `GPFB` metadata slots. New playlists append after these slots; the
two existing records remain byte-identical. Unreferenced and deleted slots are
never compacted or reused. Playlist IDs therefore remain stable across this
engine's edits; an external application can reindex the database, so clients
must still refresh their device snapshot and use ETags.

## Preservation and failure behavior

The parser validates file bounds, version, class sizes, offsets, membership
ownership, slot IDs and supported metadata encoding before mutation. Unknown
group types and nonzero padding are rejected, rather than silently normalized.
Opaque metadata records, untouched tags, and reserved TREE file-header and
descriptor bytes remain byte-identical. TREE class complement fields are
accepted only as the known count mirror (or zero) plus a zero second field;
unknown complement semantics are rejected before any write.

Both playlist files and their originals are staged and synced in
`.jsymphonic-playlist-transaction` before either destination is replaced. The
new pair is read back before success. An ordinary I/O failure restores and
verifies both originals; a forced termination or unsuccessful rollback leaves
the transaction directory and blocks subsequent playlist reads and device
writes. This is a recoverable journal, not a claim of FAT multi-file atomicity.
Recovery requires a verified backup and review of the saved before-files;
the engine does not guess which interrupted state the user intended.

Ordinary track add/delete validates native playlists before starting media
work. It retains playlist order and metadata, removing only memberships of
tracks actually removed from the library. Empty playlists are retained.
The legacy database rebuild now deletes only its explicit list of base tables;
it preserves Sony cover folders, search extensions, configuration and unknown
files. It retains the existing global tree catalog and changes only known
base-tree duration fields in `02TREINF.DAT`. Advanced Sony indexes remain
preserved, but this engine does not regenerate their unsupported semantics.
The broader legacy audio/base-database transfer is not crash-atomic.

## Verification

Ordinary `mvn test` runs the binary, failure-recovery and CLI contract tests.
To also verify a full saved Sony fixture, use:

```
mvn -Dsony.playlist.fixture=<absolute-path-to-saved-backup-folder> test
```

The fixture tests copy input into temporary directories before any mutation.
Never supply a live device as a fixture. Tests cover native CRUD and fresh-read
roundtrips, stable slots, ordered IDs, retained Sony metadata, byte preservation
of unrelated files, malformed input before writes, a failed second-file
publication and rollback, stale snapshots, and real track add/delete roundtrips
on the copied 14-track Sony library. A separate external Java process verifies
Japanese, accented and supplementary-plane characters through the Windows
launcher and the stored UTF-16BE table bytes. Physical firmware display and playback are
separate hardware acceptance checks; binary readback alone does not prove them.
