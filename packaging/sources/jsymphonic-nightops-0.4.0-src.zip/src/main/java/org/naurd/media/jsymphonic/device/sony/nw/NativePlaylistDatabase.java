package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Sony OMGAUDIO user playlists (tree 0x22). Binary fields corroborated against
 * ML_SONY/sonydb's write_01TREEXX(type=22) and write_03GINFXX(type=22).
 * Metadata slots are never compacted or reused, preserving native slot IDs and
 * opaque Sony records not referenced by the current tree. See NATIVE-PLAYLISTS.md.
 */
public final class NativePlaylistDatabase {
    private static final int MAX_BYTES = 4 * 1024 * 1024;
    private static final int MAX_GROUPS = 2048;
    private static final int MAX_MEMBERS = 65534;
    private static final int RECORD_SIZE = 0x310;
    private static final String JOURNAL = ".jsymphonic-playlist-transaction";
    private final Path root, treePath, infoPath;
    private byte[] originalTree, originalInfo;
    private final List<byte[]> records = new ArrayList<byte[]>();
    private final List<Playlist> playlists = new ArrayList<Playlist>();
    private boolean changed;

    public static final class Playlist {
        public final int id;
        public final String name;
        public final List<Integer> trackIds;
        private Playlist(int id, String name, List<Integer> tracks) {
            this.id = id;
            this.name = name;
            this.trackIds = Collections.unmodifiableList(new ArrayList<Integer>(tracks));
        }
    }

    private NativePlaylistDatabase(File directory) throws IOException {
        root = directory.toPath().toAbsolutePath().normalize();
        checkPath(root);
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) throw invalid("OMGAUDIO is not a directory");
        if (Files.exists(root.resolve(JOURNAL), LinkOption.NOFOLLOW_LINKS))
            throw invalid("An incomplete playlist transaction requires backup recovery before another operation");
        treePath = findFile(directory, "01tree22.dat").toPath();
        infoPath = findFile(directory, "03ginf22.dat").toPath();
        originalTree = readOptional(treePath);
        originalInfo = readOptional(infoPath);
        if ((originalTree == null) != (originalInfo == null)) throw invalid("Playlist table pair is incomplete");
        if (originalTree != null) parse();
    }

    public static NativePlaylistDatabase read(File directory) throws IOException {
        return new NativePlaylistDatabase(directory);
    }

    static void validateTreeInfo(File directory) throws IOException {
        Path file = findFile(directory, "02treinf.dat").toPath();
        byte[] data = readOptional(file);
        if (data != null && section(data, "GTIF", 1, "GTFB", 0x90).count < 0x2d)
            throw invalid("Incomplete Sony tree information");
    }

    static void updateTreeInfo(File directory, int duration) throws IOException {
        Path file = findFile(directory, "02treinf.dat").toPath();
        byte[] data = readOptional(file);
        if (data == null) throw invalid("Missing Sony tree information");
        Section info = section(data, "GTIF", 1, "GTFB", 0x90);
        if (info.count < 0x2d) throw invalid("Incomplete Sony tree information");
        // Retain all opaque extended-tree records and their existing labels.
        for (int id : new int[] {1, 2, 3, 4, 0x2d}) put32(data, info.offset + 16 + (id - 1) * 0x90 + 8, duration);
        writeSynced(file, data);
    }

    /** Resolve only a fixed engine-owned filename, retaining its actual casing. */
    static File findFile(File directory, String name) throws IOException {
        File result = null;
        File[] children = directory.listFiles();
        if (children == null) throw invalid("Cannot enumerate OMGAUDIO");
        for (File child : children) if (child.getName().equalsIgnoreCase(name)) {
            if (result != null) throw invalid("Ambiguous database filename " + name);
            checkPath(child.toPath());
            if (!Files.isRegularFile(child.toPath(), LinkOption.NOFOLLOW_LINKS)) throw invalid("Database path is not a regular file");
            result = child;
        }
        return result == null ? new File(directory, name) : result;
    }

    static void checkPath(Path path) throws IOException {
        for (Path current = path.toAbsolutePath().normalize(); current != null; current = current.getParent()) {
            if (!Files.exists(current, LinkOption.NOFOLLOW_LINKS)) continue;
            BasicFileAttributes a = Files.readAttributes(current, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
            if (a.isSymbolicLink() || a.isOther()) throw invalid("Links and reparse points are not permitted in device paths");
        }
    }

    private static byte[] readOptional(Path path) throws IOException {
        checkPath(path);
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return null;
        long size = Files.size(path);
        if (size < 16 || size > MAX_BYTES) throw invalid("Invalid database file size");
        try (InputStream in = Files.newInputStream(path)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream((int) size);
            byte[] chunk = new byte[8192];
            int n;
            while ((n = in.read(chunk)) != -1) {
                if (out.size() + n > MAX_BYTES) throw invalid("Database file grew beyond its processing limit");
                out.write(chunk, 0, n);
            }
            return out.toByteArray();
        }
    }

    private void parse() throws IOException {
        Section gp = section(originalInfo, "GPIF", 1, "GPFB", RECORD_SIZE);
        if (gp.offset != 0x20 || gp.count > MAX_GROUPS || gp.offset + gp.length != originalInfo.length)
            throw invalid("Unsupported GPFB layout");
        requireZeros(originalInfo, gp.offset + 16 + gp.count * RECORD_SIZE, originalInfo.length);
        for (int n = 0; n < gp.count; n++) records.add(Arrays.copyOfRange(originalInfo,
                gp.offset + 16 + n * RECORD_SIZE, gp.offset + 16 + (n + 1) * RECORD_SIZE));
        Section groups = section(originalTree, "TREE", 2, "GPLB", 8);
        Section members = section(originalTree, "TREE", 2, "TPLB", 2);
        if (groups.offset != 0x30 || groups.count > MAX_GROUPS || members.count > MAX_MEMBERS
                || groups.offset + groups.length != members.offset || members.offset + members.length != originalTree.length)
            throw invalid("Unsupported playlist tree layout");
        validateTreeClassHeader(originalTree, groups);
        validateTreeClassHeader(originalTree, members);
        requireZeros(originalTree, groups.offset + 16 + groups.count * 8, members.offset);
        requireZeros(originalTree, members.offset + 16 + members.count * 2, originalTree.length);
        List<int[]> active = new ArrayList<int[]>();
        Set<Integer> ids = new HashSet<Integer>();
        int last = 1;
        for (int n = 0; n < groups.count; n++) {
            int at = groups.offset + 16 + n * 8;
            int id = u16(originalTree, at), flag = u16(originalTree, at + 2), start = u16(originalTree, at + 4);
            if (id < 1 || id > records.size() || !ids.add(id) || u16(originalTree, at + 6) != 0)
                throw invalid("Invalid playlist slot reference");
            if (flag == 0 && start == 0) continue; // inactive native slot; retain its metadata bytes
            if (flag != 0x0100 || start < last || start < 1 || start > members.count + 1)
                throw invalid("Invalid playlist membership offset or unsupported group type");
            active.add(new int[] {id, start});
            last = start;
        }
        if ((!active.isEmpty() && active.get(0)[1] != 1) || (active.isEmpty() && members.count != 0))
            throw invalid("Unowned playlist members");
        for (int n = 0; n < active.size(); n++) {
            int[] group = active.get(n);
            int end = n + 1 < active.size() ? active.get(n + 1)[1] : members.count + 1;
            List<Integer> tracks = new ArrayList<Integer>();
            for (int i = group[1]; i < end; i++) {
                int id = u16(originalTree, members.offset + 16 + (i - 1) * 2);
                if (id == 0) throw invalid("Invalid zero track ID in playlist");
                tracks.add(id);
            }
            playlists.add(new Playlist(group[0], recordName(records.get(group[0] - 1)), tracks));
        }
    }

    public List<Playlist> list() { return Collections.unmodifiableList(new ArrayList<Playlist>(playlists)); }

    public Playlist create(String name, List<Integer> trackIds, Set<Integer> existingTracks) throws IOException {
        validateName(name);
        validateTracks(trackIds, existingTracks);
        if (records.size() >= MAX_GROUPS) throw invalid("Native playlist slot limit reached (2048)");
        checkMemberLimit(trackIds.size(), 0);
        byte[] record = new byte[RECORD_SIZE];
        put16(record, 12, 6); put16(record, 14, 0x80);
        String[] tags = {"TIT2", "TPE1", "TCON", "TSOP", "PICP", "PIC0"};
        for (int i = 0; i < tags.length; i++) { ascii(record, 16 + i * 0x80, tags[i]); put16(record, 20 + i * 0x80, 2); }
        renameRecord(record, name);
        records.add(record);
        Playlist result = new Playlist(records.size(), name, trackIds);
        playlists.add(result); changed = true;
        return result;
    }

    public Playlist update(int id, String name, List<Integer> trackIds, Set<Integer> existingTracks) throws IOException {
        int index = index(id);
        Playlist previous = playlists.get(index);
        if (name != null) validateName(name);
        if (trackIds != null) { validateTracks(trackIds, existingTracks); checkMemberLimit(trackIds.size(), previous.trackIds.size()); }
        Playlist result = new Playlist(id, name == null ? previous.name : name, trackIds == null ? previous.trackIds : trackIds);
        if (name != null) renameRecord(records.get(id - 1), name);
        playlists.set(index, result); changed = true;
        return result;
    }

    public void delete(int id) throws IOException {
        playlists.remove(index(id)); changed = true;
        // GPFB slot remains opaque and unreferenced, as in native Sony databases.
    }

    public void validateReferences(Set<Integer> existingTracks) throws IOException {
        for (Playlist p : playlists) for (Integer id : p.trackIds)
            if (!existingTracks.contains(id)) throw invalid("Playlist " + p.id + " references missing track " + id);
    }

    public void retainTracks(Set<Integer> existingTracks) {
        for (int i = 0; i < playlists.size(); i++) {
            Playlist p = playlists.get(i);
            List<Integer> retained = new ArrayList<Integer>();
            for (Integer id : p.trackIds) if (existingTracks.contains(id)) retained.add(id);
            if (!retained.equals(p.trackIds)) { playlists.set(i, new Playlist(p.id, p.name, retained)); changed = true; }
        }
    }

    public void assertUnchanged() throws IOException {
        if (!Arrays.equals(originalTree, readOptional(treePath)) || !Arrays.equals(originalInfo, readOptional(infoPath)))
            throw invalid("Playlist database changed since it was read");
    }

    private int index(int id) throws IOException {
        for (int i = 0; i < playlists.size(); i++) if (playlists.get(i).id == id) return i;
        throw invalid("No native playlist with id " + id);
    }

    private void checkMemberLimit(int added, int removed) throws IOException {
        long total = added - removed;
        for (Playlist p : playlists) total += p.trackIds.size();
        if (total > MAX_MEMBERS) throw invalid("Native playlist membership limit reached (65534)");
    }

    private static void validateTracks(List<Integer> ids, Set<Integer> existing) throws IOException {
        if (ids == null || ids.size() > MAX_MEMBERS) throw invalid("Invalid playlist track list");
        for (Integer id : ids) if (id == null || id < 1 || id > 65535 || !existing.contains(id))
            throw invalid("Unknown device track ID " + id);
    }

    private static void validateName(String name) throws IOException {
        if (name == null || name.trim().isEmpty() || name.length() > 60) throw invalid("Playlist name must contain 1 to 60 UTF-16 characters");
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (Character.isISOControl(c) || Character.getType(c) == Character.FORMAT) throw invalid("Playlist name contains control characters");
            if (Character.isHighSurrogate(c)) {
                if (++i >= name.length() || !Character.isLowSurrogate(name.charAt(i))) throw invalid("Invalid Unicode playlist name");
            } else if (Character.isLowSurrogate(c)) throw invalid("Invalid Unicode playlist name");
        }
    }

    private static String recordName(byte[] record) throws IOException {
        if (u16(record, 12) != 6 || u16(record, 14) != 0x80 || !magic(record, 16, "TIT2") || u16(record, 20) != 2)
            throw invalid("Unsupported native playlist metadata encoding");
        int end = 22;
        while (end < 144 && u16(record, end) != 0) end += 2;
        try { return StandardCharsets.UTF_16BE.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(record, 22, end - 22)).toString(); }
        catch (CharacterCodingException e) { throw invalid("Invalid native playlist name encoding"); }
    }

    private static void renameRecord(byte[] record, String name) {
        Arrays.fill(record, 22, 144, (byte) 0);
        byte[] text = name.getBytes(StandardCharsets.UTF_16BE);
        System.arraycopy(text, 0, record, 22, text.length);
    }

    /** Stage both files and durable originals before publishing either member.
     * A crash leaves a named recovery journal; all later access fails closed.
     * An ordinary I/O error rolls back both originals and reports failure.
     */
    public void save() throws IOException { save(new Publisher() {
        public void publish(Path source, Path target) throws IOException { replace(source, target); }
    }); }

    // Package-private I/O seam allows deterministic disk-failure tests, never a
    // production runtime option or a validation bypass.
    interface Publisher { void publish(Path source, Path target) throws IOException; }
    void save(Publisher publisher) throws IOException {
        if (!changed && originalTree != null) return;
        assertUnchanged();
        byte[] tree = encodeTree(), info = encodeInfo();
        Path journal = root.resolve(JOURNAL);
        Files.createDirectory(journal);
        boolean publishStarted = false;
        try {
            writeSynced(journal.resolve("tree.before"), originalTree == null ? new byte[0] : originalTree);
            writeSynced(journal.resolve("info.before"), originalInfo == null ? new byte[0] : originalInfo);
            writeSynced(journal.resolve("tree.next"), tree);
            writeSynced(journal.resolve("info.next"), info);
            writeSynced(journal.resolve("files.txt"), (treePath.getFileName() + "\n" + infoPath.getFileName() + "\n").getBytes(StandardCharsets.UTF_8));
            assertUnchanged();
            publishStarted = true;
            publisher.publish(journal.resolve("info.next"), infoPath);
            publisher.publish(journal.resolve("tree.next"), treePath);
            if (!Arrays.equals(tree, readOptional(treePath)) || !Arrays.equals(info, readOptional(infoPath)))
                throw invalid("Playlist write verification failed");
            cleanJournal(journal);
            originalTree = tree; originalInfo = info; changed = false;
        } catch (IOException e) {
            if (publishStarted) {
                try { restore(infoPath, originalInfo); restore(treePath, originalTree); cleanJournal(journal); }
                catch (IOException recovery) { e.addSuppressed(recovery); throw new IOException("Playlist update failed; incomplete recovery requires a verified backup", e); }
            } else {
                try { cleanJournal(journal); } catch (IOException cleanup) { e.addSuppressed(cleanup); }
            }
            throw e;
        }
    }

    private byte[] encodeTree() throws IOException {
        int count = 0;
        for (Playlist p : playlists) count += p.trackIds.size();
        int memberLength = 16 + count * 2 + (16 - (count * 2) % 16);
        byte[] data = new byte[0x4040 + memberLength];
        if (originalTree != null) {
            // Unknown file/descriptor reserved bytes are opaque, not padding.
            // Preserve them even when the class payloads grow or move.
            System.arraycopy(originalTree, 0, data, 0, 0x30);
            Section oldGroups = section(originalTree, "TREE", 2, "GPLB", 8);
            Section oldMembers = section(originalTree, "TREE", 2, "TPLB", 2);
            System.arraycopy(originalTree, oldGroups.offset, data, 0x30, 16);
            System.arraycopy(originalTree, oldMembers.offset, data, 0x4040, 16);
        } else header(data, "TREE", 2);
        int groupDescriptor = originalTree == null || magic(data, 16, "GPLB") ? 16 : 32;
        descriptor(data, groupDescriptor, "GPLB", 0x30, 0x4010);
        descriptor(data, groupDescriptor == 16 ? 32 : 16, "TPLB", 0x4040, memberLength);
        classHeader(data, 0x30, "GPLB", playlists.size(), 8);
        put32(data, 0x38, playlists.size());
        classHeader(data, 0x4040, "TPLB", count, 2);
        put32(data, 0x4048, count);
        int cursor = 1, group = 0;
        for (Playlist p : playlists) {
            int at = 0x40 + group++ * 8;
            put16(data, at, p.id); put16(data, at + 2, 0x0100); put16(data, at + 4, cursor);
            for (Integer track : p.trackIds) { put16(data, 0x4050 + (cursor - 1) * 2, track); cursor++; }
        }
        return data;
    }

    private byte[] encodeInfo() {
        byte[] data = new byte[0x30 + records.size() * RECORD_SIZE];
        if (originalInfo != null) System.arraycopy(originalInfo, 0, data, 0, Math.min(0x30, originalInfo.length));
        else { header(data, "GPIF", 1); descriptor(data, 16, "GPFB", 0x20, 16); classHeader(data, 0x20, "GPFB", 0, RECORD_SIZE); }
        put32(data, 24, data.length - 0x20); put16(data, 0x24, records.size());
        for (int i = 0; i < records.size(); i++) System.arraycopy(records.get(i), 0, data, 0x30 + i * RECORD_SIZE, RECORD_SIZE);
        return data;
    }

    private static void writeSynced(Path path, byte[] data) throws IOException {
        checkPath(path);
        try (FileOutputStream out = new FileOutputStream(path.toFile())) { out.write(data); out.getFD().sync(); }
    }
    private static void replace(Path source, Path target) throws IOException {
        checkPath(source); checkPath(target);
        try { Files.move(source, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException e) { Files.move(source, target, StandardCopyOption.REPLACE_EXISTING); }
    }
    private static void restore(Path path, byte[] original) throws IOException {
        if (original == null) Files.deleteIfExists(path);
        else writeSynced(path, original);
        if (!Arrays.equals(original, readOptional(path))) throw invalid("Playlist rollback verification failed");
    }
    private static void cleanJournal(Path journal) throws IOException {
        checkPath(journal);
        for (String name : Arrays.asList("tree.before", "info.before", "tree.next", "info.next", "files.txt")) {
            Path file = journal.resolve(name); checkPath(file); Files.deleteIfExists(file);
        }
        Files.delete(journal);
    }

    private static final class Section {
        final int offset, length, count;
        Section(int offset, int length, int count) { this.offset = offset; this.length = length; this.count = count; }
    }
    private static Section section(byte[] data, String type, int expectedSections, String name, int size) throws IOException {
        if (data.length < 16 + expectedSections * 16 || !magic(data, 0, type)
                || u32(data, 4) != 0x01010000L || data[8] != expectedSections) throw invalid("Unsupported " + type + " database header");
        Section found = null;
        for (int i = 0; i < expectedSections; i++) {
            int at = 16 + i * 16;
            long offset = u32(data, at + 4), length = u32(data, at + 8);
            if (offset < 16 + expectedSections * 16 || length < 16 || offset + length > data.length) throw invalid("Database class outside file bounds");
            if (!magic(data, (int) offset, new String(data, at, 4, StandardCharsets.US_ASCII))) throw invalid("Database class header mismatch");
            if (!magic(data, at, name)) continue;
            int count = u16(data, (int) offset + 4);
            if (found != null || u16(data, (int) offset + 6) != size || 16L + (long) count * size > length) throw invalid("Invalid " + name + " class length");
            found = new Section((int) offset, (int) length, count);
        }
        if (found == null) throw invalid("Missing " + name + " database class");
        return found;
    }
    private static void requireZeros(byte[] data, int from, int to) throws IOException {
        for (int i = from; i < to; i++) if (data[i] != 0) throw invalid("Unsupported nonzero database padding");
    }
    private static void validateTreeClassHeader(byte[] data, Section section) throws IOException {
        long mirror = u32(data, section.offset + 8);
        if ((mirror != 0 && mirror != section.count) || u32(data, section.offset + 12) != 0)
            throw invalid("Unsupported playlist class complement fields");
    }
    private static int u16(byte[] b, int at) { return ((b[at] & 255) << 8) | (b[at + 1] & 255); }
    private static long u32(byte[] b, int at) { return ((long) u16(b, at) << 16) | u16(b, at + 2); }
    private static void put16(byte[] b, int at, int value) { b[at] = (byte) (value >> 8); b[at + 1] = (byte) value; }
    private static void put32(byte[] b, int at, int value) { put16(b, at, value >> 16); put16(b, at + 2, value); }
    private static boolean magic(byte[] b, int at, String s) { return at >= 0 && at + 4 <= b.length && new String(b, at, 4, StandardCharsets.US_ASCII).equals(s); }
    private static void ascii(byte[] b, int at, String s) { byte[] text = s.getBytes(StandardCharsets.US_ASCII); System.arraycopy(text, 0, b, at, text.length); }
    private static void header(byte[] b, String s, int count) { ascii(b, 0, s); put32(b, 4, 0x01010000); b[8] = (byte) count; }
    private static void descriptor(byte[] b, int at, String s, int offset, int length) { ascii(b, at, s); put32(b, at + 4, offset); put32(b, at + 8, length); }
    private static void classHeader(byte[] b, int at, String s, int count, int size) { ascii(b, at, s); put16(b, at + 4, count); put16(b, at + 6, size); }
    private static IOException invalid(String message) { return new IOException(message); }
}
