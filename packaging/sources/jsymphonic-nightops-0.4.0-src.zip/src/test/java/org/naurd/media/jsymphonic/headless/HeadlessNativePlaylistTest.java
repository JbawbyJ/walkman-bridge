package org.naurd.media.jsymphonic.headless;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Base64;
import java.nio.charset.StandardCharsets;
import java.util.stream.Stream;
import org.junit.Test;
import org.naurd.media.jsymphonic.device.sony.nw.NativePlaylistDatabase;
import static org.junit.Assert.*;

/** Optional real Sony copy integration: never supplies a physical volume. */
public class HeadlessNativePlaylistTest {
    @Test public void nativeCliCrudUsesRealBinaryTablesAndRetainsEveryUnrelatedByte() throws Exception {
        Path device = fixtureCopy();
        Map<String, byte[]> baseline = contents(device);
        Result create = invoke("playlist-create", "--device", device.toString(), "--name", "Night walk", "14", "1", "3");
        assertSuccess(create);
        assertTrue(create.out, create.out.contains("\"id\":\"3\",\"name\":\"Night walk\",\"trackIds\":[\"14\",\"1\",\"3\"]"));
        assertSuccess(invoke("playlist-update", "--device", device.toString(), "--id", "3", "--name", "Evening", "--tracks", "3,14,1"));
        Result list = invoke("playlists", "--device", device.toString());
        assertSuccess(list);
        assertTrue(list.out, list.out.contains("\"name\":\"Evening\",\"trackIds\":[\"3\",\"14\",\"1\"]"));
        assertTrue(list.out, list.out.contains("\"event\":\"playlistsEnd\",\"count\":1"));
        assertSuccess(invoke("playlist-update", "--device", device.toString(), "--id", "3", "--tracks", ""));
        assertEquals(0, NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile()).list().get(0).trackIds.size());
        assertSuccess(invoke("playlist-delete", "--device", device.toString(), "--id", "3"));
        assertEquals(0, NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile()).list().size());
        assertUnchangedExcept(baseline, device, "OMGAUDIO/01TREE22.DAT", "OMGAUDIO/03GINF22.DAT");
    }

    @Test public void ordinaryTrackAddAndDeletePreservePlaylistsAndUnownedSonyFiles() throws Exception {
        Path device = fixtureCopy();
        assertSuccess(invoke("playlist-create", "--device", device.toString(), "--name", "Ordered", "14", "1", "3"));
        Map<String, byte[]> baseline = contents(device);
        Path source = Paths.get(System.getProperty("sony.playlist.fixture"), "OMGAUDIO", "10F00", "10000001.OMA");
        assertTrue(source.toString(), Files.isRegularFile(source));
        assertSuccess(invoke("add", "--device", device.toString(), source.toString(), "--idle-timeout", "15"));
        Result list = invoke("list", "--device", device.toString());
        assertSuccess(list);
        assertTrue(list.out, list.out.contains("\"count\":15"));
        assertEquals(Arrays.asList(14, 1, 3), NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile()).list().get(0).trackIds);
        assertArrayEquals(baseline.get("OMGAUDIO/03GINF22.DAT"), Files.readAllBytes(device.resolve("OMGAUDIO/03GINF22.DAT")));
        assertSuccess(invoke("del", "--device", device.toString(), "--id", "1", "--idle-timeout", "15"));
        assertEquals(Arrays.asList(14, 3), NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile()).list().get(0).trackIds);
        for (Map.Entry<String, byte[]> file : baseline.entrySet()) {
            String path = file.getKey();
            if (path.matches("OMGAUDIO/(01TREE(01|02|03|04|2D|22)|03GINF(01|02|03|04|2D)|02TREINF|04CNTINF|04PATLST|05CIDLST)\\.DAT")
                    || path.equals("OMGAUDIO/10F00/10000001.OMA")) continue;
            assertArrayEquals("Unrelated Sony file changed: " + path, file.getValue(), Files.readAllBytes(device.resolve(path)));
        }
    }

    @Test public void malformedPlaylistPreventsTrackDeletionBeforeAnyFileChanges() throws Exception {
        Path device = fixtureCopy();
        Path tree = device.resolve("OMGAUDIO/01TREE22.DAT");
        byte[] malformed = Files.readAllBytes(tree); malformed[24] = 0x7f; Files.write(tree, malformed);
        Map<String, byte[]> baseline = contents(device);
        Result result = invoke("del", "--device", device.toString(), "--id", "1");
        assertEquals(result.out + result.err, 1, result.code);
        assertTrue(result.out, result.out.contains("\"event\":\"fatal\""));
        assertFalse(result.out, result.out.contains("\"event\":\"done\""));
        assertUnchangedExcept(baseline, device);
        assertEquals(baseline.size(), contents(device).size());
    }

    @Test public void enumerationDoesNotDeleteMalformedTinyOma() throws Exception {
        Path device = Files.createTempDirectory("native-playlist-readonly-");
        Files.createDirectories(device.resolve("OMGAUDIO/10F00"));
        Path tiny = device.resolve("OMGAUDIO/10F00/10000001.OMA");
        Files.write(tiny, new byte[] {1, 2});
        assertSuccess(invoke("list", "--device", device.toString()));
        assertArrayEquals(new byte[] {1, 2}, Files.readAllBytes(tiny));
    }

    @Test public void nativeMalformedRequestFailsWithoutCreatingDeviceFiles() throws Exception {
        Path device = Files.createTempDirectory("native-playlist-invalid-cli-");
        Files.createDirectories(device.resolve("OMGAUDIO"));
        Result result = invoke("playlist-create", "--device", device.toString(), "--name", "Invalid", "999");
        assertEquals(1, result.code);
        assertEquals(0, contents(device).size());
        assertEquals(2, invoke("playlist-update", "--device", device.toString(), "--id", "1").code);
    }

    @Test public void externalJavaLauncherPreservesNonAnsiPlaylistNames() throws Exception {
        Path device = Files.createTempDirectory("native-playlist-unicode-cli-");
        Files.createDirectories(device.resolve("OMGAUDIO"));
        String name = "\u65e5\u672c \u00e9 \ud83c\udfb5";
        String encoded = Base64.getEncoder().encodeToString(name.getBytes(StandardCharsets.UTF_8));
        Path output = device.resolve("process.log");
        String javaExecutable = Paths.get(System.getProperty("java.home"), "bin", System.getProperty("os.name").startsWith("Windows") ? "java.exe" : "java").toString();
        Process child = new ProcessBuilder(javaExecutable, "-cp", System.getProperty("java.class.path"),
                HeadlessCli.class.getName(), "playlist-create", "--device", device.toString(), "--name-base64", encoded)
                .redirectErrorStream(true).redirectOutput(output.toFile()).start();
        assertTrue("External Java finished", child.waitFor(20, java.util.concurrent.TimeUnit.SECONDS));
        assertEquals(new String(Files.readAllBytes(output), StandardCharsets.UTF_8), 0, child.exitValue());
        assertEquals(name, NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile()).list().get(0).name);
        Result invalid = invoke("playlist-update", "--device", device.toString(), "--id", "1", "--name-base64", "/w==");
        assertEquals(1, invalid.code);
        assertEquals(name, NativePlaylistDatabase.read(device.resolve("OMGAUDIO").toFile()).list().get(0).name);
    }

    private static Path fixtureCopy() throws Exception {
        String value = System.getProperty("sony.playlist.fixture");
        org.junit.Assume.assumeTrue(value != null);
        Path source = Paths.get(value).toAbsolutePath().normalize();
        // Reject drive roots; test input is explicitly a saved folder, never a mount.
        assertTrue("Use a backup fixture folder", source.getNameCount() > 1);
        Path target = Files.createTempDirectory("native-playlist-fixture-");
        try (Stream<Path> files = Files.walk(source)) {
            for (Path path : (Iterable<Path>) files::iterator) {
                Path destination = target.resolve(source.relativize(path));
                if (Files.isDirectory(path)) Files.createDirectories(destination);
                else Files.copy(path, destination);
            }
        }
        return target;
    }

    private static Map<String, byte[]> contents(Path root) throws Exception {
        Map<String, byte[]> result = new HashMap<String, byte[]>();
        try (Stream<Path> files = Files.walk(root)) {
            for (Path path : (Iterable<Path>) files::iterator) if (Files.isRegularFile(path))
                result.put(root.relativize(path).toString().replace('\\', '/'), Files.readAllBytes(path));
        }
        return result;
    }

    private static void assertUnchangedExcept(Map<String, byte[]> expected, Path actual, String... changes) throws Exception {
        for (Map.Entry<String, byte[]> file : expected.entrySet()) if (!Arrays.asList(changes).contains(file.getKey()))
            assertArrayEquals(file.getKey(), file.getValue(), Files.readAllBytes(actual.resolve(file.getKey())));
    }
    private static void assertSuccess(Result result) { assertEquals(result.out + result.err, 0, result.code); }
    private static Result invoke(String... args) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream(), err = new ByteArrayOutputStream();
        int code = HeadlessCli.run(args, new PrintStream(out, true, "UTF-8"), new PrintStream(err, true, "UTF-8"));
        return new Result(code, out.toString("UTF-8"), err.toString("UTF-8"));
    }
    private static final class Result {
        final int code; final String out, err;
        Result(int code, String out, String err) { this.code = code; this.out = out; this.err = err; }
    }
}
