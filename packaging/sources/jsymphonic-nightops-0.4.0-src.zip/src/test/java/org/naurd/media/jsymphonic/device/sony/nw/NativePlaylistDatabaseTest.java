package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.junit.Test;
import static org.junit.Assert.*;

public class NativePlaylistDatabaseTest {
    private final Set<Integer> tracks = new HashSet<Integer>(Arrays.asList(1, 3, 14));

    @Test public void nativeRecordsSurviveCreateRenameReorderDeleteAndRestart() throws Exception {
        Path folder = Files.createTempDirectory("native-playlists-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(folder.toFile());
        NativePlaylistDatabase.Playlist a = db.create("Night walk", Arrays.asList(14, 1, 3), tracks);
        db.save();
        byte[] tree = Files.readAllBytes(folder.resolve("01tree22.dat"));
        assertEquals("TREE", new String(tree, 0, 4, "US-ASCII"));
        // Independently check the ML_SONY/OMGAUDIO field layout.
        ByteBuffer binary = ByteBuffer.wrap(tree).order(ByteOrder.BIG_ENDIAN);
        assertEquals(0x4010, binary.getInt(24));
        assertEquals(0x4040, binary.getInt(36));
        assertEquals(1, binary.getShort(0x34));
        assertEquals(a.id, binary.getShort(0x40));
        assertEquals(0x0100, binary.getShort(0x42));
        assertEquals(1, binary.getShort(0x44));
        assertEquals(14, binary.getShort(0x4050));
        assertEquals(1, binary.getShort(0x4052));
        assertEquals(3, binary.getShort(0x4054));
        db = NativePlaylistDatabase.read(folder.toFile());
        db.update(a.id, "Soir \u65e5\u672c", Arrays.asList(3, 14), tracks);
        NativePlaylistDatabase.Playlist b = db.create("Second", Arrays.asList(1), tracks);
        db.save();
        db = NativePlaylistDatabase.read(folder.toFile());
        assertEquals(Arrays.asList(3, 14), db.list().get(0).trackIds);
        assertEquals("Soir \u65e5\u672c", db.list().get(0).name);
        db.delete(a.id);
        db.save();
        db = NativePlaylistDatabase.read(folder.toFile());
        assertEquals(b.id, db.list().get(0).id);
        assertTrue(db.create("Third", Arrays.asList(3), tracks).id > b.id);
    }

    @Test public void invalidReferencesAndMalformedFilesDoNotMutate() throws Exception {
        Path folder = Files.createTempDirectory("native-playlist-invalid-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(folder.toFile());
        db.create("Valid", Arrays.asList(1), tracks);
        db.save();
        byte[] before = Files.readAllBytes(folder.resolve("01tree22.dat"));
        try { db.create("Unknown", Arrays.asList(999), tracks); fail("unknown track"); }
        catch (java.io.IOException expected) { }
        try { db.update(1, "\u0000", null, tracks); fail("invalid name"); }
        catch (java.io.IOException expected) { }
        assertArrayEquals(before, Files.readAllBytes(folder.resolve("01tree22.dat")));
        before[0x44] = 0x7f;
        Files.write(folder.resolve("01tree22.dat"), before);
        try { NativePlaylistDatabase.read(folder.toFile()); fail("invalid offset"); }
        catch (java.io.IOException expected) { }
        assertArrayEquals(before, Files.readAllBytes(folder.resolve("01tree22.dat")));
    }

    @Test public void trackRemovalPrunesOnlyDeletedMembershipAndRetainsEmptyPlaylist() throws Exception {
        Path folder = Files.createTempDirectory("native-playlist-prune-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(folder.toFile());
        db.create("First", Arrays.asList(1, 14, 3), tracks);
        db.create("Second", Arrays.asList(1), tracks);
        db.save();
        db.retainTracks(new HashSet<Integer>(Arrays.asList(14, 3)));
        db.save();
        db = NativePlaylistDatabase.read(folder.toFile());
        assertEquals(Arrays.asList(14, 3), db.list().get(0).trackIds);
        assertEquals(Collections.emptyList(), db.list().get(1).trackIds);
    }

    @Test public void incompleteJournalBlocksRatherThanGuessingOrOverwriting() throws Exception {
        Path folder = Files.createTempDirectory("native-playlist-journal-");
        Files.createDirectory(folder.resolve(".jsymphonic-playlist-transaction"));
        try { NativePlaylistDatabase.read(folder.toFile()); fail("journal must block"); }
        catch (java.io.IOException expected) { assertTrue(expected.getMessage().contains("incomplete")); }
    }

    @Test public void failedSecondPublishRestoresBothOriginalFiles() throws Exception {
        Path folder = Files.createTempDirectory("native-playlist-rollback-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(folder.toFile());
        db.create("Before", Arrays.asList(1), tracks);
        db.save();
        final byte[] tree = Files.readAllBytes(folder.resolve("01tree22.dat"));
        final byte[] info = Files.readAllBytes(folder.resolve("03ginf22.dat"));
        db.update(1, "After", Arrays.asList(14, 3), tracks);
        try {
            db.save(new NativePlaylistDatabase.Publisher() {
                int calls;
                public void publish(Path source, Path target) throws java.io.IOException {
                    if (++calls == 2) throw new java.io.IOException("injected second-file I/O failure");
                    Files.move(source, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
            });
            fail("I/O failure must surface");
        } catch (java.io.IOException expected) { assertTrue(expected.getMessage().contains("injected")); }
        assertArrayEquals(tree, Files.readAllBytes(folder.resolve("01tree22.dat")));
        assertArrayEquals(info, Files.readAllBytes(folder.resolve("03ginf22.dat")));
        assertEquals("Before", NativePlaylistDatabase.read(folder.toFile()).list().get(0).name);
    }

    @Test public void staleSnapshotCannotOverwriteExternalPlaylistEdit() throws Exception {
        Path folder = Files.createTempDirectory("native-playlist-stale-");
        NativePlaylistDatabase first = NativePlaylistDatabase.read(folder.toFile());
        first.create("Original", Arrays.asList(1), tracks); first.save();
        NativePlaylistDatabase stale = NativePlaylistDatabase.read(folder.toFile());
        first.update(1, "External update", null, tracks); first.save();
        stale.update(1, "Stale overwrite", null, tracks);
        try { stale.save(); fail("stale snapshot"); } catch (java.io.IOException expected) { }
        assertEquals("External update", NativePlaylistDatabase.read(folder.toFile()).list().get(0).name);
    }

    @Test public void repeatedTracksAndUnicodeNamesArePreservedWithoutTruncation() throws Exception {
        Path folder = Files.createTempDirectory("native-playlist-unicode-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(folder.toFile());
        char[] exact = new char[60]; Arrays.fill(exact, '\u65e5');
        db.create(new String(exact), Arrays.asList(1, 1, 3), tracks); db.save();
        db = NativePlaylistDatabase.read(folder.toFile());
        assertEquals(new String(exact), db.list().get(0).name);
        assertEquals(Arrays.asList(1, 1, 3), db.list().get(0).trackIds);
        byte[] before = Files.readAllBytes(folder.resolve("03ginf22.dat"));
        for (String name : Arrays.asList(new String(exact) + "x", "bad\ud800", "bad\u202e")) {
            try { db.update(1, name, null, tracks); fail("unsupported name"); }
            catch (java.io.IOException expected) { }
        }
        assertArrayEquals(before, Files.readAllBytes(folder.resolve("03ginf22.dat")));
    }

    @Test public void opaqueTreeHeaderAndDescriptorBytesArePreserved() throws Exception {
        Path folder = Files.createTempDirectory("native-playlist-opaque-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(folder.toFile());
        db.create("Before", Arrays.asList(1), tracks); db.save();
        Path tree = folder.resolve("01tree22.dat");
        byte[] before = Files.readAllBytes(tree);
        before[10] = 0x55; before[28] = 0x33; before[44] = 0x44;
        Files.write(tree, before);
        db = NativePlaylistDatabase.read(folder.toFile());
        db.update(1, "After", Arrays.asList(14, 1, 3), tracks); db.save();
        byte[] after = Files.readAllBytes(tree);
        assertEquals(before[10], after[10]); assertEquals(before[28], after[28]); assertEquals(before[44], after[44]);
        after[0x3c] = 1; Files.write(tree, after);
        try { NativePlaylistDatabase.read(folder.toFile()); fail("unknown class semantics"); }
        catch (java.io.IOException expected) { }
        assertArrayEquals(after, Files.readAllBytes(tree));
    }

    @Test public void realSonyFixtureOpaqueRecordsAndUnrelatedFilesArePreserved() throws Exception {
        String fixture = System.getProperty("sony.playlist.fixture");
        org.junit.Assume.assumeTrue(fixture != null);
        Path source = new File(fixture, "OMGAUDIO").toPath();
        Path folder = Files.createTempDirectory("native-playlist-sony-");
        for (String name : Arrays.asList("01TREE22.DAT", "03GINF22.DAT", "00GTRLST.DAT", "02TREINF.DAT")) {
            Files.copy(source.resolve(name), folder.resolve(name));
        }
        byte[] records = Files.readAllBytes(folder.resolve("03GINF22.DAT"));
        byte[] catalog = Files.readAllBytes(folder.resolve("00GTRLST.DAT"));
        byte[] info = Files.readAllBytes(folder.resolve("02TREINF.DAT"));
        NativePlaylistDatabase db = NativePlaylistDatabase.read(folder.toFile());
        assertTrue(db.list().isEmpty());
        NativePlaylistDatabase.Playlist added = db.create("Fixture roundtrip", Arrays.asList(14, 1, 3), tracks);
        assertEquals(3, added.id);
        db.save();
        byte[] after = Files.readAllBytes(folder.resolve("03GINF22.DAT"));
        assertArrayEquals(Arrays.copyOfRange(records, 0x30, records.length), Arrays.copyOfRange(after, 0x30, records.length));
        assertArrayEquals(catalog, Files.readAllBytes(folder.resolve("00GTRLST.DAT")));
        assertArrayEquals(info, Files.readAllBytes(folder.resolve("02TREINF.DAT")));
        assertEquals(Arrays.asList(14, 1, 3), NativePlaylistDatabase.read(folder.toFile()).list().get(0).trackIds);
    }
}
