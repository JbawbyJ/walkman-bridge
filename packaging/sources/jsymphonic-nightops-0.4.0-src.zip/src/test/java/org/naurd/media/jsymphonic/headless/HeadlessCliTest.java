package org.naurd.media.jsymphonic.headless;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class HeadlessCliTest {

    @Test
    public void jsonEscapesQuotesNewlinesAndControls() {
        assertEquals("\"\"", HeadlessCli.json(null));
        assertEquals("\"\"", HeadlessCli.json(""));
        assertEquals("\"hello\"", HeadlessCli.json("hello"));
        assertEquals("\"say \\\"hi\\\"\"", HeadlessCli.json("say \"hi\""));
        assertEquals("\"a\\\\b\"", HeadlessCli.json("a\\b"));
        assertEquals("\"line\\nbreak\"", HeadlessCli.json("line\nbreak"));
        assertEquals("\"tab\\there\"", HeadlessCli.json("tab\there"));
        assertEquals("\"\\u0001\"", HeadlessCli.json("\u0001"));
    }

    @Test
    public void stripHtmlFlattensGuiDeletionErrors() {
        String html = "<html>Errors during deletion:<br>consult the log.";
        assertEquals("Errors during deletion: consult the log.", HeadlessCli.stripHtml(html));
        assertEquals("", HeadlessCli.stripHtml(null));
        assertEquals("plain", HeadlessCli.stripHtml("plain"));
    }

    @Test
    public void missingArgsIsUsageExit() throws Exception {
        CliResult result = invoke();
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
        assertEquals("", result.out.trim());
    }

    @Test
    public void missingDeviceIsUsageExit() throws Exception {
        CliResult result = invoke("info");
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
        assertEquals("", result.out.trim());
    }

    @Test
    public void unknownFlagIsUsageExit() throws Exception {
        CliResult result = invoke("info", "--device", "/tmp", "--help");
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void missingOmgaudioIsFatalJson() throws Exception {
        File empty = tempDir("no-omgaudio");
        CliResult result = invoke("info", "--device", empty.getAbsolutePath());
        assertEquals(1, result.code);
        assertTrue(result.out.contains("\"event\":\"fatal\""));
        assertTrue(result.out.contains("OMGAUDIO"));
        assertFalse("stdout must stay JSON-lines", result.out.contains("Usage:"));
    }

    @Test
    public void addWithoutFilesIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("add", "--device", mount.getAbsolutePath());
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void delWithoutIdIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("del", "--device", mount.getAbsolutePath());
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void unknownCommandOnValidMountIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("sync", "--device", mount.getAbsolutePath());
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void infoOnEmptyOmgaudioEmitsDeviceEvent() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("info", "--device", mount.getAbsolutePath());
        assertEquals(result.err, 0, result.code);
        assertTrue(result.out, result.out.contains("\"event\":\"device\""));
        assertTrue(result.out, result.out.contains("\"ok\":true"));
        assertTrue(result.out, result.out.contains("\"trackCount\":0"));
        assertFalse("leftover System.out must not leak onto stdout",
                result.out.contains("THERE'S ONE"));
        for (String line : result.out.split("\\r?\\n")) {
            if (line.isEmpty()) {
                continue;
            }
            assertTrue("stdout line is JSON: " + line, line.startsWith("{") && line.endsWith("}"));
        }
    }

    @Test
    public void listOnEmptyOmgaudioEmitsListEnd() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("list", "--device", mount.getAbsolutePath());
        assertEquals(result.err, 0, result.code);
        assertTrue(result.out, result.out.contains("\"event\":\"listEnd\""));
        assertTrue(result.out, result.out.contains("\"count\":0"));
    }

    @Test
    public void systemOutDuringRunGoesToStderrNotJson() throws Exception {
        File empty = tempDir("no-omgaudio-sysout");
        ByteArrayOutputStream json = new ByteArrayOutputStream();
        ByteArrayOutputStream logs = new ByteArrayOutputStream();
        PrintStream jsonOut = new PrintStream(json, true, "UTF-8");
        PrintStream logErr = new PrintStream(logs, true, "UTF-8");
        int code = HeadlessCli.run(
                new String[] {"info", "--device", empty.getAbsolutePath()},
                jsonOut, logErr);
        assertEquals(1, code);
        // A debug print from the device layer (or this test's captured System.out
        // redirect target) must not appear on the JSON stream.
        String out = json.toString("UTF-8");
        assertTrue(out.contains("\"event\":\"fatal\""));
        assertFalse(out.contains("THERE'S ONE"));
    }

    @Test
    public void stepErrorAfterTerminationIsFatal() throws Exception {
        HeadlessCli.EventListener listener = new HeadlessCli.EventListener();
        listener.transferStepFinished(org.naurd.media.jsymphonic.device.sony.nw.NWGenericListener.DELETING,
                "<html>Errors during deletion:<br>consult the log.");
        listener.transferTermination();
        assertEquals("Errors during deletion: consult the log.", listener.stepError.get());
        assertEquals(0, listener.finished.getCount());
    }

    private static File mockDevice() throws Exception {
        File mount = tempDir("mock-walkman");
        File omgaudio = new File(mount, "OMGAUDIO");
        if (!omgaudio.mkdir()) {
            fail("could not create " + omgaudio);
        }
        return mount;
    }

    private static File tempDir(String prefix) throws Exception {
        File dir = File.createTempFile(prefix, "");
        if (!dir.delete() || !dir.mkdir()) {
            fail("could not create temp dir " + dir);
        }
        dir.deleteOnExit();
        return dir;
    }

    private static CliResult invoke(String... args) throws UnsupportedEncodingException {
        ByteArrayOutputStream json = new ByteArrayOutputStream();
        ByteArrayOutputStream logs = new ByteArrayOutputStream();
        PrintStream jsonOut = new PrintStream(json, true, "UTF-8");
        PrintStream logErr = new PrintStream(logs, true, "UTF-8");
        int code = HeadlessCli.run(args, jsonOut, logErr);
        return new CliResult(code, json.toString("UTF-8"), logs.toString("UTF-8"));
    }

    private static final class CliResult {
        final int code;
        final String out;
        final String err;

        CliResult(int code, String out, String err) {
            this.code = code;
            this.out = out;
            this.err = err;
        }
    }
}
