# JSymphonic (Walkman Bridge fork)

This repository is a fork of the [JSymphonic revival](https://github.com/georgewoodall82/jsymphonic)
(itself a Maven port of the original [SourceForge project](https://sourceforge.net/projects/symphonic/)).
It is the transfer engine for [Walkman Bridge](https://github.com/JbawbyJ/walkman-bridge): a local
dashboard that writes music into a Sony Walkman's OMGAUDIO database.

This fork keeps the Swing GUI as the jar's default main class and adds:

1. **Headless CLI** (`org.naurd.media.jsymphonic.headless.HeadlessCli`) for scripted
   `info` / `list` / `add` / `del`, with JSON-lines on stdout.
2. **Windows file-locking fixes** so OMGAUDIO rewrite and title deletion work when
   `File.delete()` refuses files that still have an open handle (the original author
   tested on Linux, where that succeeds). Constructor error dialogs are skipped when
   the JVM is headless.

JSymphonic is GPL-3.0. The original author is nicolas_cardoso; the Maven / modern-JVM
port is by georgewoodall82 / brianpipa.

## Headless CLI

Walkman Bridge (and any other wrapper) should invoke the CLI by classname. The same
fat jar still launches the GUI when run with `java -jar`.

```
mvn package
java -cp target/jsymphonic-0.5.3-jar-with-dependencies.jar \
     org.naurd.media.jsymphonic.headless.HeadlessCli <command> [options]
```

Commands:

| Command | Purpose |
|---|---|
| `info --device <mount>` | Device summary (`device` event) |
| `list --device <mount>` | One `track` event per title, then `listEnd` |
| `add --device <mount> <file> [<file>...]` | Import files and commit the database once |
| `del --device <mount> --id <id>` | Delete one title and commit the database |

Native Sony playlist list/create/rename/reorder/delete is available through the
headless CLI. See [Native playlists](NATIVE-PLAYLISTS.md) for commands, binary
format evidence, preservation guarantees, recovery behavior and test scope.

Options: `--generation <3..8>` (default `7` = NW-S60x/S70x family, no DvID.DAT key)
and `--idle-timeout <sec>` (default `300`).

**Protocol:** one JSON object per stdout line, discriminated by `event`. Logging and
usage text go to stderr. Exit `0` = success, `1` = failure (a `{"event":"fatal",...}`
line is emitted first when possible), `2` = usage error. A transfer step that
finishes with a non-empty error — including a title Windows could not delete — is
failure: `fatal` + exit 1, no `done`. Stdout is reserved for JSON-lines; leftover
`System.out` traffic from the device layer is redirected to stderr.

Walkman Bridge documents the wrapper-side contract in
[docs/PROTOCOL.md](https://github.com/JbawbyJ/walkman-bridge/blob/main/docs/PROTOCOL.md).

A folder containing an empty `OMGAUDIO` directory is a valid mock device (the
database is regenerated on first write).

## GUI

The jar's default main class is still `org.danizmax.jsymphonic.gui.JSymphonic`.

```
java -jar target/jsymphonic-0.5.3-jar-with-dependencies.jar
```

To transfer files other than MP3 and ATRAC, install ffmpeg. See
[Installing FFMPEG](INSTALLING-FFMPEG.md). Java 8 or above is required.

The upstream Flatpak and GitHub Releases still belong to
[georgewoodall82/jsymphonic](https://github.com/georgewoodall82/jsymphonic). This
fork is consumed by building the `jar-with-dependencies` artifact.

## Building

```
mvn package
```

That produces `target/jsymphonic-*-jar-with-dependencies.jar` (GUI + headless CLI)
and runs the HeadlessCli unit tests.

Resource-loading helpers live under
`src/main/java/com/pipasoft/jsymphonic`.
