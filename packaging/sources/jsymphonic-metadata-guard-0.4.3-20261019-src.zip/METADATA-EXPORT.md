# Metadata export and readback

`list` includes `genre` alongside title, artist and album from the OMA text
frames. MP3 export now writes ID3v2.3 title (`TIT2`), artist (`TPE1`), album
(`TALB`), genre (`TCON`), positive year (`TYER`) and positive track (`TRCK`).
UTF-16 with BOM and v2.3 unsynchronisation preserve Unicode. No artist, album,
genre, image or other unsupported field is inferred during export. Empty fields
are omitted. Text over 16,384 UTF-16 units, embedded NUL or malformed Unicode is
refused before any ID3 bytes are written. Audio payload bytes are unchanged.

MP3 tag-reading mode leaves missing metadata empty rather than borrowing folder
names. Explicit filename-pattern mode retains its existing behavior. OMA reads
also leave missing/empty fields empty. Applications can show their own visible
missing-value labels without treating those labels as source metadata.
Untitled tracks use `Track-<8-digit hexadecimal device ID>` for the exported
filename only. Two untagged tracks therefore receive separate files; their
ID3 metadata remains empty. Existing destination files are still not overwritten.

The existing native text budget remains 60 UTF-16 units per field. A boundary
falls back by one unit when necessary to keep a surrogate pair intact. Reading a
bounded native view and writing an OMA header do not mutate the source strings.
Full application metadata can be longer; the device representation has this
documented length reduction. Firmware glyph availability is separate from
correct Unicode serialization.

Artwork is not embedded in OMA or reconstructed during MP3 export. The NW-S700
family supports SonicStage album jackets, but this repository's PICP path
interpretation has not been validated against a native SonicStage capture.
See [JACKET.md](JACKET.md). Add/delete operations now refuse existing opaque
picture data instead of rebuilding the library with blank artwork pointers.
The refusal scan covers every present `03GINFxx.DAT`, including the four-tag
native table-37 layout, rather than depending on picture data in table 01.

`MetadataExportTest` drives the real OMA writer, device export path and headless
listing using temporary synthetic MPEG frames. It checks independent ID3
readback, exact audio bytes, missing tags, Unicode limits, invalid text refusal
and committed-journal recovery followed by export. Jacket tests check refusal
without mutation. These fixtures prove serialization and readback, not hardware
display, playback audibility or firmware artwork behavior.

The export fixture invokes the real `applyExport` component directly. The legacy
public `applyChanges` lifecycle also rebuilds the device database after an
export-only request; it consequently refuses devices with existing artwork under
the preservation guard. That lifecycle has not been refactored here. Do not
remove the guard without also preventing that unnecessary rebuild.
