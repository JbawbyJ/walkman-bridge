# Recovery hardening review (2026-10-18)

Review boundary: temporary filesystem fixtures only. No physical Walkman access,
merge, or push. Working base is PR #4, `ba18bdfe46b7d988759402e7716826dc73283cfc`.

## Existing pull requests, before implementation

- **#3, `1613000`**: test-only native playlist review against main `70662e4`.
  Covers inactive rows, structured failures, reference repair, first-save rollback,
  unchecked publish failures, and slot exhaustion. The tests are useful regression
  input; their header deliberately describes failures on the older snapshot.
  They do not test a publisher that changes its target and then throws, or malformed
  recovery manifests. They are not evidence of device acceptance.
- **#4, `ba18bdfe`**: broadens the journal to base tables, playlists and audio,
  with explicit recovery and read-only inspect. Concrete remaining gaps from
  inspection: publish accounting occurs after the publisher returns; cleanup
  failures can roll back a fully published transaction; recovery ignores format
  contents, tolerates a missing audio manifest, and publishes earlier tables before
  discovering missing later payloads. The add command still accepts a partial
  unsupported-input scan, rebuilds the database, and emits success.
- **#5, `4215199`**: adds bounded jacket image normalization, managed sidecars and
  journal-backed table edits on an earlier recovery implementation. Shares the
  journal risks above. Its header documents assumed picture pointer bytes; fixture
  coverage cannot establish physical compatibility. Keep the feature separate;
  importing it is unnecessary for these fixes.
- **#6, `bf078da`**: pins Maven plugin versions and action revisions, runs tests
  on Linux and Windows/JDK 8, and uploads Surefire reports. These changes are
  already present in #4. CI invokes `test`, so packaging still needs a separate
  clean package check. No unrelated CI changes are required here.

## Intended acceptance

1. A failed or uncertain database publish restores every possibly touched target.
2. After publication completes, cleanup errors never revert that committed snapshot.
3. Unknown/incomplete committed journals fail before recovery changes anything and
   retain their evidence. Valid explicit recovery remains repeatable.
4. Mixed and entirely unsupported add batches fail without device changes, transfer
   plans, or a success event. Existing JSON fatal/exit conventions remain unchanged.
5. Read commands remain non-mutating. Fresh tests and a clean package build are
   required; filesystem crash fixtures do not establish USB power-loss durability.

## Implemented findings and regression proof

Before production changes, five new journal tests failed for uncertain publish
rollback, cleanup rollback, unknown format acceptance, missing audio manifest,
and partial publication before discovering a missing later payload. All three
input validation tests also failed: entirely unsupported, mixed, and a rejected
batch with a pending probe. Follow-up failing tests reproduced empty-file deletion
during rollback, overwriting external table/audio changes during recovery,
Windows junction traversal, malformed commit acceptance, and partial legacy replay
with an invalid destination. Each defect now has a passing regression.

`OmgaudioRecoveryHardeningTest` uses temporary directories and checks bytes and
surviving evidence. Its Windows junction fixtures do not require the privileged
symbolic-link capability. `HeadlessAddValidationTest` compares all fixture device
paths and bytes and requires fatal/exit 1 without a transfer plan or `done`.
The prior dangling-reference CLI fixture now uses a recognized OMA input and a
missing ID that cannot collide with its pending import, keeping that test focused
on the reference-check contract.

The initial fixes added no jacket feature, fatal code, or journal format change.

## Initial verification environment and results

- Windows, portable JDK `21.0.12+8`, Apache Maven `3.9.9`.
- Final command: `mvn -o -B -Dmaven.repo.local=.m2-recovery clean package`.
  Result: **91 tests, 0 failures, 0 errors, 4 skipped**, executable dependency
  JAR produced. The four skips require the optional saved Sony fixture; no real
  device or saved user library was supplied to this run.
- Exact PR #3 test source exported from `1613000`, compiled against the packaged
  JAR and run with `org.junit.runner.JUnitCore`: **7 tests passed**. It remains
  separate from this patch rather than duplicating the existing test PR.
- `git diff --check`: passed.
- Offline dependency resolution initially failed because the existing cache lacked
  `maven-resources-plugin:3.3.1`. Authorized network setup populated the checkout's
  `.m2-recovery` cache; the final clean package run works offline. Maven execution
  required the approved host context because sandboxed javac could not read a
  downloaded dependency JAR. This did not require any device access.
- Logs and dependency caches are local verification artifacts, excluded from the
  commit. No merge, push, physical write, or hardware acceptance was performed.

Verifier follow-up: independent review of the immutable commit and the consumer
integration remains separate from this builder's tests. Optional fixture coverage,
Linux/JDK 8 CI and physical firmware behavior are not claimed by this Windows run.

## Independent-review corrections

The reviewer reproduced two remaining defects in the initial candidate: truncated
manifests silently discarded omitted staged payloads, and an existing temporary
hard link could be truncated through an unrestricted audio destination. Six new
regressions failed before correction. Recovery now reconciles the complete staged
inventory, rejects duplicate/conflicting destinations, and restricts audio paths.
All temporary output handles use `CREATE_NEW`; cleanup only unlinks paths that
the current invocation created. Additional checks cover retry after a failed
publish and an existing hard link at a valid managed jacket temporary path.

At the coordinator's request, two additive inspection fields bind approval to
content: `fingerprint` hashes all journal names/bytes, and `library_fingerprint`
hashes direct Sony DAT names/bytes even without a journal. Two CLI tests failed
before implementation and now verify stable read-only inspection and invalidation
on same-summary payload, table-content, and filename changes. Existing event
states, outcomes, and error codes are retained.

The original correction and this follow-up are rebased onto updated main
`dcc7e6d173391c41ce8cfc8b0ed181b3f34e0631`, preserving the newly merged jacket
implementation and PR #3 tests. No merge command or push is part of this work.

Final rebased verification: `mvn -o -B -Dmaven.repo.local=.m2-recovery clean package`
passed **132 tests, 0 failures, 0 errors, 4 optional saved-fixture skips** on the
same Windows/JDK 21 environment. This includes merged jacket tests and PR #3
review tests. Both independent standalone probes were also rerun against the
packaged JAR in new checkout-local fixtures: manifest replay is refused with A/B
unchanged and the journal retained; the temporary-path probe is refused with its
outside hard-linked file unchanged and the journal retained. The valid managed
jacket hard-link regression also passes, exercising exclusive creation rather
than depending solely on the destination-name check.

Fingerprinting uses bounded memory but reads every staged payload on inspection;
large pending audio batches can increase inspection latency. It provides content
identity, not authentication or protection from a concurrent writer during the
command. Independent final review and consumer acceptance remain separate gates.
