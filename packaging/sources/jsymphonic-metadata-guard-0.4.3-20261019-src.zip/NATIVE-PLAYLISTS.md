# Native Sony playlists

The headless engine reads and edits the native `OMGAUDIO/01TREE22.DAT` and
`03GINF22.DAT` playlist tables. It does not write an M3U file or alter audio to
represent a playlist. Playlist operations leave every other device file intact.

## Commands and protocol

```
playlists --device <mount>
playlist-create --device <mount> --name-base64 <UTF-8-base64> [track-id ...]
playlist-update --device <mount> --id <playlist-id> [--name-base64 <UTF-8-base64>] [--tracks <id,id,...>]
playlist-delete --device <mount> --id <playlist-id>
playlist-repair --device <mount>
playlist-recover --device <mount> [--inspect]
```

All commands use the existing `HeadlessCli` entry point. `playlists` emits a row
for each active group, followed by `{"event":"playlistsEnd","count":N}`:

```json
{"event":"playlist","id":"3","name":"Night walk","trackIds":["14","1","3"]}
```

Create/update emit the changed row only after both tables have been written and
read back successfully, then `{"event":"done"}`. Delete emits `done`. Failures
emit `fatal` and return nonzero. These failures include a top-level string
field `code`. The field is absent on every other fatal. `path` is present
for `DEVICE_FILE_LOCKED`, `DEVICE_FILE_READ_ONLY`, `DEVICE_PROBE_RESTORE_FAILED`,
and `DEVICE_PROBE_CONFLICT`, and is omitted when it does not apply.
`probe_path` is present for the two probe codes and is omitted when null:

```json
{"event":"fatal","message":"IOException: Playlist 1 references missing track 14","code":"PLAYLIST_REF_MISSING"}
{"event":"fatal","message":"IOException: An incomplete playlist transaction requires backup recovery before another operation","code":"PLAYLIST_JOURNAL_PENDING"}
{"event":"fatal","message":"IOException: Native playlist slot limit reached (2048)","code":"PLAYLIST_SLOTS_EXHAUSTED"}
{"event":"fatal","message":"Playlist repair refused: the device track list is empty or the library did not load","code":"PLAYLIST_LIBRARY_NOT_LOADED"}
{"event":"fatal","message":"Device file is locked","code":"DEVICE_FILE_LOCKED","path":"OMGAUDIO/10F00/10000001.OMA"}
{"event":"fatal","message":"Device file is read-only","code":"DEVICE_FILE_READ_ONLY","path":"OMGAUDIO/10F00/10000001.OMA"}
{"event":"fatal","message":"Database update failed; incomplete recovery requires a verified backup","code":"DEVICE_ROLLBACK_FAILED"}
{"event":"fatal","message":"Device file probe could not be restored","code":"DEVICE_PROBE_RESTORE_FAILED","path":"OMGAUDIO/10F00/10000001.OMA","probe_path":"OMGAUDIO/10F00/10000001.OMA.jsymphonic-probe"}
{"event":"fatal","message":"Device file probe conflicts with the track","code":"DEVICE_PROBE_CONFLICT","path":"OMGAUDIO/10F00/10000001.OMA","probe_path":"OMGAUDIO/10F00/10000001.OMA.jsymphonic-probe"}
```

`list`, `info`, `playlists`, and `playlist-recover --inspect` never rename or
delete anything on the device. When a `.jsymphonic-probe` sibling is pending
— the original is missing, or the sibling sits beside it — each of those
commands emits one warning per sibling before its normal output, then continues:

```json
{"event":"warning","code":"DEVICE_PROBE_PENDING","path":"OMGAUDIO/10F00/10000001.OMA","probe_path":"OMGAUDIO/10F00/10000001.OMA.jsymphonic-probe"}
```

`path` is the original track, mount-relative with forward slashes, even when
that file is absent. `probe_path` is the sibling in the same form. The warning
has no `message` field. Probe siblings are looked for in `10Fxx` and `20Pxx`
folders.

Add/delete reach the first three conditions through the device writer, so the
message keeps the `IllegalStateException: Device write refused: ...` prefix and
the same `code`. `PLAYLIST_LIBRARY_NOT_LOADED` is emitted only by
`playlist-repair`, with the message text unchanged, and it writes nothing.
`playlist-repair` prunes dangling track references instead of failing with
`PLAYLIST_REF_MISSING`. It refuses when the mounted library loaded zero tracks,
the listing did not finish, or any `.OMA` in a `10F` directory failed to parse.
A tag walk that bails out, a file too small to be a track, or a name that does
not yield a track id is a parse failure. One bad file makes the library not
loaded even when other tracks parsed, so repair cannot prune a reference to
the file it skipped. An empty scan is not treated as "every member is dangling".

On success, repair emits one summary, then one `playlist` row per active
group, then `done`. The summary is emitted only after the save commits, and
it is still emitted when there is nothing to prune. In that case the counts
are zero, the arrays are empty, and the playlist tables are not written.
`prunedCount` is the number of member references removed, counting duplicates.
`prunedTrackIds` is the distinct removed track ids as JSON numbers, sorted
ascending. `playlistIds` is the ids of playlists whose membership changed, the
same way.

```json
{"event":"playlistRepair","prunedCount":1,"prunedTrackIds":[3],"playlistIds":[1]}
{"event":"playlist","id":"1","name":"Keep","trackIds":["1"]}
{"event":"done"}
```

```json
{"event":"playlistRepair","prunedCount":0,"prunedTrackIds":[],"playlistIds":[]}
{"event":"playlist","id":"1","name":"Keep","trackIds":["1"]}
{"event":"done"}
```

An empty library, a listing that did not finish, or any `.OMA` parse failure
refuses before any repair write. There is no `playlistRepair` summary. A scan
line may precede this fatal; the fatal line itself is:

```json
{"event":"fatal","message":"Playlist repair refused: the device track list is empty or the library did not load","code":"PLAYLIST_LIBRARY_NOT_LOADED"}
```

`playlist-recover --inspect` reports a leftover `.jsymphonic-playlist-transaction`
and does not change the device. The event is exactly:

```json
{"event":"playlistJournal","state":"committed","pending":true,"committed":true,"action":"roll-forward","files":["01TREE22.DAT"]}
{"event":"done"}
```

`state` is `committed` (commit marker, or a legacy staged pair), `uncommitted`,
or `none`. `files` lists the staged database names and then each audio path.
Inspect does not include `outcome`.

Without `--inspect`, recover applies that decision and emits `outcome`:

```json
{"event":"playlistJournal","state":"committed","outcome":"rolled_forward","pending":false,"committed":true,"action":"roll-forward","files":["01TREE22.DAT"]}
{"event":"done"}
```

`outcome` is `rolled_forward`, `discarded` (the journal had no commit marker, so
only the journal is removed), or `none`. `state`, `committed`, `action`, and
`files` describe the journal that was found. `pending` is the state after the
call. Callers must use these fields; message text is not a contract.

An update without a name or track-list argument
is a usage error. `--tracks ""` explicitly clears membership; omitting the option
retains membership. Delete removes only the playlist group, never audio tracks.

`--name-base64` carries the name as standard base64 of its UTF-8 bytes. Malformed
base64 or UTF-8 is rejected before mutation. Use this option for all names from
wrappers: the Windows Java launcher can corrupt non-ANSI command-line text
before `main()` receives it, even with UTF-8 JVM settings. `--name <text>` remains
available for direct CLI use; the two name options are mutually exclusive.

Names are limited to 60 UTF-16 code units, with no control/format characters or
unpaired surrogates. They are not truncated. Track IDs are decimal values
1–65535 and must exist in the loaded device library. Duplicate member IDs are
preserved because a playlist may intentionally repeat a track. There are at
most 2048 metadata slots and 65534 total membership entries.

## Format evidence

The Java implementation was written independently from the format facts in
[mattn/sonydb](https://github.com/mattn/sonydb/blob/master/sonydb.cpp), the
BSD-licensed Linux port of Winamp ML_SONY. The source's `readAllPlaylist`,
`write_01TREEXX(...,22)` and `write_03GINFXX(...,22)` establish:

- `TREE` consists of 8-byte `GPLB` groups and 2-byte `TPLB` track IDs, big endian.
- `GPLB` refers to a one-based metadata slot and a one-based start in `TPLB`;
  the next group's start ends the previous group's ordered membership.
- Active groups use `0x0100`. The writer reserves `0x4010` bytes for the group
  section, putting `TPLB` at `0x4040`.
- `GPIF/GPFB` records for playlists are `0x310` bytes, including six `0x80`-byte
  tags. `TIT2`, with encoding `0x0002`, contains the UTF-16BE playlist name.

The inspected source file's SHA-256 is
`0a5eb09b1098d12773ae21ebee62d7846e7340f68404f2583d6e0d300299c904`.
No source code from that project is copied or translated into this engine.

The existing `reference/omgaudio_files_version2.xls` (outside this repository)
documents the generic class headers and group/track offsets but explicitly
leaves populated playlist semantics unimplemented. It is not treated as proof
of populated playlist handling. The independent source provides that evidence.

The locally supplied Sony NW-S705F backup has zero active `GPLB` memberships but
two opaque `GPFB` metadata slots. New playlists append after these slots; the
two existing records remain byte-identical. Unreferenced and deleted slots are
never compacted or reused. Playlist IDs therefore remain stable across this
engine's edits; an external application can reindex the database, so clients
must still refresh their device snapshot and use ETags.

## Preservation and failure behavior

The parser validates file bounds, version, class sizes, offsets, membership
ownership, slot IDs and supported metadata encoding before mutation. Unknown
group types and nonzero padding are rejected, rather than silently normalized.
Opaque metadata records, untouched tags, and reserved TREE file-header and
descriptor bytes remain byte-identical. TREE class complement fields are
accepted only as the known count mirror (or zero) plus a zero second field;
unknown complement semantics are rejected before any write.

Both playlist files and their originals are staged and synced in
`.jsymphonic-playlist-transaction` before either destination is replaced. The
same journal now also carries the base-table rewrite, the `02TREINF.DAT`
update (temp file, then rename) and the audio files an add or delete will
publish. Nothing in the live tree is replaced until a `commit` marker is
durable. The new bytes are read back before success. An ordinary I/O failure
restores the staged before-images; a forced termination leaves the journal
and blocks later playlist reads and device writes with `PLAYLIST_JOURNAL_PENDING`.
Any failure before that marker, including a `RuntimeException` or an `Error`
such as `OutOfMemoryError`, discards the uncommitted journal and is rethrown,
so the next write is not refused. `Interrupt` still leaves the journal: it
stands in for process death. `playlist-recover` rolls that journal forward when the commit marker is
present and back when it is not. This is still not a claim that FAT can
rename several files as one operation: reconcile is what closes the window.

Ordinary track add/delete validates native playlists before starting media
work. The audio file itself is not unlinked or published until that same
journal commits, so an interruption leaves either the previous pair (file and
database) or, after recover, the new pair. Delete and import step-finished
events, including their failure counts, are emitted only after that commit
returns. Before export, import, a new `10F` directory, a table, or a journal
write, each audio file that would be deleted — and each import destination
that already exists — is probed by renaming it to a sibling named
`<name>.jsymphonic-probe` and renaming it back. If the rename-away fails, the
command stops with `DEVICE_FILE_LOCKED` and the file is still at its original
name. The rename-back is retried five times over about a second. If the sibling
is still there after that, the command stops with `DEVICE_PROBE_RESTORE_FAILED`
and both `path` and `probe_path`. It does not report `DEVICE_FILE_LOCKED`, and
it does not delete the sibling. The `path` value is the original file relative
to the mount root, with forward slashes. A file `Files.isWritable` reports as
not writable, or with the DOS read-only attribute, is not renamed; a POSIX mode
with no write bit is treated the same way. The command stops with
`DEVICE_FILE_READ_ONLY` and the same `path`. `DEVICE_FILE_LOCKED` is only an `AccessDeniedException`, or a Windows sharing
or lock violation. OpenJDK maps Win32 `ERROR_ACCESS_DENIED` (5) to
`AccessDeniedException`. It does not map `ERROR_SHARING_VIOLATION` (32) or
`ERROR_LOCK_VIOLATION` (33): both become a `FileSystemException` whose reason
is the localized system text, with the `WindowsException` not set as the cause.
Those two count only when a `WindowsException` cause exposes `lastError()` 32
or 33, or when the reason is exactly `Unknown error: 0x20`, `Unknown error: 0x21`,
`32`, or `33` (the JDK text when `FormatMessage` returns nothing, or the bare
code). A sentence in the reason, in any language, is not a lock. Write-protected
media (`FileStore.isReadOnly` or `ReadOnlyFileSystemException`) is
`DEVICE_FILE_READ_ONLY`. A full root folder, a bad name, or any other
`FileSystemException` has no lock or read-only code. On add, delete,
playlist writes, and every other write except `playlist-recover`,
`DEVICE_FILE_LOCKED` and `DEVICE_FILE_READ_ONLY` always mean nothing was written
to the live tables and audio: those bytes match the tree before the command,
the journal is gone, and no `.jsymphonic-probe` sibling remains. A refreshed
`db_backup`, a leftover empty `10Fxx` folder, and a failed add's
`.jsymphonic-tmp` (which only `playlist-recover` sweeps) are outside that
comparison. That covers a lock or read-only file found by the probe, and one
found after the commit marker while publishing or deleting audio, but only when
the whole-batch rollback restored every file and removed the journal. If that
rollback cannot fully restore, the command emits `DEVICE_ROLLBACK_FAILED`
instead, never the lock or read-only code, and the journal stays.
`playlist-recover` roll-forward is the exception: the same lock or read-only
failure keeps the committed journal and uses that code, so a later recover can
finish. A crash after the rename-away and before the rename-back leaves the
sibling and a missing original. Probe siblings are looked for in `10Fxx` and
`20Pxx` folders. `list`, `info`, `playlists`, and
`playlist-recover --inspect` do not rename it; they emit `DEVICE_PROBE_PENDING`
and continue. `playlist-recover` and the next write put the original back
before any other work, including before `playlist-repair` chooses tracks to
prune, even when there is no journal. The same `DEVICE_PROBE_RESTORE_FAILED`
line is used when that restore fails at the start of a write or of
`playlist-recover`. If the original is already beside the sibling and the two
are byte-identical, that restore deletes only the sibling. If the bytes differ,
the command stops with `DEVICE_PROBE_CONFLICT` and both paths, writes nothing,
and deletes neither file. It does not report `DEVICE_FILE_LOCKED`.
The staged database describes the entire batch, so keeping the other audio
files, or writing the tables while one locked file stays behind, would make
the library and the database disagree. The device remains on the previous
consistent snapshot; retry the batch once the file can be replaced. If that
post-commit restore cannot put every file back, the command stops with
`DEVICE_ROLLBACK_FAILED` and the journal is left in place, so
`playlist-recover --inspect` and `playlist-recover` still apply. Playlist
commands emit that same fatal: `playlist-create`, `playlist-update`,
`playlist-delete`, and `playlist-repair` use the add/delete message and code,
with no `path`, when rollback or the restore check fails after the commit
marker, and the journal stays. That failure
does not use a `PLAYLIST_*` code and it is not described as a playlist update.
Playlist edits retain playlist order and
metadata, removing only memberships of tracks actually removed from the
library. Empty playlists are retained. Inactive GPLB rows (`flag=0`,
`start=0`) are copied back byte-identical; they are not compacted away on
the first edit. The legacy database rebuild no longer deletes its base tables
before the playlist save: both are published from the journal or neither is.
It preserves Sony cover folders, search extensions, configuration and unknown
files. Stray `*.jsymphonic-tmp` files are removed only by a device write or by
`playlist-recover`, and only inside the journal directory and the OMGAUDIO
directory that holds the known tables. `playlist-recover` also removes direct
children of `10Fxx` directories whose names end with `.OMA.jsymphonic-tmp`
(any case). Other temps in those folders are left in place, and a write does
not walk them. `playlists` is read-only and does not sweep or rename, so a
temp file under `10F00` or beside a table is left untouched. It retains the
existing global tree catalog and changes only known
base-tree duration fields in `02TREINF.DAT`. Advanced Sony indexes remain
preserved, but this engine does not regenerate their unsupported semantics.

## DEVICE_PROBE_CONFLICT

The probe renames the file to a sibling named `<name>.jsymphonic-probe` and then renames it back. That move does not copy and does not replace an existing file, so the sibling holds the pre-probe original bytes. The file at `path` is not written by the probe. When both exist and their bytes differ, `path` was created afterward by something else.

Do not delete either file. Compare both against the backup and keep the one that matches. If your backup doesn't have this file, or neither copy matches, keep both and ask for help.

This conflict blocks every write and stops `playlist-recover` from finishing until it is resolved. Read commands keep working and warn with `DEVICE_PROBE_PENDING`.

## Verification

### Recovery validation and rejected add batches

`playlistJournal` includes two additive SHA-256 fields. `fingerprint` covers every
direct journal entry's name and bytes, or is `null` if no journal exists.
`library_fingerprint` covers all direct OMGAUDIO `.DAT` filenames and bytes even
when no journal exists. Both use canonical filename order and length-prefixed
names/content. Repeated read-only inspection is stable; a payload change cannot
hide behind the same `state` and `files` summary. On recovery responses these
fingerprints describe the pre-operation snapshot, like `state` and `files`.
Consumers should obtain a fresh inspection after recovery before further writes.

`playlist-recover` validates a committed journal's complete manifest and staged
payloads before restoring probes, removing temporary files, or publishing tables.
The manifest must account for every staged file exactly once. Omitted payloads,
duplicate destinations (including case aliases), and unexpected entries retain
the journal. Audio destinations must be eight-hex-digit OMA files in `10Fxx`, or
managed `1GxxxxxxP0/01/02.JPG` jacket names in `20Pxx`. Temporary output paths are
opened exclusively with `CREATE_NEW`; an existing symlink or hard link cannot be
truncated. Failure cleanup removes only temporary paths created by that invocation.
Unknown formats, malformed commit markers, missing payloads, invalid destinations,
and links or Windows reparse points in probe paths stop recovery and retain the
journal. Format-2 live table bytes must match their before-image or next-image;
existing audio must match its staged payload. Conflicting bytes require backup
reconciliation and are preserved. These failures use the existing `fatal` event
and exit 1, without a successful recovery outcome or `done` event.

Once all publication has completed, a cleanup failure retains that new snapshot.
Explicit recovery finishes any remaining cleanup. Before publication completes,
rollback includes a publisher that changed its target and then threw, and restores
an existing empty table as an empty file rather than deleting it.

`add` validates every input before mounting for writes. An unsupported file rejects
the entire batch, including mixed supported/unsupported batches: exit 1 and a
`fatal` event, with no transfer plan, database rebuild, probe restoration, or
`done` event. Retry with a batch of supported inputs.

Recovery requires exclusive access to the library. Fingerprints bind content
snapshots rather than granting an exclusive filesystem lock. Preflight detects already
conflicting bytes; it does not coordinate with another process changing files
during the command. File contents are synced, but directory metadata persistence,
non-atomic fallback moves, controller caches, unplugging, and physical power loss
remain outside the fixture tests' guarantees. Legacy journals lack the complete
format-2 before-image validation. Keep a verified backup for hardware use.

Ordinary `mvn test` runs the binary, failure-recovery and CLI contract tests.
To also verify a full saved Sony fixture, use:

```
mvn -Dsony.playlist.fixture=<absolute-path-to-saved-backup-folder> test
```

The fixture tests copy input into temporary directories before any mutation.
Never supply a live device as a fixture. Tests cover native CRUD and fresh-read
roundtrips, stable slots, ordered IDs, retained Sony metadata, byte preservation
of unrelated files, malformed input before writes, a failed second-file
publication and rollback, stale snapshots, and real track add/delete roundtrips
on the copied 14-track Sony library. A separate external Java process verifies
Japanese, accented and supplementary-plane characters through the Windows
launcher and the stored UTF-16BE table bytes. Physical firmware display and playback are
separate hardware acceptance checks; binary readback alone does not prove them.
