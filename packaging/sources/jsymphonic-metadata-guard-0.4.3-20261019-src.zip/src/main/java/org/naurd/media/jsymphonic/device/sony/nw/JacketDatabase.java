package org.naurd.media.jsymphonic.device.sony.nw;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.ImageOutputStream;

/**
 * Album jacket table for Sony OMGAUDIO tree 01.
 *
 * <p>Confirmed layout: {@code 03GINF01.DAT} is a GPIF file whose GPFB records are
 * {@code 0x310} bytes, six {@code 0x80} tags ({@code TIT2}, {@code TPE1},
 * {@code TCON}, {@code TSOP}, {@code PICP}, {@code PIC0}), encoding {@code 0x0002}
 * as UTF-16BE. {@code 01TREE01.DAT} GPLB/TPLB rows link those groups to track ids.
 * JPEG sidecars live under {@code 20Pxx} as {@code 1G<6 hex><suffix>.JPG}.
 * See JACKET.md for which of those facts are confirmed and which pointer bytes
 * this writer assumes. Edits are published through {@link OmgaudioJournal}.
 */
public final class JacketDatabase {
    /** Engine limit. The S705 manual does not publish a pixel cap. See JACKET.md. */
    public static final int MAX_EDGE = 240;
    /** Engine limit for the JPEG stored in {@code 20P00}. See JACKET.md. */
    public static final int MAX_STORED_BYTES = 128 * 1024;
    /** Engine limit for the file read before decode. See JACKET.md. */
    public static final int MAX_INPUT_BYTES = 8 * 1024 * 1024;

    private static final int RECORD = 0x310;
    private static final int TAG = 0x80;
    private static final int PICP = 16 + 4 * TAG;
    private static final int PIC0 = 16 + 5 * TAG;
    private static final int MAX_TABLE = 4 * 1024 * 1024;
    private static final int MAX_DIMENSION = 4096;
    private static final long MAX_PIXELS = 4_000_000L;
    private static final Pattern MANAGED = Pattern.compile("20P[0-9A-F]{2}/1G[0-9A-F]{6}(?:P0|01|02)\\.JPG");
    private static final Pattern GINF_FILE = Pattern.compile("03GINF[0-9A-F]{2}\\.DAT", Pattern.CASE_INSENSITIVE);
    /**
     * Test seam. The next {@link #save()} throws {@link OutOfMemoryError} when the
     * journal reaches this step, before the commit marker. Cleared when save starts.
     * Null in production.
     */
    static volatile String failNextSaveAtStep;
    private static final Pattern PICTURE_ID = Pattern.compile("1G([0-9A-F]{6})");

    public static final class Jacket {
        public final int slot;
        public final String album;
        public final String artist;
        public final List<Integer> trackIds;
        public final String path;
        public final long bytes;
        public final byte[] image;
        Jacket(int slot, String album, String artist, List<Integer> trackIds, String path, long bytes, byte[] image) {
            this.slot = slot;
            this.album = album;
            this.artist = artist;
            this.trackIds = Collections.unmodifiableList(new ArrayList<Integer>(trackIds));
            this.path = path;
            this.bytes = bytes;
            this.image = image == null ? null : Arrays.copyOf(image, image.length);
        }
    }

    private final Path root;
    private final String infoName;
    private final byte[] original;
    private final List<List<Integer>> tracks;
    private final boolean treePresent;
    private boolean changed;
    private byte[] nextBytes;
    private final List<OmgaudioJournal.AudioSpec> audio = new ArrayList<OmgaudioJournal.AudioSpec>();
    private Path tempImage;

    private JacketDatabase(Path root, String infoName, byte[] original, List<List<Integer>> tracks, boolean treePresent) {
        this.root = root;
        this.infoName = infoName;
        this.original = original;
        this.tracks = tracks;
        this.treePresent = treePresent;
    }

    public static JacketDatabase read(java.io.File directory) throws IOException {
        Path root = directory.toPath().toAbsolutePath().normalize();
        NativePlaylistDatabase.checkPath(root);
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) throw new IOException("OMGAUDIO is not a directory");
        if (Files.exists(root.resolve(OmgaudioJournal.DIRECTORY), LinkOption.NOFOLLOW_LINKS))
            throw new NativePlaylistDatabase.Fatal(NativePlaylistDatabase.Fatal.JOURNAL_PENDING,
                    "An incomplete playlist transaction requires backup recovery before another operation");
        java.io.File info = NativePlaylistDatabase.findFile(directory, "03ginf01.dat");
        if (!Files.isRegularFile(info.toPath(), LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Missing album jacket table");
        byte[] table = readBounded(info.toPath());
        parseInfo(table);
        java.io.File tree = NativePlaylistDatabase.findFile(directory, "01tree01.dat");
        boolean present = Files.isRegularFile(tree.toPath(), LinkOption.NOFOLLOW_LINKS);
        List<List<Integer>> tracks = present ? parseTracks(readBounded(tree.toPath()), recordCount(table))
                : emptyTracks(recordCount(table));
        return new JacketDatabase(root, info.getName(), table, tracks, present);
    }

    public List<Jacket> list() throws IOException {
        List<Jacket> result = new ArrayList<Jacket>();
        for (int i = 0; i < recordCount(original); i++) result.add(describe(original, i));
        return result;
    }

    /** A base-library rebuild cannot yet remap native jacket associations.
     * Refuse before mounting for mutation, staging media, or creating a journal.
     * Unknown payload bytes are meaningful until proved otherwise: even opaque
     * padding must not be silently erased. This does not decode image files. */
    public static void assertRebuildSafe(java.io.File directory) throws IOException {
        String current = "GINF tables";
        try {
            NativePlaylistDatabase.checkPath(directory.toPath());
            java.io.File[] entries = directory.listFiles();
            if (entries == null) throw new IOException("Cannot enumerate OMGAUDIO");
            java.util.Set<String> names = new java.util.TreeSet<String>();
            for (java.io.File entry : entries) {
                if (!GINF_FILE.matcher(entry.getName()).matches()) continue;
                current = entry.getName().toLowerCase(Locale.ROOT);
                if (!names.add(current)) throw new IOException("Ambiguous GINF filename");
            }
            for (String name : names) {
                current = name;
                java.io.File info = NativePlaylistDatabase.findFile(directory, name);
                assertGinfRebuildSafe(name, readBounded(info.toPath()));
            }
        } catch (IOException e) {
            throw new NativePlaylistDatabase.Fatal("DEVICE_ARTWORK_REBUILD_UNSUPPORTED",
                    "Import/delete refused: this engine cannot safely preserve the existing album artwork table. "
                    + "Keep the device unchanged and use a transfer tool that preserves its native artwork associations. "
                    + current + ": " + e.getMessage());
        }
    }

    /** Layouts corroborated by this writer and the saved native capture: one,
     * two, four (tree 37), or six tags per GPFB row. This is a refusal-only scan;
     * it neither interprets pointer text nor changes association membership. */
    private static void assertGinfRebuildSafe(String name, byte[] table) throws IOException {
        if (table.length < 0x30 || !magic(table, 0, "GPIF") || u32(table, 4) != 0x01010000L || table[8] != 1
                || !magic(table, 16, "GPFB") || u32(table, 20) != 0x20 || !magic(table, 32, "GPFB"))
            throw new IOException("Unsupported GINF header layout");
        int count = u16(table, 36), stride = u16(table, 38);
        String[] tags;
        switch (stride) {
            case 0x90: tags = new String[] {"TIT2"}; break;
            case 0x110: tags = new String[] {"TIT2", "XSOT"}; break;
            case 0x210: tags = new String[] {"TIT2", "PICP", "PIC0", "XSOT"}; break;
            case 0x310: tags = new String[] {"TIT2", "TPE1", "TCON", "TSOP", "PICP", "PIC0"}; break;
            default: throw new IOException("Unsupported GINF record size");
        }
        if ((("03ginf01.dat".equals(name) || "03ginf22.dat".equals(name)) && stride != 0x310)
                || ("03ginf37.dat".equals(name) && stride != 0x210))
            throw new IOException("Unsupported picture-bearing GINF layout");
        long length = u32(table, 24);
        if (length != 16L + (long) count * stride || 32L + length != table.length)
            throw new IOException("Invalid GINF record bounds");
        for (int n = 0; n < count; n++) {
            int record = 0x30 + n * stride;
            if (u16(table, record + 12) != tags.length || u16(table, record + 14) != TAG)
                throw new IOException("Unsupported GINF tag layout in slot " + (n + 1));
            for (int tag = 0; tag < tags.length; tag++) {
                int at = record + 16 + tag * TAG;
                if (!magic(table, at, tags[tag]) || u16(table, at + 4) != 2)
                    throw new IOException("Unsupported GINF tag encoding in slot " + (n + 1));
                if (!"PICP".equals(tags[tag]) && !"PIC0".equals(tags[tag])) continue;
                for (int i = at + 6; i < at + TAG; i++) {
                    if (table[i] != 0) throw new IOException("Existing or opaque " + tags[tag] + " association in slot " + (n + 1));
                }
            }
        }
    }

    public Jacket setByAlbum(String album, Path image) throws IOException {
        return stage(indexByAlbum(album), normalize(image));
    }

    public Jacket setByTrack(int trackId, Path image) throws IOException {
        return stage(indexByTrack(trackId), normalize(image));
    }

    public Jacket clearByAlbum(String album) throws IOException {
        return stage(indexByAlbum(album), null);
    }

    public Jacket clearByTrack(int trackId) throws IOException {
        return stage(indexByTrack(trackId), null);
    }

    public void save() throws IOException { save(null); }

    void save(OmgaudioJournal.Probe probe) throws IOException {
        if (!changed) return;
        OmgaudioJournal.Probe effective = probe;
        if (failNextSaveAtStep != null) {
            final String step = failNextSaveAtStep;
            final OmgaudioJournal.Probe inner = probe;
            failNextSaveAtStep = null;
            effective = new OmgaudioJournal.Probe() {
                public void step(String name) throws IOException {
                    if (inner != null) inner.step(name);
                    if (step.equals(name)) throw new OutOfMemoryError("jacket-command");
                }
            };
        }
        try {
            probeOldSidecars();
            OmgaudioJournal.commit(root, files(), audio, null, effective);
        } finally {
            if (tempImage != null) Files.deleteIfExists(tempImage);
        }
    }

    /**
     * Rename-probe each old sidecar before the journal directory exists.
     * A read-only file is not renamed. A lock is a rename aside and back.
     */
    private void probeOldSidecars() throws IOException {
        for (OmgaudioJournal.AudioSpec spec : audio) {
            if (!spec.delete || spec.payload == null) continue;
            java.io.File file = spec.payload.toFile();
            if (!file.isFile()) continue;
            if (NWOmgaudio.isReadOnly(file)) throw new OmgaudioJournal.FileReadOnly(spec.relative);
            if (NWOmgaudio.trackFileLocked(file)) throw new OmgaudioJournal.FileLocked(spec.relative);
        }
    }

    List<String> pendingSteps() throws IOException {
        if (!changed) throw new IOException("No jacket update is staged");
        return OmgaudioJournal.plan(files(), audio);
    }

    public static byte[] normalize(Path image) throws IOException {
        if (image == null || !Files.isRegularFile(image, LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Jacket image was not found");
        long size = Files.size(image);
        if (size > MAX_INPUT_BYTES) throw new IOException("Jacket image is too large");
        return normalizeBytes(readBounded(image, MAX_INPUT_BYTES));
    }

    private Jacket stage(int index, byte[] jpeg) throws IOException {
        if (changed) throw new IOException("Jacket update is already staged");
        int at = recordOffset(index);
        if (!magic(original, at + PICP, "PICP") || u16(original, at + PICP + 4) != 2)
            throw new IOException("Unsupported jacket tag layout");
        if (foreignPointer(original, at + PICP) || foreignPointer(original, at + PIC0))
            throw new IOException("Jacket pointer is not a managed picture path");
        byte[] patched = Arrays.copyOf(original, original.length);
        String previous = managedText(text(patched, at + PICP));
        Arrays.fill(patched, at + PICP + 6, at + PICP + TAG, (byte) 0);
        String created = null;
        if (jpeg != null) {
            int id = nextPictureId(patched);
            created = String.format(Locale.ROOT, "20P00/1G%06XP0.JPG", id);
            byte[] encoded = created.getBytes(StandardCharsets.UTF_16BE);
            if (encoded.length > TAG - 6) throw new IOException("Jacket path does not fit in PICP");
            System.arraycopy(encoded, 0, patched, at + PICP + 6, encoded.length);
            tempImage = Files.createTempFile("jsymphonic-jacket-", ".jpg");
            Files.write(tempImage, jpeg);
            audio.add(new OmgaudioJournal.AudioSpec(false, created, tempImage));
        }
        if (magic(patched, at + PIC0, "PIC0") && u16(patched, at + PIC0 + 4) == 2
                && previous != null && previous.equals(managedText(text(patched, at + PIC0))))
            Arrays.fill(patched, at + PIC0 + 6, at + PIC0 + TAG, (byte) 0);
        if (previous != null && !referenced(patched, previous)) {
            Path old = resolveManaged(previous);
            if (old != null) audio.add(new OmgaudioJournal.AudioSpec(true, previous, old));
        }
        nextBytes = patched;
        changed = !Arrays.equals(original, patched) || !audio.isEmpty();
        // The new JPEG is not in the live tree until save publishes the journal.
        return new Jacket(index + 1, text(patched, at + 16), text(patched, at + 16 + TAG),
                tracks.get(index), created, jpeg == null ? 0 : jpeg.length, jpeg);
    }

    private List<OmgaudioJournal.FileSpec> files() {
        return Collections.singletonList(new OmgaudioJournal.FileSpec(infoName, original, nextBytes));
    }

    private int indexByAlbum(String album) throws IOException {
        if (album == null || album.isEmpty()) throw new IOException("Album name must not be empty");
        List<Integer> exact = new ArrayList<Integer>();
        List<Integer> shaped = new ArrayList<Integer>();
        for (int i = 0; i < recordCount(original); i++) {
            String title = text(original, recordOffset(i) + 16);
            String artist = text(original, recordOffset(i) + 16 + TAG);
            if (album.equals(title)) exact.add(i);
            else if (title.equals(artist + "/" + album)) shaped.add(i);
        }
        List<Integer> hits = exact.isEmpty() ? shaped : exact;
        if (hits.isEmpty()) throw new IOException("No album jacket group matches " + album);
        if (hits.size() > 1) throw new IOException("Album name matches more than one jacket group");
        return hits.get(0);
    }

    private int indexByTrack(int trackId) throws IOException {
        if (!treePresent) throw new IOException("Missing album tree");
        int found = -1;
        for (int i = 0; i < tracks.size(); i++) {
            if (tracks.get(i).contains(trackId)) {
                if (found >= 0) throw new IOException("Track " + trackId + " belongs to more than one jacket group");
                found = i;
            }
        }
        if (found < 0) throw new IOException("No album jacket group contains track " + trackId);
        return found;
    }

    private Jacket describe(byte[] table, int index) throws IOException {
        int at = recordOffset(index);
        String picp = managedText(text(table, at + PICP));
        String pic0 = managedText(text(table, at + PIC0));
        String relative = picp != null ? picp : pic0;
        Path file = relative == null ? null : resolveManaged(relative);
        byte[] image = null;
        long bytes = 0;
        if (file != null) {
            bytes = Files.size(file);
            if (bytes <= MAX_STORED_BYTES) image = Files.readAllBytes(file);
        } else relative = null;
        return new Jacket(index + 1, text(table, at + 16), text(table, at + 16 + TAG),
                tracks.get(index), relative, image == null ? bytes : image.length, image);
    }

    private int nextPictureId(byte[] table) throws IOException {
        int max = 0;
        java.io.File[] children = root.toFile().listFiles();
        if (children == null) throw new IOException("Cannot enumerate OMGAUDIO");
        for (java.io.File child : children) {
            if (!child.isDirectory() || !child.getName().toUpperCase(Locale.ROOT).matches("20P[0-9A-F]{2}")) continue;
            NativePlaylistDatabase.checkPath(child.toPath());
            java.io.File[] pictures = child.listFiles();
            if (pictures == null) throw new IOException("Cannot read jacket folder " + child.getName());
            for (java.io.File picture : pictures) {
                Integer id = pictureId(picture.getName().toUpperCase(Locale.ROOT));
                if (id != null) max = Math.max(max, id);
            }
        }
        for (int i = 0; i < recordCount(table); i++) {
            int at = recordOffset(i);
            for (String value : new String[] { text(table, at + PICP), text(table, at + PIC0) }) {
                Integer id = pictureId(value.toUpperCase(Locale.ROOT));
                if (id != null) max = Math.max(max, id);
            }
        }
        if (max >= 0xFFFFFF) throw new IOException("Jacket picture id space is exhausted");
        return max + 1;
    }

    private boolean referenced(byte[] table, String relative) {
        for (int i = 0; i < recordCount(table); i++) {
            int at = recordOffset(i);
            if (relative.equals(managedText(text(table, at + PICP))) || relative.equals(managedText(text(table, at + PIC0))))
                return true;
        }
        return false;
    }

    private Path resolveManaged(String relative) throws IOException {
        if (relative == null || !MANAGED.matcher(relative).matches()) return null;
        Path file = root.resolve(relative).normalize();
        if (!file.startsWith(root)) return null;
        if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) return null;
        NativePlaylistDatabase.checkPath(file);
        return file;
    }

    private static String managedText(String text) {
        if (text == null) return null;
        String upper = text.toUpperCase(Locale.ROOT);
        return MANAGED.matcher(upper).matches() ? upper : null;
    }

    /** A terminated picture string that this writer does not own. Uniform padding is not a pointer. */
    private static boolean foreignPointer(byte[] data, int tag) {
        String value = text(data, tag);
        if (value.isEmpty() || managedText(value) != null) return false;
        return !uniformPadding(data, tag);
    }

    private static boolean uniformPadding(byte[] data, int tag) {
        int start = tag + 6;
        int end = tag + TAG;
        if (start >= end || end > data.length) return false;
        byte fill = data[start];
        if (fill == 0) return false;
        for (int i = start + 1; i < end; i++) if (data[i] != fill) return false;
        return true;
    }

    private static Integer pictureId(String text) {
        Matcher matcher = PICTURE_ID.matcher(text);
        if (!matcher.find()) return null;
        return Integer.valueOf(Integer.parseInt(matcher.group(1), 16));
    }

    private static byte[] normalizeBytes(byte[] data) throws IOException {
        if (data.length < 4 || (data[0] & 255) != 0xFF || (data[1] & 255) != 0xD8)
            throw new IOException("Jacket image must be a JPEG");
        BufferedImage decoded = decodeWithinLimits(data);
        Frame frame = frame(data);
        if (frame != null && frame.baseline && frame.width > 0 && frame.height > 0
                && frame.width <= MAX_EDGE && frame.height <= MAX_EDGE && data.length <= MAX_STORED_BYTES)
            return Arrays.copyOf(data, data.length);
        if (decoded.getWidth() > MAX_DIMENSION || decoded.getHeight() > MAX_DIMENSION
                || (long) decoded.getWidth() * decoded.getHeight() > MAX_PIXELS)
            throw new IOException("Jacket image is too large");
        double scale = Math.min(1d, Math.min((double) MAX_EDGE / decoded.getWidth(), (double) MAX_EDGE / decoded.getHeight()));
        int width = Math.max(1, (int) Math.round(decoded.getWidth() * scale));
        int height = Math.max(1, (int) Math.round(decoded.getHeight() * scale));
        BufferedImage rgb = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = rgb.createGraphics();
        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, width, height);
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics.drawImage(decoded, 0, 0, width, height, null);
        graphics.dispose();
        float[] qualities = new float[] {0.85f, 0.70f, 0.55f, 0.40f, 0.25f};
        for (float quality : qualities) {
            byte[] encoded = writeJpeg(rgb, quality);
            Frame stored = frame(encoded);
            if (encoded.length <= MAX_STORED_BYTES && stored != null && stored.baseline) return encoded;
        }
        throw new IOException("Jacket image is too large");
    }

    /**
     * Read width and height from the JPEG header before allocating a raster.
     * {@code getWidth}/{@code getHeight} cover every SOF the reader understands,
     * including progressive, so a huge header cannot reach {@code read(0)}.
     */
    private static BufferedImage decodeWithinLimits(byte[] data) throws IOException {
        ImageInputStream stream = ImageIO.createImageInputStream(new ByteArrayInputStream(data));
        if (stream == null) throw new IOException("Jacket image cannot be decoded");
        ImageReader reader = null;
        try {
            Iterator<ImageReader> readers = ImageIO.getImageReaders(stream);
            if (!readers.hasNext()) throw new IOException("Jacket image must be a JPEG");
            reader = readers.next();
            reader.setInput(stream);
            int width;
            int height;
            try {
                width = reader.getWidth(0);
                height = reader.getHeight(0);
            } catch (IOException e) {
                throw new IOException("Jacket image cannot be decoded", e);
            }
            if (width < 1 || height < 1) throw new IOException("Jacket image cannot be decoded");
            if (width > MAX_DIMENSION || height > MAX_DIMENSION || (long) width * (long) height > MAX_PIXELS)
                throw new IOException("Jacket image is too large");
            BufferedImage image;
            try { image = reader.read(0); }
            catch (IOException e) { throw new IOException("Jacket image cannot be decoded", e); }
            if (image == null || image.getWidth() < 1 || image.getHeight() < 1)
                throw new IOException("Jacket image cannot be decoded");
            return image;
        } finally {
            if (reader != null) reader.dispose();
            stream.close();
        }
    }

    private static byte[] writeJpeg(BufferedImage image, float quality) throws IOException {
        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpeg");
        if (!writers.hasNext()) throw new IOException("Jacket image cannot be decoded");
        ImageWriter writer = writers.next();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(quality);
        try (ImageOutputStream out = ImageIO.createImageOutputStream(bytes)) {
            writer.setOutput(out);
            writer.write(null, new IIOImage(image, null, null), param);
        } finally { writer.dispose(); }
        return bytes.toByteArray();
    }

    private static final class Frame {
        final boolean baseline;
        final int width, height;
        Frame(boolean baseline, int width, int height) {
            this.baseline = baseline; this.width = width; this.height = height;
        }
    }

    /** Marker scan through the first SOS. Returns null when the marker stream is not a JPEG. */
    private static Frame frame(byte[] data) {
        if (data.length < 4 || (data[0] & 255) != 0xFF || (data[1] & 255) != 0xD8) return null;
        int i = 2;
        boolean baseline = false;
        int width = 0, height = 0;
        while (i + 1 < data.length) {
            if ((data[i] & 255) != 0xFF) return null;
            while (i < data.length && (data[i] & 255) == 0xFF) i++;
            if (i >= data.length) return null;
            int marker = data[i++] & 255;
            if (marker == 0xD9) break;
            if (marker == 0xDA) return new Frame(baseline, width, height);
            if (marker == 0x01 || (marker >= 0xD0 && marker <= 0xD8)) continue;
            if (i + 1 >= data.length) return null;
            int length = ((data[i] & 255) << 8) | (data[i + 1] & 255);
            if (length < 2 || i + length > data.length) return null;
            if (marker == 0xC0 && length >= 8) {
                baseline = true;
                height = ((data[i + 3] & 255) << 8) | (data[i + 4] & 255);
                width = ((data[i + 5] & 255) << 8) | (data[i + 6] & 255);
            } else if (isStartOfFrame(marker)) return new Frame(false, 0, 0);
            i += length;
        }
        return new Frame(baseline, width, height);
    }

    private static boolean isStartOfFrame(int marker) {
        return (marker >= 0xC1 && marker <= 0xC3) || (marker >= 0xC5 && marker <= 0xC7)
                || (marker >= 0xC9 && marker <= 0xCB) || (marker >= 0xCD && marker <= 0xCF);
    }

    private static void parseInfo(byte[] data) throws IOException {
        if (data.length < 0x30 || !magic(data, 0, "GPIF") || u32(data, 4) != 0x01010000L || data[8] != 1)
            throw new IOException("Unsupported jacket table layout");
        long offset = u32(data, 20), length = u32(data, 24);
        if (!magic(data, 16, "GPFB") || offset != 0x20 || length < 16 || offset + length > data.length
                || !magic(data, (int) offset, "GPFB") || u16(data, (int) offset + 6) != RECORD)
            throw new IOException("Unsupported jacket record size");
        int count = u16(data, (int) offset + 4);
        if (count < 0 || 16L + (long) count * RECORD > length) throw new IOException("Invalid jacket record count");
    }

    private static int recordCount(byte[] data) { return u16(data, 0x24); }
    private static int recordOffset(int index) { return 0x30 + index * RECORD; }

    private static List<List<Integer>> parseTracks(byte[] data, int records) throws IOException {
        if (data.length < 0x30 || !magic(data, 0, "TREE") || u32(data, 4) != 0x01010000L || data[8] != 2)
            throw new IOException("Unsupported album tree layout");
        Section groups = section(data, "GPLB", 8);
        Section members = section(data, "TPLB", 2);
        List<int[]> active = new ArrayList<int[]>();
        for (int n = 0; n < groups.count; n++) {
            int at = groups.offset + 16 + n * 8;
            int id = u16(data, at), flag = u16(data, at + 2), start = u16(data, at + 4);
            if (flag == 0 && start == 0) continue;
            if (flag != 0x0100 || id < 1 || id > records || start < 1 || start > members.count + 1 || u16(data, at + 6) != 0)
                throw new IOException("Unsupported album tree layout");
            for (int[] earlier : active) if (earlier[0] == id) throw new IOException("Unsupported album tree layout");
            active.add(new int[] {id, start});
        }
        Collections.sort(active, new java.util.Comparator<int[]>() {
            public int compare(int[] left, int[] right) { return left[1] - right[1]; }
        });
        List<List<Integer>> tracks = emptyTracks(records);
        for (int n = 0; n < active.size(); n++) {
            int end = n + 1 < active.size() ? active.get(n + 1)[1] : members.count + 1;
            if (active.get(n)[1] >= end) throw new IOException("Unsupported album tree layout");
            List<Integer> ids = new ArrayList<Integer>();
            for (int i = active.get(n)[1]; i < end; i++) {
                int id = u16(data, members.offset + 16 + (i - 1) * 2);
                if (id == 0) throw new IOException("Unsupported album tree layout");
                ids.add(id);
            }
            tracks.set(active.get(n)[0] - 1, ids);
        }
        return tracks;
    }

    private static List<List<Integer>> emptyTracks(int records) {
        List<List<Integer>> tracks = new ArrayList<List<Integer>>();
        for (int i = 0; i < records; i++) tracks.add(new ArrayList<Integer>());
        return tracks;
    }

    private static final class Section {
        final int offset, count;
        Section(int offset, int count) { this.offset = offset; this.count = count; }
    }

    private static Section section(byte[] data, String name, int size) throws IOException {
        Section found = null;
        for (int i = 0; i < 2; i++) {
            int at = 16 + i * 16;
            if (!magic(data, at, name)) continue;
            long offset = u32(data, at + 4), length = u32(data, at + 8);
            if (offset < 48 || length < 16 || offset + length > data.length || !magic(data, (int) offset, name))
                throw new IOException("Unsupported album tree layout");
            int count = u16(data, (int) offset + 4);
            if (u16(data, (int) offset + 6) != size || 16L + (long) count * size > length)
                throw new IOException("Unsupported album tree layout");
            if (found != null) throw new IOException("Unsupported album tree layout");
            found = new Section((int) offset, count);
        }
        if (found == null) throw new IOException("Unsupported album tree layout");
        return found;
    }

    private static String text(byte[] data, int tag) {
        if (tag < 0 || tag + TAG > data.length || u16(data, tag + 4) != 2) return "";
        int end = tag + 6;
        while (end + 1 < tag + TAG && u16(data, end) != 0) end += 2;
        try {
            return StandardCharsets.UTF_16BE.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(data, tag + 6, end - (tag + 6))).toString();
        } catch (CharacterCodingException e) { return ""; }
    }

    private static byte[] readBounded(Path path) throws IOException { return readBounded(path, MAX_TABLE); }

    private static byte[] readBounded(Path path, int max) throws IOException {
        NativePlaylistDatabase.checkPath(path);
        long size = Files.size(path);
        if (size > max) throw new IOException(max == MAX_TABLE ? "Invalid database file size" : "Jacket image is too large");
        try (InputStream in = Files.newInputStream(path)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream((int) size);
            byte[] chunk = new byte[8192];
            int n;
            while ((n = in.read(chunk)) >= 0) {
                if (out.size() + n > max) throw new IOException("Invalid database file size");
                out.write(chunk, 0, n);
            }
            return out.toByteArray();
        }
    }

    private static int u16(byte[] data, int at) { return ((data[at] & 255) << 8) | (data[at + 1] & 255); }
    private static long u32(byte[] data, int at) { return ((long) u16(data, at) << 16) | u16(data, at + 2); }
    private static boolean magic(byte[] data, int at, String text) {
        return at >= 0 && at + 4 <= data.length && new String(data, at, 4, StandardCharsets.US_ASCII).equals(text);
    }
}
