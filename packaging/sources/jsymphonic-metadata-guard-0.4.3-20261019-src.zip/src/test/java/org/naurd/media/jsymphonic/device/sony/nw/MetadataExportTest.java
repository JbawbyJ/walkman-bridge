package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import org.jaudiotagger.audio.AudioFileIO;
import org.jaudiotagger.tag.FieldKey;
import org.jaudiotagger.tag.Tag;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.naurd.media.jsymphonic.headless.HeadlessCli;
import org.naurd.media.jsymphonic.title.Mp3;
import org.naurd.media.jsymphonic.title.Oma;
import org.naurd.media.jsymphonic.title.Title;
import static org.junit.Assert.*;

public class MetadataExportTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();

    @Test public void realOmaExportAndCliListPreserveUnicodeTextAndAudio() throws Exception {
        assertRoundTrip(false);
    }

    @Test public void recoveredOmaExportKeepsTextAndAudio() throws Exception {
        assertRoundTrip(true);
    }

    private void assertRoundTrip(boolean recover) throws Exception {
        Path mount = temporary.newFolder().toPath();
        Path audio = Files.createDirectories(mount.resolve("OMGAUDIO/10F00")).resolve("10000001.OMA");
        byte[] frames = frames();
        FixtureMp3 original = new FixtureMp3(temporary.getRoot().toPath().resolve("not-yet-created.mp3").toFile());
        Oma wrapped = new Oma(audio.toFile(), original);
        try (FileOutputStream out = new FileOutputStream(audio.toFile())) {
            wrapped.writeTagInfoToFile(out, false);
            out.write(frames);
        }
        byte[] before = Files.readAllBytes(audio);
        if (recover) {
            Path payload = temporary.newFile().toPath();
            Files.write(payload, before);
            Files.delete(audio);
            try {
                OmgaudioJournal.commit(mount.resolve("OMGAUDIO"),
                        java.util.Collections.<OmgaudioJournal.FileSpec>emptyList(),
                        java.util.Collections.singletonList(new OmgaudioJournal.AudioSpec(false, "10F00/10000001.OMA", payload)),
                        null, new OmgaudioJournal.Probe() {
                            public void step(String name) {
                                if ("commit".equals(name)) throw new OmgaudioJournal.Interrupt(name);
                            }
                        });
                fail("Expected simulated interruption");
            } catch (OmgaudioJournal.Interrupt expected) { assertEquals("commit", expected.step); }
            assertTrue(OmgaudioJournal.inspect(mount.resolve("OMGAUDIO")).pending);
            OmgaudioJournal.recover(mount.resolve("OMGAUDIO"));
            assertArrayEquals(before, Files.readAllBytes(audio));
        }
        Path destination = temporary.newFolder().toPath();
        ExportDevice device = new ExportDevice(mount, destination);
        device.exportAll();
        Path exported = destination.resolve("坂本龍一/音楽😀/07-夜の歌Ā.mp3");
        assertTrue("Real export produced an MP3", Files.isRegularFile(exported));
        Tag tag = AudioFileIO.read(exported.toFile()).getTag();
        assertNotNull("Export must carry tags, not only audio", tag);
        assertEquals("夜の歌Ā", tag.getFirst(FieldKey.TITLE));
        assertEquals("坂本龍一", tag.getFirst(FieldKey.ARTIST));
        assertEquals("音楽😀", tag.getFirst(FieldKey.ALBUM));
        assertEquals("電子音楽", tag.getFirst(FieldKey.GENRE));
        assertEquals("2024", tag.getFirst(FieldKey.YEAR));
        assertEquals("7", tag.getFirst(FieldKey.TRACK));
        byte[] bytes = Files.readAllBytes(exported);
        assertEquals('I', bytes[0]); assertEquals('D', bytes[1]); assertEquals('3', bytes[2]);
        assertEquals(3, bytes[3]);
        int tagSize = ((bytes[6] & 127) << 21) | ((bytes[7] & 127) << 14)
                | ((bytes[8] & 127) << 7) | (bytes[9] & 127);
        assertArrayEquals(frames, Arrays.copyOfRange(bytes, tagSize + 10, bytes.length));
        assertArrayEquals("Export must not modify OMA", before, Files.readAllBytes(audio));
        ByteArrayOutputStream json = new ByteArrayOutputStream();
        int code = HeadlessCli.run(new String[] {"list", "--device", mount.toString()},
                new PrintStream(json, true, "UTF-8"), new PrintStream(new ByteArrayOutputStream()));
        assertEquals(0, code);
        assertTrue(json.toString("UTF-8"), json.toString("UTF-8").contains("\"genre\":\"電子音楽\""));
    }

    @Test public void emptyFieldsAreNotInventedAndOversizeTextIsRejectedBeforeOutput() throws Exception {
        FixtureMp3 title = new FixtureMp3(temporary.getRoot().toPath().resolve("absent.mp3").toFile());
        title.clear();
        Path output = temporary.newFile().toPath();
        try (FileOutputStream out = new FileOutputStream(output.toFile())) { title.writeTagInfoToFile(out, false); }
        assertEquals("Empty text has no frames", 10, Files.size(output));
        title.setTitleName(new String(new char[20000]).replace('\0', 'x'));
        try (FileOutputStream out = new FileOutputStream(output.toFile())) {
            try { ((Title) title).writeTagInfoToFile(out, false); fail("Unbounded text must be refused"); }
            catch (java.io.IOException expected) { assertTrue(expected.getMessage().contains("ID3")); }
        }
        assertEquals(0, Files.size(output));
    }

    @Test public void nativeTextLimitDoesNotSplitUnicodeOrMutateOriginal() {
        String prefix = new String(new char[59]).replace('\0', 'a');
        FixtureMp3 title = new FixtureMp3(new File(temporary.getRoot(), "missing.mp3"));
        String value = prefix + "😀tail";
        title.setTitleName(value); title.setArtistName(value); title.setAlbumName(value); title.setGenre(value);
        assertEquals(prefix, title.getTitle()); assertEquals(prefix, title.getArtist());
        assertEquals(prefix, title.getAlbum()); assertEquals(prefix, title.getGenre());
        assertEquals(value, title.rawTitle());
        String exactlySixty = prefix + "x";
        title.setTitleName(exactlySixty);
        assertEquals(exactlySixty, title.getTitle());
        String pairEndsAtLimit = prefix.substring(1) + "😀";
        title.setTitleName(pairEndsAtLimit + "tail");
        assertEquals(pairEndsAtLimit, title.getTitle());
    }

    @Test public void explicitFilenamePatternModeStillWorks() throws Exception {
        Path file = Files.createDirectories(temporary.getRoot().toPath().resolve("Configured artist/Configured album")).resolve("Chosen title.mp3");
        Files.write(file, frames());
        try {
            Title.setTryReadTagInfo(false);
            java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("localization/jsymphonicproperties");
            Title.setTryReadTagInfoPattern("<" + bundle.getString("JSymphonicProperties.Artist")
                    + ">/<" + bundle.getString("JSymphonicProperties.Album")
                    + ">/<" + bundle.getString("JSymphonicProperties.Title") + ">");
            Mp3 title = new Mp3(file.toFile());
            assertEquals("Configured artist", title.getArtist());
            assertEquals("Configured album", title.getAlbum());
            assertEquals("Chosen title", title.getTitle());
        } finally {
            Title.setTryReadTagInfo(true);
            Title.setTryReadTagInfoPattern("");
        }
    }

    @Test public void utf16FalseSyncBytesRoundTripThroughIndependentId3Reader() throws Exception {
        FixtureMp3 title = new FixtureMp3(new File(temporary.getRoot(), "absent.mp3"));
        String value = "\uffe0Ā😀";
        title.setTitleName(value);
        Path file = temporary.getRoot().toPath().resolve("unsync.mp3");
        try (FileOutputStream out = new FileOutputStream(file.toFile())) {
            title.writeTagInfoToFile(out, false); out.write(frames());
        }
        assertEquals(value, AudioFileIO.read(file.toFile()).getTag().getFirst(FieldKey.TITLE));
    }

    @Test public void untaggedMp3DoesNotInventMetadataFromItsFolders() throws Exception {
        Path file = Files.createDirectories(temporary.getRoot().toPath().resolve("not-an-artist/not-an-album")).resolve("not-a-title.mp3");
        Files.write(file, frames());
        Title.setTryReadTagInfo(true);
        Mp3 title = new Mp3(file.toFile());
        assertEquals("", title.getTitle()); assertEquals("", title.getArtist());
        assertEquals("", title.getAlbum()); assertEquals("", title.getGenre());
        assertEquals(0, title.getYear()); assertEquals(0, title.getTitleNumber());
        Oma wrapped = new Oma(temporary.newFile().getAbsoluteFile(), title);
        try (FileOutputStream out = new FileOutputStream(wrapped.getSourceFile())) {
            wrapped.writeTagInfoToFile(out, false); out.write(frames());
        }
        Oma readback = new Oma(wrapped.getSourceFile());
        assertEquals("", readback.getTitle()); assertEquals("", readback.getArtist());
        assertEquals("", readback.getAlbum()); assertEquals("", readback.getGenre());
    }

    @Test public void malformedUnicodeAndNulAreRefusedBeforeExportWrites() throws Exception {
        for (String bad : new String[] {"broken\ud83d", "one\0two"}) {
            FixtureMp3 title = new FixtureMp3(new File(temporary.getRoot(), "absent.mp3"));
            title.setTitleName(bad);
            Path file = temporary.newFile().toPath();
            try (FileOutputStream out = new FileOutputStream(file.toFile())) {
                try { title.writeTagInfoToFile(out, false); fail("Invalid ID3 text"); }
                catch (java.io.IOException expected) { assertTrue(expected.getMessage().contains("ID3")); }
            }
            assertEquals(0, Files.size(file));
        }
    }

    @Test public void twoUntaggedTracksExportSeparatelyWithoutInventedTags() throws Exception {
        Path mount = temporary.newFolder().toPath();
        Path audioFolder = Files.createDirectories(mount.resolve("OMGAUDIO/10F00"));
        byte[][] expected = new byte[2][];
        for (int id = 1; id <= 2; id++) {
            FixtureMp3 title = new FixtureMp3(new File(temporary.getRoot(), "absent.mp3"));
            title.clear();
            byte[] payload = frames();
            payload[100] = (byte) id;
            expected[id - 1] = payload;
            Path audio = audioFolder.resolve(String.format(java.util.Locale.ROOT, "1%07X.OMA", id));
            Oma wrapped = new Oma(audio.toFile(), title);
            try (FileOutputStream out = new FileOutputStream(audio.toFile())) {
                wrapped.writeTagInfoToFile(out, false); out.write(payload);
            }
        }
        Path destination = temporary.newFolder().toPath();
        new ExportDevice(mount, destination).exportAll();
        try (java.util.stream.Stream<Path> exported = Files.walk(destination)) {
            assertEquals("Every untagged track must be exported", 2, exported.filter(Files::isRegularFile).count());
        }
        for (int id = 1; id <= 2; id++) {
            Path file = destination.resolve(String.format(java.util.Locale.ROOT, "Track-%08X.mp3", id));
            assertTrue("Track ID supplies only a filesystem name", Files.isRegularFile(file));
            Tag tag = AudioFileIO.read(file.toFile()).getTag();
            if (tag != null) for (FieldKey field : new FieldKey[] {
                    FieldKey.TITLE, FieldKey.ARTIST, FieldKey.ALBUM, FieldKey.GENRE, FieldKey.YEAR, FieldKey.TRACK}) {
                assertEquals("No fabricated " + field, "", tag.getFirst(field));
            }
            byte[] bytes = Files.readAllBytes(file);
            assertArrayEquals(expected[id - 1], Arrays.copyOfRange(bytes, 10, bytes.length));
            Oma source = new Oma(audioFolder.resolve(String.format(java.util.Locale.ROOT, "1%07X.OMA", id)).toFile());
            assertEquals("", source.getTitle()); assertEquals("", source.getArtist());
            assertEquals("", source.getAlbum()); assertEquals("", source.getGenre());
        }
    }

    private static byte[] frames() {
        // Valid MPEG-1 Layer III, 128kbps/44.1kHz frames; deterministic silence-shaped payload.
        byte[] data = new byte[417 * 100];
        for (int i = 0; i < data.length; i += 417) {
            data[i] = (byte) 0xff; data[i + 1] = (byte) 0xfb; data[i + 2] = (byte) 0x90;
        }
        return data;
    }

    private static class FixtureMp3 extends Mp3 {
        FixtureMp3(File file) {
            super(file);
            titleName = "夜の歌Ā"; artistName = "坂本龍一"; albumName = "音楽😀"; genre = "電子音楽";
            year = 2024; titleNumber = 7; bitRate = 128; frequency = 44.1; nbChannels = 2;
            framesNumber = 100; length = 2600;
        }
        void clear() { titleName = ""; artistName = ""; albumName = ""; genre = ""; year = 0; titleNumber = 0; }
        String rawTitle() { return titleName; }
    }

    private static class ExportDevice extends NWOmgaudio {
        ExportDevice(Path mount, Path destination) {
            super(mount.toString(), "fixture", "", null, GENERATION_7, null, destination.toString(), false);
        }
        void exportAll() {
            for (Object title : getTitlesInMap().keySet()) scheduleExport((Title) title);
            titleVectorsMonitor.initialize(dataBase.getTitles());
            applyExport();
        }
    }
}
