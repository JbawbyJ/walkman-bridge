package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public class OmgaudioRecoveryHardeningTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();

    @Test public void publisherThatWritesThenThrowsRestoresItsTarget() throws Exception {
        Path root = temporary.newFolder().toPath();
        write(root.resolve("TABLE.DAT"), "before");
        try {
            OmgaudioJournal.commit(root, Collections.singletonList(
                    new OmgaudioJournal.FileSpec("TABLE.DAT", bytes("before"), bytes("after"))),
                    Collections.<OmgaudioJournal.AudioSpec>emptyList(),
                    new NativePlaylistDatabase.Publisher() {
                        public void publish(Path source, Path target) throws IOException {
                            Files.copy(source, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                            throw new IOException("failure after target was changed");
                        }
                    }, null);
            fail("publish failure must surface");
        } catch (IOException expected) { }
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void cleanupFailureKeepsTheFullyPublishedSnapshot() throws Exception {
        Path root = temporary.newFolder().toPath();
        write(root.resolve("TABLE.DAT"), "before");
        Path deleted = Files.createDirectories(root.resolve("10F00")).resolve("10000001.OMA");
        write(deleted, "old audio");
        try {
            OmgaudioJournal.commit(root, Collections.singletonList(
                    new OmgaudioJournal.FileSpec("TABLE.DAT", bytes("before"), bytes("after"))),
                    Collections.singletonList(new OmgaudioJournal.AudioSpec(true, "10F00/10000001.OMA", deleted)),
                    null, new OmgaudioJournal.Probe() {
                        public void step(String step) throws IOException {
                            if ("cleanup-retired".equals(step)) throw new IOException("cleanup interrupted");
                        }
                    });
            fail("cleanup failure must surface");
        } catch (IOException expected) { }
        assertArrayEquals(bytes("after"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertFalse(Files.exists(deleted));
        OmgaudioJournal.recover(root);
        OmgaudioJournal.recover(root);
        assertArrayEquals(bytes("after"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertFalse(Files.exists(deleted));
    }

    @Test public void unknownFormatPreservesJournalAndStrayEvidence() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = Files.createDirectory(root.resolve(OmgaudioJournal.DIRECTORY));
        write(journal.resolve("format"), "99\n");
        Path stray = root.resolve("TABLE.DAT.jsymphonic-tmp");
        write(stray, "unknown outcome");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("99\n"), Files.readAllBytes(journal.resolve("format")));
        assertArrayEquals(bytes("unknown outcome"), Files.readAllBytes(stray));
    }

    @Test public void missingAudioManifestRejectsRecoveryBeforePublishing() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        Files.delete(journal.resolve("audio.txt"));
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    @Test public void missingLaterPayloadRejectsRecoveryBeforePublishingEarlierTable() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("files.txt"), "TABLE.DAT\nMISSING.DAT\n");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    @Test public void malformedAudioEntryPreservesTablesAndProbeSiblings() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("audio.txt"), "unknown\t10F00/10000001.oma\tadd-0.dat\n");
        write(journal.resolve("add-0.dat"), "new audio");
        Path sibling = Files.createDirectory(root.resolve("10F00")).resolve("track.oma.jsymphonic-probe");
        write(sibling, "pending probe");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertArrayEquals(bytes("pending probe"), Files.readAllBytes(sibling));
        assertFalse(Files.exists(sibling.resolveSibling("track.oma")));
    }

    @Test public void rollbackPreservesAnExistingEmptyTable() throws Exception {
        Path root = temporary.newFolder().toPath();
        write(root.resolve("EMPTY.DAT"), "");
        try {
            OmgaudioJournal.commit(root, Collections.singletonList(
                    new OmgaudioJournal.FileSpec("EMPTY.DAT", new byte[0], bytes("after"))),
                    Collections.<OmgaudioJournal.AudioSpec>emptyList(), null,
                    new OmgaudioJournal.Probe() {
                        public void step(String step) throws IOException {
                            if ("publish:EMPTY.DAT".equals(step)) throw new IOException("publish interrupted");
                        }
                    });
            fail("publish failure must surface");
        } catch (IOException expected) { }
        assertTrue("An empty original is different from an absent original", Files.isRegularFile(root.resolve("EMPTY.DAT")));
        assertEquals(0, Files.size(root.resolve("EMPTY.DAT")));
    }

    @Test public void recoveryDoesNotOverwriteATableChangedOutsideTheTransaction() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(root.resolve("TABLE.DAT"), "external update");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("external update"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    @Test public void recoveryDoesNotDeleteAudioChangedOutsideTheTransaction() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("audio.txt"), "delete\t10F00/10000001.OMA\tdel-0.dat\n");
        write(journal.resolve("del-0.dat"), "old audio");
        Path audio = Files.createDirectory(root.resolve("10F00")).resolve("10000001.OMA");
        write(audio, "external audio");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("external audio"), Files.readAllBytes(audio));
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    @Test public void recoveryDoesNotFollowAnAudioDirectoryLink() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path outside = temporary.newFolder().toPath();
        Path sibling = outside.resolve("track.oma.jsymphonic-probe");
        write(sibling, "outside device root");
        linkDirectory(root.resolve("10F00"), outside);
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("outside device root"), Files.readAllBytes(sibling));
        assertFalse(Files.exists(outside.resolve("track.oma")));
    }

    @Test public void inspectDoesNotFollowAnAudioDirectoryLink() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path outside = temporary.newFolder().toPath();
        write(outside.resolve("track.oma.jsymphonic-probe"), "outside device root");
        linkDirectory(root.resolve("10F00"), outside);
        try {
            OmgaudioJournal.listPendingProbes(root);
            fail("probe discovery must reject paths outside its device root");
        } catch (IOException expected) { }
    }

    @Test public void invalidLegacyDestinationDoesNotPartiallyPublish() throws Exception {
        Path root = temporary.newFolder().toPath();
        write(root.resolve("TABLE.DAT"), "before");
        Path journal = Files.createDirectory(root.resolve(OmgaudioJournal.DIRECTORY));
        write(journal.resolve("files.txt"), "TABLE.DAT\n..\n");
        write(journal.resolve("tree.next"), "after");
        write(journal.resolve("info.next"), "invalid destination");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal));
    }

    @Test public void malformedCommitMarkerPreservesTheJournal() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("commit"), "not a valid commit marker");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal));
    }

    @Test public void omittedTablePayloadPreservesTheWholeTransaction() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(root.resolve("OTHER.DAT"), "other before");
        write(journal.resolve("OTHER.DAT.before"), "other before");
        write(journal.resolve("OTHER.DAT.next"), "other after");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertArrayEquals(bytes("other before"), Files.readAllBytes(root.resolve("OTHER.DAT")));
        assertTrue(Files.exists(journal.resolve("OTHER.DAT.next")));
    }

    @Test public void omittedAudioPayloadPreservesTheWholeTransaction() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("add-0.dat"), "omitted audio");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertArrayEquals(bytes("omitted audio"), Files.readAllBytes(journal.resolve("add-0.dat")));
    }

    @Test public void duplicateTableDestinationIsRejectedBeforeAnyPublication() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("files.txt"), "TABLE.DAT\nTABLE.DAT\n");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    @Test public void conflictingAudioDestinationsAreRejectedBeforeAnyPublication() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("audio.txt"), "add\t10F00/10000001.oma\tadd-0.dat\nadd\t10F00/10000001.OMA\tadd-1.dat\n");
        write(journal.resolve("add-0.dat"), "first audio");
        write(journal.resolve("add-1.dat"), "second audio");
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertFalse(Files.exists(root.resolve("10F00")));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    @Test public void unsupportedAudioDestinationDoesNotTouchLinkedTemporaryFile() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("audio.txt"), "add\t10F00/track.bin\tadd-0.dat\n");
        write(journal.resolve("add-0.dat"), "audio payload");
        Path outside = temporary.newFile().toPath();
        write(outside, "outside original");
        Files.createLink(Files.createDirectory(root.resolve("10F00")).resolve("track.bin.jsymphonic-tmp"), outside);
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("outside original"), Files.readAllBytes(outside));
        assertArrayEquals(bytes("before"), Files.readAllBytes(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    @Test public void atomicWriteNeverTruncatesAnExistingTemporaryHardLink() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path outside = temporary.newFile().toPath();
        write(outside, "outside original");
        Files.createLink(root.resolve("TABLE.DAT.jsymphonic-tmp"), outside);
        try {
            OmgaudioJournal.atomicWrite(root, "TABLE.DAT", bytes("new table"));
            fail("an existing temporary path must not be opened for writing");
        } catch (IOException expected) { }
        assertArrayEquals(bytes("outside original"), Files.readAllBytes(outside));
        assertFalse(Files.exists(root.resolve("TABLE.DAT")));
        assertTrue(Files.exists(root.resolve("TABLE.DAT.jsymphonic-tmp")));
    }

    @Test public void failedAtomicPublishDoesNotPoisonTheNextAttempt() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path obstruction = Files.createDirectory(root.resolve("TABLE.DAT"));
        write(obstruction.resolve("child"), "preserve obstruction");
        try {
            OmgaudioJournal.atomicWrite(root, "TABLE.DAT", bytes("new table"));
            fail("cannot publish over a directory");
        } catch (IOException expected) { }
        Files.delete(obstruction.resolve("child"));
        Files.delete(obstruction);
        OmgaudioJournal.atomicWrite(root, "TABLE.DAT", bytes("retry table"));
        assertArrayEquals(bytes("retry table"), Files.readAllBytes(root.resolve("TABLE.DAT")));
    }

    @Test public void recoveryCopyNeverTruncatesAnExistingJacketTemporaryHardLink() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path journal = committed(root);
        write(journal.resolve("audio.txt"), "add\t20P00/1G000001P0.JPG\tadd-0.dat\n");
        write(journal.resolve("add-0.dat"), "jacket payload");
        Path outside = temporary.newFile().toPath();
        write(outside, "outside original");
        Path link = Files.createDirectory(root.resolve("20P00")).resolve("1G000001P0.JPG.jsymphonic-tmp");
        Files.createLink(link, outside);
        expectRecoveryFailure(root);
        assertArrayEquals(bytes("outside original"), Files.readAllBytes(outside));
        assertTrue(Files.exists(link));
        assertTrue(Files.exists(journal.resolve("commit")));
    }

    private static void linkDirectory(Path link, Path destination) throws Exception {
        if (System.getProperty("os.name").startsWith("Windows")) {
            // Directory junctions exercise reparse-point handling without requiring
            // the privileged Windows symbolic-link capability. Both paths are fixtures.
            Process process = new ProcessBuilder("cmd.exe", "/c", "mklink", "/J",
                    link.toString(), destination.toString()).redirectErrorStream(true).start();
            try (java.io.InputStream output = process.getInputStream()) {
                while (output.read() != -1) { }
            }
            assertEquals("could not create fixture junction", 0, process.waitFor());
        } else {
            Files.createSymbolicLink(link, destination);
        }
    }

    private Path committed(Path root) throws IOException {
        write(root.resolve("TABLE.DAT"), "before");
        Path journal = Files.createDirectory(root.resolve(OmgaudioJournal.DIRECTORY));
        write(journal.resolve("format"), "2\n");
        write(journal.resolve("files.txt"), "TABLE.DAT\n");
        write(journal.resolve("audio.txt"), "");
        write(journal.resolve("TABLE.DAT.before"), "before");
        write(journal.resolve("TABLE.DAT.next"), "after");
        write(journal.resolve("commit"), "");
        return journal;
    }

    private static void expectRecoveryFailure(Path root) throws IOException {
        try { OmgaudioJournal.recover(root); fail("unsafe journal must be preserved for reconciliation"); }
        catch (IOException expected) { }
    }

    private static byte[] bytes(String value) { return value.getBytes(StandardCharsets.UTF_8); }
    private static void write(Path file, String value) throws IOException { Files.write(file, bytes(value)); }
}
