package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.naurd.media.jsymphonic.headless.HeadlessCli;
import static org.junit.Assert.*;

/** Synthetic rows derived from the saved 2026-09-05 native capture's layout.
 * No saved personal metadata, images, or live-device access is needed. */
public class NativeArtworkRebuildGuardTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();
    private static final String[] ALBUM = {"TIT2", "TPE1", "TCON", "TSOP", "PICP", "PIC0"};
    private static final String[] TREE37 = {"TIT2", "PICP", "PIC0", "XSOT"};
    private static final String PREVIEW = "200200;20P05\\JN0005P0.JPG";
    private static final String VARIANTS = "096096;20P05\\JN000501.JPG|032032;20P05\\JN000502.JPG";

    @Test public void tree37OnlyNativePicturesAreRefusedEvenWithoutTable01() throws Exception {
        Path root = temporary.newFolder().toPath();
        byte[] table = table(TREE37, PREVIEW, VARIANTS);
        Files.write(root.resolve("03GINF37.DAT"), table);
        refused(root, "03ginf37.dat");
        assertArrayEquals(table, Files.readAllBytes(root.resolve("03GINF37.DAT")));
        assertEquals(1, root.toFile().list().length);
    }

    @Test public void eachNativePictureVariantAndOpaquePayloadAreRefused() throws Exception {
        for (String filename : new String[] {"03GINF01.DAT", "03GINF22.DAT", "03gInF37.dAt", "03GINF38.DAT"}) {
            for (int picture = 0; picture < 3; picture++) {
                Path root = temporary.newFolder().toPath();
                String[] tags = filename.contains("01") || filename.contains("22") ? ALBUM : TREE37;
                byte[] table = table(tags, picture == 0 ? PREVIEW : "", picture == 1 ? VARIANTS : "");
                if (picture == 2) table[0x30 + 16 + Arrays.asList(tags).indexOf("PIC0") * 128 + 6] = (byte) 0xff;
                Files.write(root.resolve(filename), table);
                refused(root, filename.toLowerCase(java.util.Locale.ROOT));
                assertArrayEquals(table, Files.readAllBytes(root.resolve(filename)));
            }
        }
    }

    @Test public void captureShapedSixRowTable37ScansPictureDataInLaterSlots() throws Exception {
        Path root = temporary.newFolder().toPath();
        byte[] empty = table(TREE37, "", "");
        byte[] pictured = table(TREE37, PREVIEW, VARIANTS);
        int stride = 0x210;
        byte[] captureShape = Arrays.copyOf(empty, 0x30 + 6 * stride);
        ByteBuffer.wrap(captureShape).putInt(24, 16 + 6 * stride).putShort(36, (short) 6);
        for (int n = 0; n < 6; n++) System.arraycopy(n >= 4 ? pictured : empty, 0x30, captureShape, 0x30 + n * stride, stride);
        // These are the same record/tag offsets as the preserved native capture.
        assertEquals("PICP", new String(captureShape, 0x900, 4, StandardCharsets.US_ASCII));
        assertEquals("PIC0", new String(captureShape, 0x980, 4, StandardCharsets.US_ASCII));
        Files.write(root.resolve("03GINF37.DAT"), captureShape);
        Files.write(root.resolve("03GINF01.DAT"), table(ALBUM, "", ""));
        refused(root, "03ginf37.dat");
        assertArrayEquals(captureShape, Files.readAllBytes(root.resolve("03GINF37.DAT")));
    }

    @Test public void unsupportedStrideAndOversizeGinfAreRefused() throws Exception {
        Path root = temporary.newFolder().toPath();
        Path file = root.resolve("03GINF38.DAT");
        Files.write(file, table(new String[] {"TIT2", "PICP", "PIC0"}, "", ""));
        refused(root, "03ginf38.dat");
        byte[] oversized = new byte[4 * 1024 * 1024 + 1];
        Files.write(file, oversized);
        refused(root, "03ginf38.dat");
        assertEquals(oversized.length, Files.size(file));
    }

    @Test public void knownEmptyPictureAndNonPictureLayoutsRemainAllowed() throws Exception {
        Path root = temporary.newFolder().toPath();
        for (String filename : new String[] {"03GINF01.DAT", "03GINF22.DAT"}) Files.write(root.resolve(filename), table(ALBUM, "", ""));
        Files.write(root.resolve("03GINF37.DAT"), table(TREE37, "", ""));
        Files.write(root.resolve("03GINF02.DAT"), table(new String[] {"TIT2"}, "", ""));
        Files.write(root.resolve("03GINF2F.DAT"), table(new String[] {"TIT2", "XSOT"}, "", ""));
        JacketDatabase.assertRebuildSafe(root.toFile());
    }

    @Test public void malformedNativeLayoutsFailClosedWithoutPictureStrings() throws Exception {
        for (int damage = 0; damage < 7; damage++) {
            Path root = temporary.newFolder().toPath();
            byte[] table = table(TREE37, "", "");
            if (damage == 0) table[0] = 'X';
            if (damage == 1) ByteBuffer.wrap(table).putShort(0x26, (short) 0x110);
            if (damage == 2) ByteBuffer.wrap(table).putShort(0x3c, (short) 3);
            if (damage == 3) table[0x40 + 128 + 5] = 1;
            if (damage == 4) table[0x40 + 128] = 'X';
            if (damage == 5) table = Arrays.copyOf(table, table.length - 1);
            if (damage == 6) ByteBuffer.wrap(table).putShort(0x24, (short) 0);
            Files.write(root.resolve("03GINF37.DAT"), table);
            refused(root, "03ginf37.dat");
            assertArrayEquals(table, Files.readAllBytes(root.resolve("03GINF37.DAT")));
        }
    }

    @Test public void tree37RefusalPrecedesAddOrDeleteAndProbeRecovery() throws Exception {
        for (String command : new String[] {"add", "del"}) {
            Path mount = temporary.newFolder().toPath();
            Path root = Files.createDirectory(mount.resolve("OMGAUDIO"));
            byte[] info = table(TREE37, PREVIEW, VARIANTS);
            Files.write(root.resolve("03GINF37.DAT"), info);
            Path audio = Files.createDirectory(root.resolve("10F00"));
            Path probe = audio.resolve("10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX);
            Files.write(probe, new byte[] {1, 2, 3});
            Path input = temporary.newFile("source-" + command + ".mp3").toPath();
            ByteArrayOutputStream json = new ByteArrayOutputStream();
            String[] args = "add".equals(command)
                    ? new String[] {command, "--device", mount.toString(), input.toString()}
                    : new String[] {command, "--device", mount.toString(), "--id", "1"};
            int code = HeadlessCli.run(args, new PrintStream(json, true, "UTF-8"), new PrintStream(new ByteArrayOutputStream()));
            assertEquals(json.toString("UTF-8"), 1, code);
            assertTrue(json.toString("UTF-8"), json.toString("UTF-8").contains("DEVICE_ARTWORK_REBUILD_UNSUPPORTED"));
            assertFalse(json.toString("UTF-8").contains("\"event\":\"start\""));
            assertArrayEquals(info, Files.readAllBytes(root.resolve("03GINF37.DAT")));
            assertArrayEquals(new byte[] {1, 2, 3}, Files.readAllBytes(probe));
            assertEquals(2, root.toFile().list().length);
            assertEquals(1, audio.toFile().list().length);
        }
    }

    private static void refused(Path root, String filename) throws Exception {
        try { JacketDatabase.assertRebuildSafe(root.toFile()); fail("Native artwork/layout must block a rebuild"); }
        catch (NativePlaylistDatabase.Fatal expected) {
            assertEquals("DEVICE_ARTWORK_REBUILD_UNSUPPORTED", expected.code);
            assertTrue(expected.getMessage(), expected.getMessage().toLowerCase(java.util.Locale.ROOT).contains(filename));
        }
    }

    private static byte[] table(String[] tags, String preview, String variants) {
        int stride = 16 + 128 * tags.length;
        byte[] data = new byte[0x30 + stride];
        ascii(data, 0, "GPIF"); ByteBuffer.wrap(data).putInt(4, 0x01010000); data[8] = 1;
        ascii(data, 16, "GPFB"); ByteBuffer.wrap(data).putInt(20, 0x20).putInt(24, 16 + stride);
        ascii(data, 32, "GPFB"); ByteBuffer.wrap(data).putShort(36, (short) 1).putShort(38, (short) stride);
        ByteBuffer.wrap(data).putShort(60, (short) tags.length).putShort(62, (short) 128);
        for (int n = 0; n < tags.length; n++) {
            int at = 64 + n * 128;
            ascii(data, at, tags[n]); ByteBuffer.wrap(data).putShort(at + 4, (short) 2);
            String text = "PICP".equals(tags[n]) ? preview : "PIC0".equals(tags[n]) ? variants : "fixture";
            byte[] encoded = text.getBytes(StandardCharsets.UTF_16BE);
            System.arraycopy(encoded, 0, data, at + 6, encoded.length);
        }
        return data;
    }

    private static void ascii(byte[] data, int at, String text) {
        byte[] bytes = text.getBytes(StandardCharsets.US_ASCII); System.arraycopy(bytes, 0, data, at, bytes.length);
    }
}
