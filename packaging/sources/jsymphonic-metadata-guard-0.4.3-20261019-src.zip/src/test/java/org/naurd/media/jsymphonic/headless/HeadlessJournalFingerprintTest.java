package org.naurd.media.jsymphonic.headless;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.naurd.media.jsymphonic.device.sony.nw.OmgaudioJournal;
import static org.junit.Assert.*;

public class HeadlessJournalFingerprintTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();

    @Test public void journalFingerprintBindsPayloadBytesEvenWithIdenticalSummary() throws Exception {
        Path mount = device();
        Path journal = Files.createDirectory(mount.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY));
        Files.write(journal.resolve("format"), "2\n".getBytes(StandardCharsets.UTF_8));
        Path payload = journal.resolve("TABLE.DAT.next");
        Files.write(payload, "first payload".getBytes(StandardCharsets.UTF_8));
        String first = inspect(mount);
        assertEquals(field(first, "fingerprint"), field(inspect(mount), "fingerprint"));
        Files.write(payload, "other payload".getBytes(StandardCharsets.UTF_8));
        String second = inspect(mount);
        assertNotEquals(field(first, "fingerprint"), field(second, "fingerprint"));
        assertEquals(field(first, "library_fingerprint"), field(second, "library_fingerprint"));
        assertArrayEquals("other payload".getBytes(StandardCharsets.UTF_8), Files.readAllBytes(payload));
    }

    @Test public void libraryFingerprintExistsWithoutJournalAndBindsTableNamesAndBytes() throws Exception {
        Path mount = device();
        Path table = mount.resolve("OMGAUDIO/01TREE22.DAT");
        Files.write(table, new byte[] {1, 2, 3});
        String first = inspect(mount);
        assertTrue(first, first.contains("\"fingerprint\":null"));
        assertEquals(field(first, "library_fingerprint"), field(inspect(mount), "library_fingerprint"));
        Files.write(table, new byte[] {4, 5, 6});
        String changedBytes = inspect(mount);
        assertNotEquals(field(first, "library_fingerprint"), field(changedBytes, "library_fingerprint"));
        Files.move(table, mount.resolve("OMGAUDIO/03GINF22.DAT"));
        assertNotEquals(field(changedBytes, "library_fingerprint"), field(inspect(mount), "library_fingerprint"));
    }

    private Path device() throws Exception {
        Path mount = temporary.newFolder().toPath();
        Files.createDirectory(mount.resolve("OMGAUDIO"));
        return mount;
    }

    private static String inspect(Path mount) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        int code = HeadlessCli.run(new String[] {"playlist-recover", "--device", mount.toString(), "--inspect"},
                new PrintStream(output, true, "UTF-8"), new PrintStream(new ByteArrayOutputStream(), true, "UTF-8"));
        String json = output.toString("UTF-8");
        assertEquals(json, 0, code);
        return json;
    }

    private static String field(String json, String name) {
        Matcher match = Pattern.compile("\"" + name + "\":\"([a-f0-9]{64})\"").matcher(json);
        assertTrue("missing SHA-256 " + name + " in " + json, match.find());
        return match.group(1);
    }
}
