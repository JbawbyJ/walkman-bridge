package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Review acceptance tests for native Sony playlists (snapshot 7c11b3d).
 *
 * Several of these are EXPECTED TO FAIL until the review fixes land:
 * - inactiveGplbRowSurvivesUnrelatedEdit: encodeTree() currently drops inactive rows.
 * - *_reportsStableCode: assert on the structured NativePlaylistDatabase.Fatal.code
 *   (PLAYLIST_REF_MISSING, PLAYLIST_JOURNAL_PENDING, PLAYLIST_SLOTS_EXHAUSTED) that
 *   Builder B's #4 adds; the CLI JSON "code" field is covered by HeadlessCli tests.
 * - uncheckedPublishFailureDoesNotStrandJournal: save() only rolls back on IOException.
 *   #4 deliberately leaves the journal for playlist-recover; this test stays as a flag
 *   on that gap and is not rewritten to fit.
 * - rollbackOfFirstEverSaveLeavesNoHalfPair: depends on restore() deleting files
 *   that did not exist before the transaction.
 *
 * The DataBaseOmgaudio.write ordering issue (base tables rebuilt before the
 * playlist save) still needs a fixture-level integration test; the lockout test
 * below reproduces its on-disk end state at unit level only.
 */
public class NativePlaylistReviewTest {
    private static final String JOURNAL = ".jsymphonic-playlist-transaction";
    private final Set<Integer> tracks = new HashSet<Integer>(Arrays.asList(1, 3, 14));

    private static NativePlaylistDatabase.Publisher failOn(final int call, final boolean unchecked) {
        return new NativePlaylistDatabase.Publisher() {
            int calls;
            public void publish(Path source, Path target) throws IOException {
                if (++calls == call) {
                    if (unchecked) throw new IllegalStateException("injected unchecked failure on publish " + call);
                    throw new IOException("injected I/O failure on publish " + call);
                }
                Files.move(source, target, StandardCopyOption.REPLACE_EXISTING);
            }
        };
    }

    /**
     * Asserts on the structured code carried by NativePlaylistDatabase.Fatal (public field
     * {@code code}), never on message text, which is not a stable contract. Read reflectively
     * so this class still compiles on the 7c11b3d snapshot, where Fatal does not exist yet;
     * there these assertions fail cleanly instead of breaking the whole test compile.
     */
    private static void assertCode(IOException e, String code) {
        String actual = null;
        try {
            java.lang.reflect.Field f = e.getClass().getField("code");
            Object value = f.get(e);
            if (value instanceof String) actual = (String) value;
        } catch (NoSuchFieldException missing) {
            // pre-fix snapshot: no structured code
        } catch (IllegalAccessException inaccessible) {
            fail("Fatal.code must be publicly readable: " + inaccessible);
        }
        assertEquals("expected structured Fatal.code (not message text) for " + e.getClass().getName()
                + ": " + e.getMessage(), code, actual);
    }

    // 1. Inactive GPLB roundtrip (finding 1).
    @Test public void inactiveGplbRowSurvivesUnrelatedEdit() throws Exception {
        Path dir = Files.createTempDirectory("review-inactive-gplb-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(dir.toFile());
        db.create("Active", Arrays.asList(1, 3), tracks);
        db.create("Becomes inactive", Collections.<Integer>emptyList(), tracks);
        db.save();
        Path treeFile = dir.resolve("01tree22.dat");
        byte[] tree = Files.readAllBytes(treeFile);
        ByteBuffer b = ByteBuffer.wrap(tree).order(ByteOrder.BIG_ENDIAN);
        assertEquals(2, b.getShort(0x34));
        assertEquals(2, b.getShort(0x48));
        // Turn the second row into a native inactive slot: flag 0, start 0.
        b.putShort(0x4a, (short) 0);
        b.putShort(0x4c, (short) 0);
        Files.write(treeFile, tree);

        db = NativePlaylistDatabase.read(dir.toFile());
        assertEquals(1, db.list().size());
        db.update(1, "Renamed", null, tracks);
        db.save();

        ByteBuffer after = ByteBuffer.wrap(Files.readAllBytes(treeFile)).order(ByteOrder.BIG_ENDIAN);
        assertEquals("GPLB row count must keep the inactive Sony row", 2, after.getShort(0x34));
        assertEquals(2, after.getShort(0x48));
        assertEquals(0, after.getShort(0x4a));
        assertEquals(0, after.getShort(0x4c));
        assertEquals("Renamed", NativePlaylistDatabase.read(dir.toFile()).list().get(0).name);
    }

    // 2. Playlist save fails after base tables already dropped a track (finding 2).
    @Test public void failedPlaylistSaveAfterTrackRemovalIsRecoverable_reportsStableCode() throws Exception {
        Path dir = Files.createTempDirectory("review-lockout-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(dir.toFile());
        db.create("Mix", Arrays.asList(1, 3, 14), tracks);
        db.save();
        Set<Integer> afterBaseRebuild = new HashSet<Integer>(Arrays.asList(1, 14));
        db.retainTracks(afterBaseRebuild);
        try { db.save(failOn(1, false)); fail("injected failure must surface"); }
        catch (IOException expected) { }
        assertFalse(Files.exists(dir.resolve(JOURNAL)));

        NativePlaylistDatabase next = NativePlaylistDatabase.read(dir.toFile());
        try { next.validateReferences(afterBaseRebuild); fail("dangling reference must be reported"); }
        catch (IOException expected) { assertCode(expected, "PLAYLIST_REF_MISSING"); }

        // Repair path the UI will offer: prune and save.
        next.retainTracks(afterBaseRebuild);
        next.save();
        NativePlaylistDatabase repaired = NativePlaylistDatabase.read(dir.toFile());
        repaired.validateReferences(afterBaseRebuild);
        assertEquals(Arrays.asList(1, 14), repaired.list().get(0).trackIds);
    }

    // 3. Track removed by another app (finding 3).
    @Test public void externallyDeletedTrackCanBePruned_reportsStableCode() throws Exception {
        Path dir = Files.createTempDirectory("review-external-delete-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(dir.toFile());
        db.create("Walk", Arrays.asList(3, 1, 3), tracks);
        db.save();
        Set<Integer> remaining = new HashSet<Integer>(Arrays.asList(1, 14));
        db = NativePlaylistDatabase.read(dir.toFile());
        try { db.validateReferences(remaining); fail("missing track 3 must be reported"); }
        catch (IOException expected) {
            assertCode(expected, "PLAYLIST_REF_MISSING");
        }
        db.retainTracks(remaining);
        db.save();
        assertEquals(Arrays.asList(1), NativePlaylistDatabase.read(dir.toFile()).list().get(0).trackIds);
    }

    // 4a. Crash-like failure before anything is published (finding 4).
    @Test public void uncheckedPublishFailureDoesNotStrandJournal() throws Exception {
        Path dir = Files.createTempDirectory("review-unchecked-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(dir.toFile());
        db.create("Before", Arrays.asList(1), tracks);
        db.save();
        byte[] tree = Files.readAllBytes(dir.resolve("01tree22.dat"));
        byte[] info = Files.readAllBytes(dir.resolve("03ginf22.dat"));
        db.update(1, "After", Arrays.asList(14), tracks);
        try { db.save(failOn(1, true)); fail("failure must surface"); }
        catch (RuntimeException expected) { }
        catch (IOException expected) { }
        assertArrayEquals(tree, Files.readAllBytes(dir.resolve("01tree22.dat")));
        assertArrayEquals(info, Files.readAllBytes(dir.resolve("03ginf22.dat")));
        assertFalse("a failure before any publish must not leave a blocking journal",
                Files.exists(dir.resolve(JOURNAL)));
        assertEquals("Before", NativePlaylistDatabase.read(dir.toFile()).list().get(0).name);
    }

    // 4b. A real pending journal: next command fails with a distinct code, evidence intact.
    @Test public void pendingJournalBlocksWithEvidence_reportsStableCode() throws Exception {
        Path dir = Files.createTempDirectory("review-journal-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(dir.toFile());
        db.create("Before", Arrays.asList(1), tracks);
        db.save();
        byte[] tree = Files.readAllBytes(dir.resolve("01tree22.dat"));
        byte[] info = Files.readAllBytes(dir.resolve("03ginf22.dat"));
        Path journal = Files.createDirectory(dir.resolve(JOURNAL));
        Files.write(journal.resolve("tree.before"), tree);
        Files.write(journal.resolve("info.before"), info);
        Files.write(journal.resolve("files.txt"), "01tree22.dat\n03ginf22.dat\n".getBytes(StandardCharsets.UTF_8));

        try { NativePlaylistDatabase.read(dir.toFile()); fail("pending journal must block"); }
        catch (IOException expected) { assertCode(expected, "PLAYLIST_JOURNAL_PENDING"); }
        // Blocking must never touch the evidence or the device pair.
        assertArrayEquals(tree, Files.readAllBytes(journal.resolve("tree.before")));
        assertArrayEquals(info, Files.readAllBytes(journal.resolve("info.before")));
        assertArrayEquals(tree, Files.readAllBytes(dir.resolve("01tree22.dat")));
        assertArrayEquals(info, Files.readAllBytes(dir.resolve("03ginf22.dat")));
    }

    // 5. Rollback when the playlist pair did not exist before the transaction.
    @Test public void rollbackOfFirstEverSaveLeavesNoHalfPair() throws Exception {
        Path dir = Files.createTempDirectory("review-first-save-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(dir.toFile());
        db.create("First", Arrays.asList(1), tracks);
        try { db.save(failOn(2, false)); fail("injected failure must surface"); }
        catch (IOException expected) { }
        assertFalse("03GINF22 created by the failed transaction must be removed", Files.exists(dir.resolve("03ginf22.dat")));
        assertFalse("01TREE22 must not exist after rollback", Files.exists(dir.resolve("01tree22.dat")));
        assertFalse(Files.exists(dir.resolve(JOURNAL)));
        assertTrue(NativePlaylistDatabase.read(dir.toFile()).list().isEmpty());
    }

    // 6. Slot exhaustion after 2048 lifetime creates (slots are never reused).
    @Test public void slotLimitRoundtripsAtCapacity_reportsStableCode() throws Exception {
        Path dir = Files.createTempDirectory("review-slots-");
        NativePlaylistDatabase db = NativePlaylistDatabase.read(dir.toFile());
        for (int i = 0; i < 2048; i++) {
            NativePlaylistDatabase.Playlist p = db.create("P" + i, Collections.<Integer>emptyList(), tracks);
            db.delete(p.id);
        }
        db.save();
        // A full 2048-record table must still parse cleanly.
        db = NativePlaylistDatabase.read(dir.toFile());
        assertTrue(db.list().isEmpty());
        byte[] info = Files.readAllBytes(dir.resolve("03ginf22.dat"));
        try { db.create("One more", Arrays.asList(1), tracks); fail("slot limit must be enforced"); }
        catch (IOException expected) { assertCode(expected, "PLAYLIST_SLOTS_EXHAUSTED"); }
        assertArrayEquals(info, Files.readAllBytes(dir.resolve("03ginf22.dat")));
    }
}
