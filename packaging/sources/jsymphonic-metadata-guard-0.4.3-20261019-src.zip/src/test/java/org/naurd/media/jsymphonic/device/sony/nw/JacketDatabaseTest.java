package org.naurd.media.jsymphonic.device.sony.nw;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Map;
import java.util.TreeMap;
import java.util.Arrays;
import java.util.Random;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import org.junit.Test;
import org.naurd.media.jsymphonic.headless.HeadlessCli;
import static org.junit.Assert.*;

public class JacketDatabaseTest {
    @Test public void libraryRebuildRefusesExistingArtworkBeforeMutation() throws Exception {
        Path device = deviceOf(fixture());
        Map<String, byte[]> before = fileTree(device);
        CliResult result = invoke("del", "--device", device.toString(), "--id", "1");
        assertEquals(result.out + result.err, 1, result.code);
        assertTrue(result.out, result.out.contains("DEVICE_ARTWORK_REBUILD_UNSUPPORTED"));
        assertTreeEquals(before, fileTree(device));
    }

    @Test public void libraryRebuildRefusesUnknownPicturePayloadButAllowsEmptySlots() throws Exception {
        Path root = fixture();
        byte[] table = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        for (int n = 0; n < 2; n++) {
            int start = 0x30 + n * 0x310 + 0x210;
            Arrays.fill(table, start + 6, start + 0x80, (byte) 0);
        }
        Files.write(root.resolve("03GINF01.DAT"), table);
        try {
            new DataBaseOmgaudio(root.toFile(), false, false, false, false, false).prepareWrite();
            fail("Opaque PIC0 bytes must not be erased");
        } catch (NativePlaylistDatabase.Fatal expected) {
            assertEquals("DEVICE_ARTWORK_REBUILD_UNSUPPORTED", expected.code);
        }
        for (int n = 0; n < 2; n++) {
            int start = 0x30 + n * 0x310 + 0x290;
            Arrays.fill(table, start + 6, start + 0x80, (byte) 0);
        }
        Files.write(root.resolve("03GINF01.DAT"), table);
        new DataBaseOmgaudio(root.toFile(), false, false, false, false, false).prepareWrite();
    }

    @Test public void addRefusesArtworkBeforeRestoringPendingProbe() throws Exception {
        Path device = deviceOf(fixture());
        Path probe = device.resolve("OMGAUDIO/10F00/10000001.OMA" + OmgaudioJournal.PROBE_SUFFIX);
        Files.createDirectories(probe.getParent());
        Files.write(probe, new byte[] {1, 2, 3});
        Path input = Files.createTempFile("metadata-artwork-", ".mp3");
        Files.write(input, new byte[] {1, 2, 3});
        Map<String, byte[]> before = fileTree(device);
        CliResult result = invoke("add", "--device", device.toString(), input.toString());
        assertEquals(result.out + result.err, 1, result.code);
        assertTrue(result.out, result.out.contains("DEVICE_ARTWORK_REBUILD_UNSUPPORTED"));
        assertFalse(result.out, result.out.contains("\"event\":\"start\""));
        assertTreeEquals(before, fileTree(device));
    }

    @Test public void malformedPictureLayoutIsRefusedWithoutMutation() throws Exception {
        Path device = deviceOf(fixture());
        Path info = device.resolve("OMGAUDIO/03GINF01.DAT");
        byte[] table = Files.readAllBytes(info);
        table[0x30 + 0x210] = 'X';
        Files.write(info, table);
        Map<String, byte[]> before = fileTree(device);
        CliResult result = invoke("del", "--device", device.toString(), "--id", "1");
        assertEquals(result.out + result.err, 1, result.code);
        assertTrue(result.out, result.out.contains("DEVICE_ARTWORK_REBUILD_UNSUPPORTED"));
        assertTreeEquals(before, fileTree(device));
    }

    @Test public void roundTripPreservesUntouchedRecordsAndImages() throws Exception {
        Path root = fixture();
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        byte[] tree = Files.readAllBytes(root.resolve("01TREE01.DAT"));
        byte[] other = Files.readAllBytes(root.resolve("05CIDLST.DAT"));
        byte[] kept = Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG"));
        byte[] stray = Files.readAllBytes(root.resolve("20P00/OTHER.JPG"));
        byte[] source = jpeg(2, 2, Color.BLUE);
        Path image = Files.createTempFile("jacket-src-", ".jpg");
        Files.write(image, source);

        JacketDatabase db = JacketDatabase.read(root.toFile());
        JacketDatabase.Jacket updated = db.setByTrack(3, image);
        assertEquals(2, updated.slot);
        assertEquals("Day", updated.album);
        assertEquals("Bea", updated.artist);
        assertEquals(Arrays.asList(3), updated.trackIds);
        assertArrayEquals(source, updated.image);
        db.save();

        JacketDatabase again = JacketDatabase.read(root.toFile());
        JacketDatabase.Jacket stored = again.list().get(1);
        assertEquals(updated.path, stored.path);
        assertArrayEquals(source, stored.image);
        assertArrayEquals(kept, again.list().get(0).image);
        byte[] after = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        assertEquals(before.length, after.length);
        int text = 0x340 + 0x210 + 6;
        for (int i = 0; i < before.length; i++) {
            if (i >= text && i < text + 0x80 - 6) continue;
            assertEquals("byte " + i, before[i], after[i]);
        }
        String written = new String(after, text, updated.path.length() * 2, StandardCharsets.UTF_16BE);
        assertEquals(updated.path, written);
        for (int i = text + updated.path.length() * 2; i < text + 0x80 - 6; i++)
            assertEquals("trailing " + i, 0, after[i]);
        assertArrayEquals(tree, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertArrayEquals(other, Files.readAllBytes(root.resolve("05CIDLST.DAT")));
        assertArrayEquals(kept, Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG")));
        assertArrayEquals(stray, Files.readAllBytes(root.resolve("20P00/OTHER.JPG")));
        assertTrue(updated.path.matches("20P00/1G[0-9A-F]{6}P0\\.JPG"));
        assertFalse(updated.path.endsWith("1G000001P0.JPG"));
    }

    @Test public void clearRemovesOnlyTheManagedPicture() throws Exception {
        Path root = fixture();
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        JacketDatabase db = JacketDatabase.read(root.toFile());
        JacketDatabase.Jacket cleared = db.clearByAlbum("Night");
        assertNull(cleared.path);
        assertEquals(0, cleared.bytes);
        db.save();
        assertFalse(Files.exists(root.resolve("20P00/1G000001P0.JPG")));
        byte[] after = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        int text = 0x30 + 0x210 + 6;
        for (int i = 0; i < before.length; i++) {
            if (i >= text && i < text + 0x80 - 6) continue;
            assertEquals("byte " + i, before[i], after[i]);
        }
        for (int i = text; i < text + 0x80 - 6; i++) assertEquals(0, after[i]);
        assertEquals("Day", JacketDatabase.read(root.toFile()).list().get(1).album);
    }

    @Test public void replaceKeepsTheOtherGroupsImage() throws Exception {
        Path root = fixture();
        byte[] kept = Files.readAllBytes(root.resolve("20P00/OTHER.JPG"));
        byte[] source = jpeg(2, 2, Color.GREEN);
        Path image = Files.createTempFile("jacket-replace-", ".jpg");
        Files.write(image, source);
        JacketDatabase db = JacketDatabase.read(root.toFile());
        JacketDatabase.Jacket replaced = db.setByAlbum("Night", image);
        db.save();
        assertFalse(Files.exists(root.resolve("20P00/1G000001P0.JPG")));
        assertArrayEquals(source, Files.readAllBytes(root.resolve(replaced.path)));
        assertArrayEquals(kept, Files.readAllBytes(root.resolve("20P00/OTHER.JPG")));
        assertEquals("Day", JacketDatabase.read(root.toFile()).list().get(1).album);
        assertNull(JacketDatabase.read(root.toFile()).list().get(1).path);
    }

    @Test public void interruptionAtEachJournalStepRecoversToOneSnapshot() throws Exception {
        byte[] source = jpeg(2, 2, Color.BLUE);
        JacketDatabase sample = JacketDatabase.read(fixture().toFile());
        sample.setByTrack(3, writeTemp(source));
        java.util.List<String> steps = sample.pendingSteps();
        int commit = steps.indexOf("commit");
        int cleanup = steps.indexOf("cleanup");
        int retired = steps.indexOf("cleanup-retired");
        assertTrue(commit > 0);
        assertTrue(retired > cleanup && cleanup > commit);
        for (String step : steps) {
            Path root = fixture();
            byte[] beforeInfo = Files.readAllBytes(root.resolve("03GINF01.DAT"));
            byte[] beforeJpeg = Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG"));
            JacketDatabase db = JacketDatabase.read(root.toFile());
            JacketDatabase.Jacket staged = db.setByTrack(3, writeTemp(source));
            try {
                db.save(new OmgaudioJournal.Probe() {
                    public void step(String name) {
                        if (name.equals(step)) throw new OmgaudioJournal.Interrupt(name);
                    }
                });
                fail(step);
            } catch (OmgaudioJournal.Interrupt expected) {
                assertEquals(step, expected.step);
            }
            byte[] during = Files.readAllBytes(root.resolve("03GINF01.DAT"));
            OmgaudioJournal.Report pending = OmgaudioJournal.inspect(root);
            assertArrayEquals(during, Files.readAllBytes(root.resolve("03GINF01.DAT")));
            assertTrue(step, pending.pending);
            // cleanup deletes the commit marker, then cleanup-retired renames the
            // journal aside. The live tree is already the new snapshot, so recover
            // must discard that directory instead of treating it as committed.
            boolean published = steps.indexOf(step) >= commit;
            boolean forward = published && !"cleanup-retired".equals(step);
            assertEquals(step, forward ? "roll-forward" : "roll-back", pending.action);
            if ("cleanup".equals(step)) {
                assertEquals(step, "committed", pending.state);
                assertTrue(step, Files.isRegularFile(root.resolve(OmgaudioJournal.DIRECTORY).resolve("commit")));
            }
            if ("cleanup-retired".equals(step)) {
                assertEquals(step, "uncommitted", pending.state);
                assertFalse(step, pending.committed);
                assertTrue(step, Files.isDirectory(root.resolve(OmgaudioJournal.DIRECTORY)));
                assertFalse(step, Files.exists(root.resolve(OmgaudioJournal.DIRECTORY).resolve("commit")));
                assertFalse(step, Files.exists(root.resolve(OmgaudioJournal.RETIRED)));
            }
            OmgaudioJournal.recover(root);
            assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
            assertFalse(step, Files.exists(root.resolve(OmgaudioJournal.RETIRED)));
            assertNoJournalTemps(root);
            JacketDatabase recovered = JacketDatabase.read(root.toFile());
            if (published) {
                assertArrayEquals(step, source, recovered.list().get(1).image);
                assertEquals(step, staged.path, recovered.list().get(1).path);
                assertArrayEquals(step, beforeJpeg, recovered.list().get(0).image);
            } else {
                assertArrayEquals(step, beforeInfo, Files.readAllBytes(root.resolve("03GINF01.DAT")));
                assertArrayEquals(step, beforeJpeg, Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG")));
                assertNull(step, recovered.list().get(1).path);
                assertFalse(step, Files.exists(root.resolve(staged.path)));
            }
        }
    }

    @Test public void invalidImagesAreRejectedBeforeAnyWrite() throws Exception {
        Path root = fixture();
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        JacketDatabase db = JacketDatabase.read(root.toFile());
        for (byte[] bad : new byte[][] {
                new byte[0],
                "GIF89a".getBytes(StandardCharsets.US_ASCII),
                new byte[] {(byte) 0xFF, (byte) 0xD8, (byte) 0xFF, (byte) 0xD9},
                oversized()
        }) {
            Path file = Files.createTempFile("jacket-bad-", ".bin");
            Files.write(file, bad);
            try {
                db.setByAlbum("Day", file);
                fail(Arrays.toString(Arrays.copyOf(bad, Math.min(4, bad.length))));
            } catch (java.io.IOException expected) {
                assertTrue(expected.getMessage(), expected.getMessage().startsWith("Jacket image"));
            }
        }
        db.save();
        assertArrayEquals(before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
        assertFalse(Files.exists(root.resolve("20P00/1G000002P0.JPG")));
    }

    @Test public void wideJpegIsScaledAndSmallBaselineJpegIsKept() throws Exception {
        byte[] small = jpeg(2, 2, Color.RED);
        assertArrayEquals(small, JacketDatabase.normalize(writeTemp(small)));
        byte[] wide = jpeg(500, 10, Color.YELLOW);
        byte[] scaled = JacketDatabase.normalize(writeTemp(wide));
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(scaled));
        assertEquals(JacketDatabase.MAX_EDGE, image.getWidth());
        assertEquals(5, image.getHeight());
        assertTrue(containsMarker(scaled, 0xC0));
        assertFalse(containsMarker(scaled, 0xC2));
    }

    @Test public void ambiguousAlbumAndMissingTrackDoNotWrite() throws Exception {
        Path root = fixture();
        byte[] table = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        int second = 0x340 + 16 + 6;
        byte[] night = "Night".getBytes(StandardCharsets.UTF_16BE);
        System.arraycopy(night, 0, table, second, night.length);
        Files.write(root.resolve("03GINF01.DAT"), table);
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        JacketDatabase db = JacketDatabase.read(root.toFile());
        try {
            db.setByAlbum("Night", writeTemp(jpeg(2, 2, Color.RED)));
            fail("ambiguous");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage(), expected.getMessage().contains("more than one"));
        }
        try {
            db.setByTrack(9, writeTemp(jpeg(2, 2, Color.RED)));
            fail("missing track");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage(), expected.getMessage().contains("track 9"));
        }
        db.save();
        assertArrayEquals(before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
    }

    @Test public void progressiveJpegRoundTripsAsBaseline() throws Exception {
        byte[] progressive = progressiveJpeg(16, 16, Color.BLUE);
        assertTrue(containsMarker(progressive, 0xC2));
        assertFalse(containsMarker(progressive, 0xC0));
        Path root = fixture();
        JacketDatabase db = JacketDatabase.read(root.toFile());
        JacketDatabase.Jacket staged = db.setByTrack(3, writeTemp(progressive));
        db.save();
        byte[] stored = JacketDatabase.read(root.toFile()).list().get(1).image;
        assertEquals(staged.path, "20P00/1G000002P0.JPG");
        assertArrayEquals(stored, Files.readAllBytes(root.resolve(staged.path)));
        assertTrue(containsMarker(stored, 0xC0));
        assertFalse(containsMarker(stored, 0xC2));
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(stored));
        assertEquals(16, image.getWidth());
        assertEquals(16, image.getHeight());
        int rgb = image.getRGB(8, 8);
        assertTrue(Integer.toHexString(rgb), (rgb & 0xFF) > 200 && ((rgb >> 16) & 0xFF) < 40);
    }

    @Test public void hugeProgressiveHeaderIsRejectedBeforeDecode() throws Exception {
        byte[] huge = patchSof(progressiveJpeg(8, 8, Color.GREEN), 0xC2, 20000, 20000);
        Path root = fixture();
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        byte[] jpeg = Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG"));
        JacketDatabase db = JacketDatabase.read(root.toFile());
        try {
            db.setByAlbum("Day", writeTemp(huge));
            fail("decoded");
        } catch (java.io.IOException expected) {
            assertEquals(expected.getMessage(), "Jacket image is too large", expected.getMessage());
        }
        db.save();
        assertArrayEquals(before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
        assertArrayEquals(jpeg, Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG")));
        assertFalse(Files.exists(root.resolve("20P00/1G000002P0.JPG")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.RETIRED)));
    }

    @Test public void foreignPicturePointersAreRefusedWithoutAWrite() throws Exception {
        Path root = fixture();
        byte[] table = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        putUtf16(table, 0x340 + 0x210 + 6, "cover.jpg");
        Files.write(root.resolve("03GINF01.DAT"), table);
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        byte[] tree = Files.readAllBytes(root.resolve("01TREE01.DAT"));
        JacketDatabase db = JacketDatabase.read(root.toFile());
        try {
            db.setByAlbum("Day", writeTemp(jpeg(2, 2, Color.RED)));
            fail("set");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage(), expected.getMessage().contains("not a managed picture path"));
        }
        try {
            db.clearByTrack(3);
            fail("clear");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage(), expected.getMessage().contains("not a managed picture path"));
        }
        db.save();
        assertArrayEquals(before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
        assertArrayEquals(tree, Files.readAllBytes(root.resolve("01TREE01.DAT")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));

        byte[] pic0 = Arrays.copyOf(before, before.length);
        Arrays.fill(pic0, 0x340 + 0x210 + 6, 0x340 + 0x290, (byte) 0);
        Arrays.fill(pic0, 0x340 + 0x290 + 6, 0x340 + 0x310, (byte) 0);
        putUtf16(pic0, 0x340 + 0x290 + 6, "SIDE.JPG");
        Files.write(root.resolve("03GINF01.DAT"), pic0);
        byte[] pic0Before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        JacketDatabase again = JacketDatabase.read(root.toFile());
        try {
            again.clearByAlbum("Day");
            fail("pic0");
        } catch (java.io.IOException expected) {
            assertTrue(expected.getMessage(), expected.getMessage().contains("not a managed picture path"));
        }
        again.save();
        assertArrayEquals(pic0Before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void imageOverStoredCapWithinEdgeIsReencoded() throws Exception {
        byte[] noisy = noisyJpeg(240, 240);
        byte[] bulky = Arrays.copyOf(noisy, JacketDatabase.MAX_STORED_BYTES + 64);
        assertTrue(bulky.length > JacketDatabase.MAX_STORED_BYTES);
        byte[] stored = JacketDatabase.normalize(writeTemp(bulky));
        assertTrue(stored.length <= JacketDatabase.MAX_STORED_BYTES);
        assertTrue(containsMarker(stored, 0xC0));
        BufferedImage image = ImageIO.read(new ByteArrayInputStream(stored));
        assertEquals(240, image.getWidth());
        assertEquals(240, image.getHeight());
    }

    @Test public void unreadableOldJpegRollsBackWithoutAPartialWrite() throws Exception {
        Path root = fixture();
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        byte[] jpeg = Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG"));
        Path old = root.resolve("20P00/1G000001P0.JPG");
        OmgaudioJournal.failPayloadRead = old;
        try {
            JacketDatabase db = JacketDatabase.read(root.toFile());
            db.clearByAlbum("Night");
            try {
                db.save();
                fail("clear");
            } catch (java.io.IOException expected) {
                assertFalse(expected.getMessage(), expected.getMessage().contains("PLAYLIST_"));
                assertTrue(expected.getMessage(), expected.getMessage().contains("Could not read"));
            }
            assertArrayEquals(before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
            assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
            assertFalse(Files.exists(root.resolve(OmgaudioJournal.RETIRED)));
        } finally {
            OmgaudioJournal.failPayloadRead = null;
        }
        assertArrayEquals(jpeg, Files.readAllBytes(old));

        Path replace = fixture();
        byte[] replaceBefore = Files.readAllBytes(replace.resolve("03GINF01.DAT"));
        byte[] replaceJpeg = Files.readAllBytes(replace.resolve("20P00/1G000001P0.JPG"));
        Path replaceOld = replace.resolve("20P00/1G000001P0.JPG");
        JacketDatabase writer = JacketDatabase.read(replace.toFile());
        JacketDatabase.Jacket staged = writer.setByAlbum("Night", writeTemp(jpeg(2, 2, Color.GREEN)));
        OmgaudioJournal.failPayloadRead = replaceOld;
        try {
            writer.save();
            fail("replace");
        } catch (java.io.IOException expected) {
            assertFalse(expected.getMessage(), expected.getMessage().contains("PLAYLIST_"));
            assertTrue(expected.getMessage(), expected.getMessage().contains("Could not read"));
        } finally {
            OmgaudioJournal.failPayloadRead = null;
        }
        assertArrayEquals(replaceBefore, Files.readAllBytes(replace.resolve("03GINF01.DAT")));
        assertArrayEquals(replaceJpeg, Files.readAllBytes(replaceOld));
        assertFalse(Files.exists(replace.resolve(staged.path)));
        assertFalse(Files.exists(replace.resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void errorBeforeCommitDropsTheJournal() throws Exception {
        Path root = fixture();
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        byte[] jpeg = Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG"));
        JacketDatabase db = JacketDatabase.read(root.toFile());
        db.setByTrack(3, writeTemp(jpeg(2, 2, Color.BLUE)));
        try {
            db.save(new OmgaudioJournal.Probe() {
                public void step(String name) {
                    if (!"manifest".equals(name)) return;
                    assertTrue(Files.isDirectory(root.resolve(OmgaudioJournal.DIRECTORY)));
                    assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY).resolve("commit")));
                    throw new OutOfMemoryError("jacket-before-commit");
                }
            });
            fail("error");
        } catch (OutOfMemoryError expected) {
            assertEquals("jacket-before-commit", expected.getMessage());
        }
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.RETIRED)));
        assertArrayEquals(before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
        assertArrayEquals(jpeg, Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG")));
        assertFalse(Files.exists(root.resolve("20P00/1G000002P0.JPG")));
        assertEquals(2, JacketDatabase.read(root.toFile()).list().size());
    }

    @Test public void lockedOldJpegOnClearReportsDeviceFileLocked() throws Exception {
        Path built = fixture();
        Path device = Files.createTempDirectory("jacket-lock-");
        Path root = Files.move(built, device.resolve("OMGAUDIO"));
        byte[] before = Files.readAllBytes(root.resolve("03GINF01.DAT"));
        byte[] jpeg = Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG"));
        OmgaudioJournal.lockAudioOnPublish = true;
        CliResult locked;
        try {
            locked = invoke("jacket-clear", "--device", device.toString(), "--album", "Night");
        } finally {
            OmgaudioJournal.lockAudioOnPublish = false;
        }
        assertEquals(locked.out + locked.err, 1, locked.code);
        assertTrue(locked.out, locked.out.contains(
                "{\"event\":\"fatal\",\"message\":\"Device file is locked\",\"code\":\"DEVICE_FILE_LOCKED\",\"path\":\"OMGAUDIO/20P00/1G000001P0.JPG\"}"));
        assertFalse(locked.out, locked.out.contains("\"event\":\"done\""));
        assertFalse(locked.out, locked.out.contains("\"event\":\"jacket\""));
        assertArrayEquals(before, Files.readAllBytes(root.resolve("03GINF01.DAT")));
        assertArrayEquals(jpeg, Files.readAllBytes(root.resolve("20P00/1G000001P0.JPG")));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(Files.exists(root.resolve(OmgaudioJournal.RETIRED)));
        assertFalse(Files.exists(root.resolve("20P00/1G000001P0.JPG" + OmgaudioJournal.PROBE_SUFFIX)));
    }

    @Test public void jacketsWarnsAboutAPendingProbeAndLeavesTheTree() throws Exception {
        Path device = deviceOf(fixture());
        Path original = device.resolve("OMGAUDIO/10F00/10000001.OMA");
        Files.createDirectories(original.getParent());
        Files.write(original, new byte[] {9, 8, 7});
        Path sibling = original.resolveSibling(original.getFileName().toString() + OmgaudioJournal.PROBE_SUFFIX);
        Files.move(original, sibling);
        Map<String, byte[]> before = fileTree(device);
        CliResult listed = invoke("jackets", "--device", device.toString());
        assertEquals(listed.out + listed.err, 0, listed.code);
        assertTrue(listed.out, hasLine(listed.out,
                "{\"event\":\"warning\",\"code\":\"DEVICE_PROBE_PENDING\",\"path\":\"OMGAUDIO/10F00/10000001.OMA\",\"probe_path\":\"OMGAUDIO/10F00/10000001.OMA.jsymphonic-probe\"}"));
        assertTrue(listed.out, listed.out.contains("\"event\":\"jacketsEnd\""));
        assertFalse(listed.out, listed.out.contains("\"event\":\"fatal\""));
        assertTreeEquals(before, fileTree(device));
        assertFalse(Files.exists(original));
        assertTrue(Files.exists(sibling));
    }

    @Test public void jacketSetRollbackFailureKeepsTheJournal() throws Exception {
        Path device = deviceOf(fixture());
        Path image = writeTemp(jpeg(2, 2, Color.GREEN));
        OmgaudioJournal.failNextPublish = true;
        OmgaudioJournal.failRollbackRestore = true;
        CliResult failed;
        try {
            failed = invoke("jacket-set", "--device", device.toString(), "--id", "3", "--image", image.toString());
        } finally {
            OmgaudioJournal.failNextPublish = false;
            OmgaudioJournal.failRollbackRestore = false;
        }
        assertEquals(failed.out + failed.err, 1, failed.code);
        assertTrue(failed.out, hasLine(failed.out,
                "{\"event\":\"fatal\",\"message\":\"Database update failed; incomplete recovery requires a verified backup\",\"code\":\"DEVICE_ROLLBACK_FAILED\"}"));
        assertFalse(failed.out, failed.out.contains("\"event\":\"done\""));
        assertTrue(Files.isDirectory(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertTrue(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY).resolve("commit")));
    }

    @Test public void lockedOldJpegOnReplaceWritesNothing() throws Exception {
        Path device = deviceOf(fixture());
        Map<String, byte[]> before = fileTree(device);
        Path image = writeTemp(jpeg(2, 2, Color.GREEN));
        NWOmgaudio.fileLockProbe = new NWOmgaudio.FileLockProbe() {
            public boolean locked(File file) {
                return file.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".jpg");
            }
        };
        CliResult locked;
        try {
            locked = invoke("jacket-set", "--device", device.toString(), "--album", "Night", "--image", image.toString());
        } finally {
            NWOmgaudio.fileLockProbe = null;
        }
        assertEquals(locked.out + locked.err, 1, locked.code);
        assertTrue(locked.out, hasLine(locked.out,
                "{\"event\":\"fatal\",\"message\":\"Device file is locked\",\"code\":\"DEVICE_FILE_LOCKED\",\"path\":\"OMGAUDIO/20P00/1G000001P0.JPG\"}"));
        assertFalse(locked.out, locked.out.contains("\"event\":\"done\""));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertTreeEquals(before, fileTree(device));
    }

    @Test public void readOnlyOldJpegOnReplaceWritesNothing() throws Exception {
        Path device = deviceOf(fixture());
        Map<String, byte[]> before = fileTree(device);
        Path image = writeTemp(jpeg(2, 2, Color.BLUE));
        NWOmgaudio.fileReadOnlyProbe = new NWOmgaudio.FileLockProbe() {
            public boolean locked(File file) {
                return file.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".jpg");
            }
        };
        CliResult rejected;
        try {
            rejected = invoke("jacket-set", "--device", device.toString(), "--album", "Night", "--image", image.toString());
        } finally {
            NWOmgaudio.fileReadOnlyProbe = null;
        }
        assertEquals(rejected.out + rejected.err, 1, rejected.code);
        assertTrue(rejected.out, hasLine(rejected.out,
                "{\"event\":\"fatal\",\"message\":\"Device file is read-only\",\"code\":\"DEVICE_FILE_READ_ONLY\",\"path\":\"OMGAUDIO/20P00/1G000001P0.JPG\"}"));
        assertFalse(rejected.out, rejected.out.contains("\"event\":\"done\""));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertTreeEquals(before, fileTree(device));
    }

    @Test public void errorDuringJacketCommandIsOneFatalAndLeavesNoJournal() throws Exception {
        Path device = deviceOf(fixture());
        byte[] before = Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT"));
        Path image = writeTemp(jpeg(2, 2, Color.BLUE));
        JacketDatabase.failNextSaveAtStep = "manifest";
        CliResult failed;
        try {
            failed = invoke("jacket-set", "--device", device.toString(), "--id", "3", "--image", image.toString());
        } finally {
            JacketDatabase.failNextSaveAtStep = null;
        }
        assertEquals(failed.out + failed.err, 1, failed.code);
        String[] lines = failed.out.split("\\R");
        int fatals = 0;
        String fatal = null;
        for (String line : lines) {
            if (line.isEmpty()) continue;
            assertTrue(line, line.contains("\"event\":\"fatal\""));
            fatals++;
            fatal = line;
        }
        assertEquals(failed.out, 1, fatals);
        assertTrue(fatal, fatal.contains("OutOfMemoryError"));
        assertFalse(fatal, fatal.contains("\"code\""));
        assertFalse(fatal, fatal.contains("\"path\""));
        assertFalse(failed.out, failed.out.contains("\"event\":\"done\""));
        assertFalse(failed.out, failed.out.contains("\"event\":\"jacket\""));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.RETIRED)));
        assertArrayEquals(before, Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT")));
        assertFalse(Files.exists(device.resolve("OMGAUDIO/20P00/1G000002P0.JPG")));
    }

    @Test public void pendingJournalUsesThePlaylistCode() throws Exception {
        Path root = fixture();
        Files.createDirectory(root.resolve(OmgaudioJournal.DIRECTORY));
        try {
            JacketDatabase.read(root.toFile());
            fail("pending");
        } catch (NativePlaylistDatabase.Fatal expected) {
            assertEquals(NativePlaylistDatabase.Fatal.JOURNAL_PENDING, expected.code);
        }
    }

    private static Path deviceOf(Path omgaudio) throws Exception {
        Path device = Files.createTempDirectory("jacket-mount-");
        Files.move(omgaudio, device.resolve("OMGAUDIO"));
        return device;
    }

    private static boolean hasLine(String out, String line) {
        for (String candidate : out.split("\\r?\\n", -1)) if (candidate.equals(line)) return true;
        return false;
    }

    private static Map<String, byte[]> fileTree(final Path root) throws Exception {
        final Map<String, byte[]> tree = new TreeMap<String, byte[]>();
        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                String rel = root.relativize(dir).toString().replace('\\', '/');
                if (!rel.isEmpty()) tree.put(rel + "/", new byte[0]);
                return FileVisitResult.CONTINUE;
            }
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                tree.put(root.relativize(file).toString().replace('\\', '/'), Files.readAllBytes(file));
                return FileVisitResult.CONTINUE;
            }
        });
        return tree;
    }

    private static void assertTreeEquals(Map<String, byte[]> before, Map<String, byte[]> after) {
        assertEquals(before.keySet(), after.keySet());
        for (String path : before.keySet()) assertArrayEquals(path, before.get(path), after.get(path));
    }

    private static CliResult invoke(String... args) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        int code = HeadlessCli.run(args, new PrintStream(out, true, "UTF-8"), new PrintStream(err, true, "UTF-8"));
        return new CliResult(code, out.toString("UTF-8"), err.toString("UTF-8"));
    }

    private static final class CliResult {
        final int code; final String out, err;
        CliResult(int code, String out, String err) { this.code = code; this.out = out; this.err = err; }
    }

    private static void assertNoJournalTemps(Path root) throws Exception {
        Files.walkFileTree(root, new java.nio.file.SimpleFileVisitor<Path>() {
            @Override public java.nio.file.FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) {
                assertFalse(file.toString(), file.getFileName().toString().endsWith(".jsymphonic-tmp"));
                return java.nio.file.FileVisitResult.CONTINUE;
            }
        });
    }

    private static Path fixture() throws Exception {
        Path root = Files.createTempDirectory("jacket-db-");
        Files.write(root.resolve("03GINF01.DAT"), albumTable());
        Files.write(root.resolve("01TREE01.DAT"), tree());
        Files.write(root.resolve("05CIDLST.DAT"), new byte[] {9, 8, 7, 6, 5});
        Files.createDirectories(root.resolve("20P00"));
        Files.write(root.resolve("20P00/1G000001P0.JPG"), jpeg(2, 2, Color.RED));
        Files.write(root.resolve("20P00/OTHER.JPG"), new byte[] {1, 2, 3, 4});
        return root;
    }

    private static byte[] albumTable() {
        int record = 0x310;
        byte[] data = new byte[0x30 + 2 * record];
        ascii(data, 0, "GPIF");
        data[4] = 1; data[5] = 1; data[8] = 1; data[15] = 0x7E;
        ascii(data, 16, "GPFB");
        put32(data, 20, 0x20);
        put32(data, 24, 16 + 2 * record);
        data[28] = 0x11; data[29] = 0x22; data[30] = 0x33; data[31] = 0x44;
        ascii(data, 0x20, "GPFB");
        put16(data, 0x24, 2);
        put16(data, 0x26, record);
        data[0x2F] = (byte) 0xAB;
        record(data, 0, "Night", "Ada", "20P00/1G000001P0.JPG", (byte) 0x5A);
        record(data, 1, "Day", "Bea", "", (byte) 0xA5);
        return data;
    }

    private static void record(byte[] data, int index, String album, String artist, String path, byte marker) {
        int at = 0x30 + index * 0x310;
        Arrays.fill(data, at, at + 8, marker);
        put32(data, at + 8, 1000 * (index + 1));
        put16(data, at + 12, 6);
        put16(data, at + 14, 0x80);
        tag(data, at, 0, "TIT2", album, false);
        tag(data, at, 1, "TPE1", artist, false);
        tag(data, at, 2, "TCON", "Jazz", false);
        tag(data, at, 3, "TSOP", "", false);
        tag(data, at, 4, "PICP", path, false);
        tag(data, at, 5, "PIC0", "", true);
    }

    private static void tag(byte[] data, int record, int index, String name, String text, boolean opaque) {
        int at = record + 16 + index * 0x80;
        ascii(data, at, name);
        put16(data, at + 4, 2);
        if (opaque) Arrays.fill(data, at + 6, at + 0x80, (byte) 0x3C);
        else if (text != null && !text.isEmpty()) {
            byte[] encoded = text.getBytes(StandardCharsets.UTF_16BE);
            System.arraycopy(encoded, 0, data, at + 6, encoded.length);
        }
    }

    private static byte[] tree() {
        byte[] data = new byte[0x66];
        ascii(data, 0, "TREE");
        data[4] = 1; data[5] = 1; data[8] = 2;
        ascii(data, 16, "GPLB");
        put32(data, 20, 0x30);
        put32(data, 24, 32);
        ascii(data, 32, "TPLB");
        put32(data, 36, 0x50);
        put32(data, 40, 22);
        ascii(data, 0x30, "GPLB");
        put16(data, 0x34, 2);
        put16(data, 0x36, 8);
        row(data, 0x40, 1, 1);
        row(data, 0x48, 2, 3);
        ascii(data, 0x50, "TPLB");
        put16(data, 0x54, 3);
        put16(data, 0x56, 2);
        put16(data, 0x60, 14);
        put16(data, 0x62, 1);
        put16(data, 0x64, 3);
        return data;
    }

    private static void row(byte[] data, int at, int id, int start) {
        put16(data, at, id);
        put16(data, at + 2, 0x0100);
        put16(data, at + 4, start);
    }

    private static byte[] jpeg(int width, int height, Color color) throws Exception {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        java.awt.Graphics2D g = image.createGraphics();
        g.setColor(color);
        g.fillRect(0, 0, width, height);
        g.dispose();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        assertTrue(ImageIO.write(image, "jpeg", out));
        return out.toByteArray();
    }

    private static byte[] progressiveJpeg(int width, int height, Color color) throws Exception {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        java.awt.Graphics2D g = image.createGraphics();
        g.setColor(color);
        g.fillRect(0, 0, width, height);
        g.dispose();
        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setProgressiveMode(ImageWriteParam.MODE_DEFAULT);
        try (ImageOutputStream out = ImageIO.createImageOutputStream(bytes)) {
            writer.setOutput(out);
            writer.write(null, new IIOImage(image, null, null), param);
        } finally { writer.dispose(); }
        return bytes.toByteArray();
    }

    private static byte[] noisyJpeg(int width, int height) throws Exception {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Random random = new Random(1);
        for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) image.setRGB(x, y, random.nextInt());
        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality(1f);
        try (ImageOutputStream out = ImageIO.createImageOutputStream(bytes)) {
            writer.setOutput(out);
            writer.write(null, new IIOImage(image, null, null), param);
        } finally { writer.dispose(); }
        return bytes.toByteArray();
    }

    private static byte[] patchSof(byte[] data, int marker, int width, int height) {
        byte[] copy = Arrays.copyOf(data, data.length);
        for (int i = 0; i + 9 < copy.length; i++) {
            if ((copy[i] & 255) == 0xFF && (copy[i + 1] & 255) == marker) {
                copy[i + 5] = (byte) (height >> 8);
                copy[i + 6] = (byte) height;
                copy[i + 7] = (byte) (width >> 8);
                copy[i + 8] = (byte) width;
                return copy;
            }
        }
        throw new AssertionError("missing SOF");
    }

    private static void putUtf16(byte[] data, int at, String text) {
        byte[] encoded = text.getBytes(StandardCharsets.UTF_16BE);
        System.arraycopy(encoded, 0, data, at, encoded.length);
    }

    private static Path writeTemp(byte[] data) throws Exception {
        Path file = Files.createTempFile("jacket-img-", ".jpg");
        Files.write(file, data);
        return file;
    }

    private static byte[] oversized() {
        byte[] data = new byte[JacketDatabase.MAX_INPUT_BYTES + 1];
        data[0] = (byte) 0xFF;
        data[1] = (byte) 0xD8;
        return data;
    }

    private static boolean containsMarker(byte[] data, int marker) {
        for (int i = 0; i + 1 < data.length; i++) {
            if ((data[i] & 255) == 0xFF && (data[i + 1] & 255) == marker) return true;
        }
        return false;
    }

    private static void ascii(byte[] data, int at, String text) {
        System.arraycopy(text.getBytes(StandardCharsets.US_ASCII), 0, data, at, 4);
    }
    private static void put16(byte[] data, int at, int value) {
        data[at] = (byte) (value >> 8); data[at + 1] = (byte) value;
    }
    private static void put32(byte[] data, int at, int value) {
        put16(data, at, value >> 16); put16(data, at + 2, value);
    }
}
