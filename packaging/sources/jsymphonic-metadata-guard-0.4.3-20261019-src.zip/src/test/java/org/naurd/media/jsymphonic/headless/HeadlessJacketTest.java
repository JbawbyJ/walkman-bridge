package org.naurd.media.jsymphonic.headless;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Base64;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import org.junit.Test;
import org.naurd.media.jsymphonic.device.sony.nw.OmgaudioJournal;
import static org.junit.Assert.*;

public class HeadlessJacketTest {
    @Test public void setListAndClearRoundTripJson() throws Exception {
        Path device = fixture();
        byte[] image = jpeg(Color.BLUE);
        Path file = Files.createTempFile("jacket-cli-", ".jpg");
        Files.write(file, image);
        Result set = invoke("jacket-set", "--device", device.toString(), "--id", "3", "--image", file.toString());
        assertEquals(set.out + set.err, 0, set.code);
        assertTrue(set.out, set.out.contains("\"event\":\"jacket\""));
        assertTrue(set.out, set.out.contains("\"slot\":\"2\""));
        assertTrue(set.out, set.out.contains("\"album\":\"Day\""));
        assertTrue(set.out, set.out.contains("\"artist\":\"Bea\""));
        assertTrue(set.out, set.out.contains("\"trackIds\":[\"3\"]"));
        assertTrue(set.out, set.out.contains("\"path\":\"20P00/1G000002P0.JPG\""));
        assertTrue(set.out, set.out.contains("\"bytes\":" + image.length));
        assertTrue(set.out, set.out.contains("\"event\":\"done\""));
        assertArrayEquals(image, Files.readAllBytes(device.resolve("OMGAUDIO/20P00/1G000002P0.JPG")));

        Result list = invoke("jackets", "--device", device.toString());
        assertEquals(list.out + list.err, 0, list.code);
        assertTrue(list.out, list.out.contains("\"album\":\"Night\""));
        assertTrue(list.out, list.out.contains("\"path\":\"20P00/1G000001P0.JPG\""));
        assertTrue(list.out, list.out.contains("\"event\":\"jacketsEnd\",\"count\":2"));

        String encoded = Base64.getEncoder().encodeToString("Night".getBytes(StandardCharsets.UTF_8));
        Result clear = invoke("jacket-clear", "--device", device.toString(), "--album-base64", encoded);
        assertEquals(clear.out + clear.err, 0, clear.code);
        assertTrue(clear.out, clear.out.contains("\"album\":\"Night\""));
        assertTrue(clear.out, clear.out.contains("\"path\":null"));
        assertTrue(clear.out, clear.out.contains("\"bytes\":0"));
        assertTrue(clear.out, clear.out.contains("\"event\":\"done\""));
        assertFalse(Files.exists(device.resolve("OMGAUDIO/20P00/1G000001P0.JPG")));
        assertTrue(Files.exists(device.resolve("OMGAUDIO/20P00/1G000002P0.JPG")));
    }

    @Test public void invalidImageIsFatalWithoutANewCodeAndPendingJournalReusesPlaylistCode() throws Exception {
        Path device = fixture();
        byte[] before = Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT"));
        Path bad = Files.createTempFile("jacket-bad-", ".gif");
        Files.write(bad, "GIF89a".getBytes(StandardCharsets.US_ASCII));
        Result rejected = invoke("jacket-set", "--device", device.toString(), "--album", "Day", "--image", bad.toString());
        assertEquals(rejected.out + rejected.err, 1, rejected.code);
        assertTrue(rejected.out, rejected.out.contains("\"event\":\"fatal\""));
        assertTrue(rejected.out, rejected.out.contains("Jacket image must be a JPEG"));
        assertFalse(rejected.out, rejected.out.contains("\"code\""));
        assertFalse(rejected.out, rejected.out.contains("\"event\":\"done\""));
        assertArrayEquals(before, Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT")));
        assertEquals(2, invoke("jacket-set", "--device", device.toString(), "--id", "1").code);

        Files.createDirectory(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY));
        Result pending = invoke("jackets", "--device", device.toString());
        assertEquals(1, pending.code);
        assertTrue(pending.out, pending.out.contains("\"code\":\"PLAYLIST_JOURNAL_PENDING\""));
        assertFalse(pending.out, pending.out.contains("\"event\":\"done\""));
    }

    @Test public void hugeProgressiveHeaderIsFatalAndWritesNothing() throws Exception {
        Path device = fixture();
        byte[] before = Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT"));
        byte[] kept = Files.readAllBytes(device.resolve("OMGAUDIO/20P00/1G000001P0.JPG"));
        Path image = Files.createTempFile("jacket-huge-", ".jpg");
        Files.write(image, patchSof(progressiveJpeg(), 0xC2, 20000, 20000));
        Result rejected = invoke("jacket-set", "--device", device.toString(), "--album", "Day", "--image", image.toString());
        assertEquals(rejected.out + rejected.err, 1, rejected.code);
        assertTrue(rejected.out, rejected.out.contains("\"event\":\"fatal\""));
        assertTrue(rejected.out, rejected.out.contains("Jacket image is too large"));
        assertFalse(rejected.out, rejected.out.contains("\"code\""));
        assertFalse(rejected.out, rejected.out.contains("\"event\":\"done\""));
        assertArrayEquals(before, Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT")));
        assertArrayEquals(kept, Files.readAllBytes(device.resolve("OMGAUDIO/20P00/1G000001P0.JPG")));
        assertFalse(Files.exists(device.resolve("OMGAUDIO/20P00/1G000002P0.JPG")));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    @Test public void foreignPicturePointerIsFatalAndWritesNothing() throws Exception {
        Path device = fixture();
        byte[] table = Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT"));
        byte[] encoded = "cover.jpg".getBytes(StandardCharsets.UTF_16BE);
        System.arraycopy(encoded, 0, table, 0x340 + 0x210 + 6, encoded.length);
        Files.write(device.resolve("OMGAUDIO/03GINF01.DAT"), table);
        byte[] before = Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT"));
        Path image = Files.createTempFile("jacket-foreign-", ".jpg");
        Files.write(image, jpeg(Color.BLUE));
        Result set = invoke("jacket-set", "--device", device.toString(), "--id", "3", "--image", image.toString());
        assertEquals(set.out + set.err, 1, set.code);
        assertTrue(set.out, set.out.contains("\"event\":\"fatal\""));
        assertTrue(set.out, set.out.contains("not a managed picture path"));
        assertFalse(set.out, set.out.contains("\"code\""));
        assertFalse(set.out, set.out.contains("\"event\":\"done\""));
        Result clear = invoke("jacket-clear", "--device", device.toString(), "--album", "Day");
        assertEquals(clear.out + clear.err, 1, clear.code);
        assertTrue(clear.out, clear.out.contains("\"event\":\"fatal\""));
        assertFalse(clear.out, clear.out.contains("\"code\""));
        assertArrayEquals(before, Files.readAllBytes(device.resolve("OMGAUDIO/03GINF01.DAT")));
        assertFalse(Files.exists(device.resolve("OMGAUDIO").resolve(OmgaudioJournal.DIRECTORY)));
    }

    private static Path fixture() throws Exception {
        Path device = Files.createTempDirectory("jacket-cli-");
        Path root = device.resolve("OMGAUDIO");
        Files.createDirectories(root.resolve("20P00"));
        Files.write(root.resolve("03GINF01.DAT"), albumTable());
        Files.write(root.resolve("01TREE01.DAT"), tree());
        Files.write(root.resolve("20P00/1G000001P0.JPG"), jpeg(Color.RED));
        return device;
    }

    private static byte[] albumTable() {
        byte[] data = new byte[0x30 + 2 * 0x310];
        ascii(data, 0, "GPIF");
        data[4] = 1; data[5] = 1; data[8] = 1;
        ascii(data, 16, "GPFB");
        put32(data, 20, 0x20);
        put32(data, 24, 16 + 2 * 0x310);
        ascii(data, 0x20, "GPFB");
        put16(data, 0x24, 2);
        put16(data, 0x26, 0x310);
        record(data, 0, "Night", "Ada", "20P00/1G000001P0.JPG");
        record(data, 1, "Day", "Bea", "");
        return data;
    }

    private static void record(byte[] data, int index, String album, String artist, String path) {
        int at = 0x30 + index * 0x310;
        put16(data, at + 12, 6);
        put16(data, at + 14, 0x80);
        tag(data, at, 0, "TIT2", album);
        tag(data, at, 1, "TPE1", artist);
        tag(data, at, 2, "TCON", "Jazz");
        tag(data, at, 3, "TSOP", "");
        tag(data, at, 4, "PICP", path);
        tag(data, at, 5, "PIC0", "");
    }

    private static void tag(byte[] data, int record, int index, String name, String text) {
        int at = record + 16 + index * 0x80;
        ascii(data, at, name);
        put16(data, at + 4, 2);
        if (!text.isEmpty()) {
            byte[] encoded = text.getBytes(StandardCharsets.UTF_16BE);
            System.arraycopy(encoded, 0, data, at + 6, encoded.length);
        }
    }

    private static byte[] tree() {
        byte[] data = new byte[0x66];
        ascii(data, 0, "TREE");
        data[4] = 1; data[5] = 1; data[8] = 2;
        ascii(data, 16, "GPLB");
        put32(data, 20, 0x30);
        put32(data, 24, 32);
        ascii(data, 32, "TPLB");
        put32(data, 36, 0x50);
        put32(data, 40, 22);
        ascii(data, 0x30, "GPLB");
        put16(data, 0x34, 2);
        put16(data, 0x36, 8);
        put16(data, 0x40, 1); put16(data, 0x42, 0x0100); put16(data, 0x44, 1);
        put16(data, 0x48, 2); put16(data, 0x4A, 0x0100); put16(data, 0x4C, 3);
        ascii(data, 0x50, "TPLB");
        put16(data, 0x54, 3);
        put16(data, 0x56, 2);
        put16(data, 0x60, 14); put16(data, 0x62, 1); put16(data, 0x64, 3);
        return data;
    }

    private static byte[] jpeg(Color color) throws Exception {
        BufferedImage image = new BufferedImage(2, 2, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setColor(color);
        g.fillRect(0, 0, 2, 2);
        g.dispose();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        assertTrue(ImageIO.write(image, "jpeg", out));
        return out.toByteArray();
    }

    private static byte[] progressiveJpeg() throws Exception {
        BufferedImage image = new BufferedImage(8, 8, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image.createGraphics();
        g.setColor(Color.GREEN);
        g.fillRect(0, 0, 8, 8);
        g.dispose();
        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ImageWriteParam param = writer.getDefaultWriteParam();
        param.setProgressiveMode(ImageWriteParam.MODE_DEFAULT);
        try (ImageOutputStream out = ImageIO.createImageOutputStream(bytes)) {
            writer.setOutput(out);
            writer.write(null, new IIOImage(image, null, null), param);
        } finally { writer.dispose(); }
        return bytes.toByteArray();
    }

    private static byte[] patchSof(byte[] data, int marker, int width, int height) {
        byte[] copy = Arrays.copyOf(data, data.length);
        for (int i = 0; i + 9 < copy.length; i++) {
            if ((copy[i] & 255) == 0xFF && (copy[i + 1] & 255) == marker) {
                copy[i + 5] = (byte) (height >> 8);
                copy[i + 6] = (byte) height;
                copy[i + 7] = (byte) (width >> 8);
                copy[i + 8] = (byte) width;
                return copy;
            }
        }
        throw new AssertionError("missing SOF");
    }

    private static void ascii(byte[] data, int at, String text) {
        System.arraycopy(text.getBytes(StandardCharsets.US_ASCII), 0, data, at, 4);
    }
    private static void put16(byte[] data, int at, int value) {
        data[at] = (byte) (value >> 8); data[at + 1] = (byte) value;
    }
    private static void put32(byte[] data, int at, int value) {
        put16(data, at, value >> 16); put16(data, at + 2, value);
    }

    private static Result invoke(String... args) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayOutputStream err = new ByteArrayOutputStream();
        int code = HeadlessCli.run(args, new PrintStream(out, true, "UTF-8"), new PrintStream(err, true, "UTF-8"));
        return new Result(code, out.toString("UTF-8"), err.toString("UTF-8"));
    }

    private static final class Result {
        final int code; final String out, err;
        Result(int code, String out, String err) { this.code = code; this.out = out; this.err = err; }
    }
}
