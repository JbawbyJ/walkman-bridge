package org.naurd.media.jsymphonic.headless;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.junit.Assume;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

public class HeadlessCliTest {

    @Test
    public void jsonEscapesQuotesNewlinesAndControls() {
        assertEquals("\"\"", HeadlessCli.json(null));
        assertEquals("\"\"", HeadlessCli.json(""));
        assertEquals("\"hello\"", HeadlessCli.json("hello"));
        assertEquals("\"say \\\"hi\\\"\"", HeadlessCli.json("say \"hi\""));
        assertEquals("\"a\\\\b\"", HeadlessCli.json("a\\b"));
        assertEquals("\"line\\nbreak\"", HeadlessCli.json("line\nbreak"));
        assertEquals("\"tab\\there\"", HeadlessCli.json("tab\there"));
        assertEquals("\"\\u0001\"", HeadlessCli.json("\u0001"));
    }

    @Test
    public void stripHtmlFlattensGuiDeletionErrors() {
        String html = "<html>Errors during deletion:<br>consult the log.";
        assertEquals("Errors during deletion: consult the log.", HeadlessCli.stripHtml(html));
        assertEquals("", HeadlessCli.stripHtml(null));
        assertEquals("plain", HeadlessCli.stripHtml("plain"));
    }

    @Test
    public void missingArgsIsUsageExit() throws Exception {
        CliResult result = invoke();
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
        assertEquals("", result.out.trim());
    }

    @Test
    public void missingDeviceIsUsageExit() throws Exception {
        CliResult result = invoke("info");
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
        assertEquals("", result.out.trim());
    }

    @Test
    public void unknownFlagIsUsageExit() throws Exception {
        CliResult result = invoke("info", "--device", "/tmp", "--help");
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void missingOmgaudioIsFatalJson() throws Exception {
        File empty = tempDir("no-omgaudio");
        CliResult result = invoke("info", "--device", empty.getAbsolutePath());
        assertEquals(1, result.code);
        assertTrue(result.out.contains("\"event\":\"fatal\""));
        assertTrue(result.out.contains("OMGAUDIO"));
        assertFalse("stdout must stay JSON-lines", result.out.contains("Usage:"));
    }

    @Test
    public void addWithoutFilesIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("add", "--device", mount.getAbsolutePath());
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void delWithoutIdIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("del", "--device", mount.getAbsolutePath());
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void unknownCommandOnValidMountIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("sync", "--device", mount.getAbsolutePath());
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void infoOnEmptyOmgaudioEmitsDeviceEvent() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("info", "--device", mount.getAbsolutePath());
        assertEquals(result.err, 0, result.code);
        assertTrue(result.out, result.out.contains("\"event\":\"device\""));
        assertTrue(result.out, result.out.contains("\"ok\":true"));
        assertTrue(result.out, result.out.contains("\"trackCount\":0"));
        assertFalse("leftover System.out must not leak onto stdout",
                result.out.contains("THERE'S ONE"));
        for (String line : result.out.split("\\r?\\n")) {
            if (line.isEmpty()) {
                continue;
            }
            assertTrue("stdout line is JSON: " + line, line.startsWith("{") && line.endsWith("}"));
        }
    }

    @Test
    public void listOnEmptyOmgaudioEmitsListEnd() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("list", "--device", mount.getAbsolutePath());
        assertEquals(result.err, 0, result.code);
        assertTrue(result.out, result.out.contains("\"event\":\"listEnd\""));
        assertTrue(result.out, result.out.contains("\"count\":0"));
    }

    @Test
    public void systemOutDuringRunGoesToStderrNotJson() throws Exception {
        File empty = tempDir("no-omgaudio-sysout");
        ByteArrayOutputStream json = new ByteArrayOutputStream();
        ByteArrayOutputStream logs = new ByteArrayOutputStream();
        PrintStream jsonOut = new PrintStream(json, true, "UTF-8");
        PrintStream logErr = new PrintStream(logs, true, "UTF-8");
        int code = HeadlessCli.run(
                new String[] {"info", "--device", empty.getAbsolutePath()},
                jsonOut, logErr);
        assertEquals(1, code);
        // A debug print from the device layer (or this test's captured System.out
        // redirect target) must not appear on the JSON stream.
        String out = json.toString("UTF-8");
        assertTrue(out.contains("\"event\":\"fatal\""));
        assertFalse(out.contains("THERE'S ONE"));
    }

    @Test
    public void stepErrorAfterTerminationIsFatal() throws Exception {
        HeadlessCli.EventListener listener = new HeadlessCli.EventListener();
        listener.transferStepFinished(org.naurd.media.jsymphonic.device.sony.nw.NWGenericListener.DELETING,
                "<html>Errors during deletion:<br>consult the log.");
        listener.transferTermination();
        assertEquals("Errors during deletion: consult the log.", listener.stepError.get());
        assertEquals(0, listener.finished.getCount());
    }

    // Cyrillic and CJK are both outside cp1252, the ANSI code page that turns them into '?'.
    private static final String NON_ANSI = "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u7528\u6237";

    @Test
    public void deviceBase64SelectsTheMount() throws Exception {
        // Windows file APIs are UTF-16. Elsewhere NIO paths need a locale that can name the folder.
        Assume.assumeTrue(File.separatorChar == '\\'
                || Charset.forName(System.getProperty("sun.jnu.encoding")).newEncoder().canEncode(NON_ANSI));
        File mount = mockDevice(new File(tempDir("device-base64"), NON_ANSI));
        CliResult result = invoke("info", "--device-base64", base64(mount.getAbsolutePath()));
        assertEquals(result.err, 0, result.code);
        assertTrue(result.out, result.out.contains("\"ok\":true"));
    }

    @Test
    public void fileBase64KeepsArgumentOrderWithPlainFiles() throws Exception {
        File mount = mockDevice();
        File folder = new File(tempDir("file-base64"), NON_ANSI);
        assertTrue(folder.mkdir());
        folder.deleteOnExit();
        File input = new File(folder, "input.txt");
        assertTrue(input.createNewFile());
        input.deleteOnExit();
        String missing = new File(folder, "missing.mp3").getAbsolutePath();

        // The decoded path is a real file, so the shim gets past "File not found".
        CliResult encodedFirst = invoke("add", "--device", mount.getAbsolutePath(),
                "--file-base64", base64(input.getAbsolutePath()), missing);
        assertEquals(1, encodedFirst.code);
        assertTrue(encodedFirst.out, encodedFirst.out.contains(
                HeadlessCli.json("Unsupported input format: " + input.getAbsolutePath() + ". No files were imported.")));

        CliResult plainFirst = invoke("add", "--device", mount.getAbsolutePath(),
                missing, "--file-base64", base64(input.getAbsolutePath()));
        assertEquals(1, plainFirst.code);
        assertTrue(plainFirst.out, plainFirst.out.contains(HeadlessCli.json("File not found: " + missing)));
    }

    @Test
    public void deviceAndDeviceBase64TogetherIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("info", "--device", mount.getAbsolutePath(),
                "--device-base64", base64(mount.getAbsolutePath()));
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
    }

    @Test
    public void fileBase64OutsideAddIsUsageExit() throws Exception {
        File mount = mockDevice();
        CliResult result = invoke("list", "--device", mount.getAbsolutePath(), "--file-base64", base64("a.mp3"));
        assertEquals(2, result.code);
        assertTrue(result.err.contains("Usage: HeadlessCli"));
        assertEquals("", result.out.trim());
    }

    @Test
    public void invalidPathEncodingsAreFatalBeforeDeviceAccess() throws Exception {
        String mount = tempDir("no-omgaudio-base64").getAbsolutePath();
        String[][] cases = {
            {"--file-base64", "not base64!", "Invalid base64 file path"},
            {"--file-base64", base64("a\u0000b"), "Invalid file path"},
            {"--file-base64", "", "Invalid file path"},
            {"--device-base64", Base64.getEncoder().encodeToString(new byte[] {(byte) 0xff}), "Invalid UTF-8 device path"},
        };
        for (String[] c : cases) {
            CliResult result = "--device-base64".equals(c[0])
                    ? invoke("info", c[0], c[1])
                    : invoke("add", "--device", mount, c[0], c[1]);
            assertEquals(result.out, 1, result.code);
            assertTrue(result.out, result.out.contains("\"event\":\"fatal\""));
            assertTrue(result.out, result.out.contains(c[2]));
            assertFalse("decoding precedes the mount check", result.out.contains("OMGAUDIO"));
        }
    }

    private static String base64(String text) {
        return Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    private static File mockDevice() throws Exception {
        return mockDevice(tempDir("mock-walkman"));
    }

    private static File mockDevice(File mount) throws Exception {
        if (!mount.isDirectory() && !mount.mkdir()) {
            fail("could not create " + mount);
        }
        File omgaudio = new File(mount, "OMGAUDIO");
        if (!omgaudio.mkdir()) {
            fail("could not create " + omgaudio);
        }
        return mount;
    }

    private static File tempDir(String prefix) throws Exception {
        File dir = File.createTempFile(prefix, "");
        if (!dir.delete() || !dir.mkdir()) {
            fail("could not create temp dir " + dir);
        }
        dir.deleteOnExit();
        return dir;
    }

    private static CliResult invoke(String... args) throws UnsupportedEncodingException {
        ByteArrayOutputStream json = new ByteArrayOutputStream();
        ByteArrayOutputStream logs = new ByteArrayOutputStream();
        PrintStream jsonOut = new PrintStream(json, true, "UTF-8");
        PrintStream logErr = new PrintStream(logs, true, "UTF-8");
        int code = HeadlessCli.run(args, jsonOut, logErr);
        return new CliResult(code, json.toString("UTF-8"), logs.toString("UTF-8"));
    }

    private static final class CliResult {
        final int code;
        final String out;
        final String err;

        CliResult(int code, String out, String err) {
            this.code = code;
            this.out = out;
            this.err = err;
        }
    }
}
