package org.naurd.media.jsymphonic.device.sony.nw;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.naurd.media.jsymphonic.title.Oma;
import static org.junit.Assert.*;

public class Utf16MetadataReadTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();
    private static final String[] TEXT = {
        "\u5742\u672c\u9f8d\u4e00", "Latin \u0100", "Emoji \ud83d\ude00", "ASCII"
    };

    @Test public void omaUnpaddedTextKeepsFinalZeroByte() throws Exception {
        assertOmaText(0);
    }

    @Test public void omaPaddedTextKeepsFinalZeroByte() throws Exception {
        assertOmaText(8);
    }

    @Test public void emptyOmaTextDoesNotBecomeReplacementCharacter() throws Exception {
        Oma title = readOma("", 8);
        assertEquals("", title.getTitle());
        assertEquals("", title.getArtist());
        assertEquals("", title.getAlbum());
        assertEquals("unknown genre (JSoma)", title.getGenre());
    }

    @Test public void paddedOriginalPathsKeepFinalZeroByteAndSkipEmptyRows() throws Exception {
        Path root = temporary.newFolder().toPath();
        // A 04PATLST header followed by fixed-size 0x150-byte TIT2 records.
        byte[] table = new byte[0x30 + (TEXT.length + 1) * 0x150];
        ByteBuffer.wrap(table).putShort(0x24, (short) (TEXT.length + 1));
        for (int i = 0; i < TEXT.length; i++) {
            int offset = 0x30 + i * 0x150;
            byte[] value = ("C:/synthetic/" + TEXT[i]).getBytes(StandardCharsets.UTF_16BE);
            System.arraycopy(new byte[] {'T','I','T','2',0,2}, 0, table, offset, 6);
            System.arraycopy(value, 0, table, offset + 6, value.length);
        }
        Files.write(root.resolve("04PATLST.DAT"), table);
        DataBaseOmgaudio database = new DataBaseOmgaudio(root.toFile(), false, false, false, false, false);
        assertEquals(0, database.buildPathList());
        for (int i = 0; i < TEXT.length; i++) {
            assertEquals("C:/synthetic/" + TEXT[i], database.paths.getValue(i + 1));
        }
        assertEquals("An empty padded path must not create a phantom source", TEXT.length, database.paths.size());
    }

    private void assertOmaText(int padding) throws Exception {
        for (String text : TEXT) {
            Oma title = readOma(text, padding);
            assertEquals(text, title.getTitle());
            assertEquals(text, title.getArtist());
            assertEquals(text, title.getAlbum());
            assertEquals(text, title.getGenre());
            assertEquals(7, title.getTitleNumber());
            assertEquals(2024, title.getYear());
        }
    }

    private Oma readOma(String text, int padding) throws Exception {
        // Hand-built EA3 text frames exercise the reader independently of its writer.
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.write(new byte[] {'e','a','3',3,0,0,0,0,0x17,0x76});
        for (String tag : new String[] {"TIT2", "TPE1", "TALB", "TCON"}) {
            frame(out, tag, text, padding);
        }
        frame(out, "TXXX", "OMG_TRACK\u00007", padding);
        frame(out, "TYER", "2024", padding);
        out.flush();
        byte[] oma = new byte[0xC60];
        System.arraycopy(bytes.toByteArray(), 0, oma, 0, bytes.size());
        Path file = temporary.newFile().toPath();
        Files.write(file, oma);
        Oma title = new Oma(file.toFile());
        assertFalse("Synthetic text frames must parse", title.failedToParse());
        return title;
    }

    private static void frame(DataOutputStream out, String tag, String text, int padding) throws Exception {
        byte[] encoded = text.getBytes(StandardCharsets.UTF_16BE);
        out.write(tag.getBytes(StandardCharsets.US_ASCII));
        out.writeInt(encoded.length + padding + 1);
        out.write(new byte[] {0,0,2});
        out.write(encoded);
        out.write(new byte[padding]);
    }
}
